// SPDX-License-Identifier: GPL-3.0-or-later
// fill_halos (several fields, one launch per direction) must give exactly the same halos as
// fill_halo field by field: all staggers, Field2 and Field3 (also mixed in one batch, with explicit parities),
// periodic, symmetric and specified, 2D and 3D.
#include <cstdio>
#include <vector>

#include "core/field.hpp"
#include "core/halo.hpp"

using namespace cppwrf;
static int fails = 0;

template <int R> static std::vector<real> host(const FieldT<R>& f) { std::vector<real> h; f.download(h); return h; }

static void run(int nx, int ny, int nz, BC bx, BC by) {
  Grid g; g.nx = nx; g.ny = ny; g.nz = nz; g.bc_x = bx; g.bc_y = by;
  auto val = [](int i, int j, int k) { return 0.37 * i - 1.1 * j + 3.3 * k + 0.01 * i * j * (k + 1); };
  Field3 a1(g, Stagger::M, "m"), b1(g, Stagger::U, "u"), c1(g, Stagger::V, "v"), d1(g, Stagger::W, "w");
  Field3 a2(g, Stagger::M, "m"), b2(g, Stagger::U, "u"), c2(g, Stagger::V, "v"), d2(g, Stagger::W, "w");
  Field2 e1(g, Stagger::M, "mu"), f1(g, Stagger::U, "muu"), e2(g, Stagger::M, "mu"), f2(g, Stagger::U, "muu");
  for (Field3* f : {&a1, &b1, &c1, &d1, &a2, &b2, &c2, &d2}) f->fill_host(val);
  for (Field2* f : {&e1, &f1, &e2, &f2}) f->fill_host(val);
  for (Field3* f : {&a1, &b1, &c1, &d1}) fill_halo(*f, g);
  for (Field2* f : {&e1, &f1}) fill_halo(*f, g);
  fill_halos({&a2, &b2, &c2, &d2}, g);
  fill_halos({&e2, &f2}, g);
  int bad = 0;
  const std::pair<const Field3*, const Field3*> p3[] = {{&a1, &a2}, {&b1, &b2}, {&c1, &c2}, {&d1, &d2}};
  for (auto [x, y] : p3) bad += host(*x) != host(*y);
  bad += host(e1) != host(e2);
  bad += host(f1) != host(f2);
  {  // one batch of both ranks with explicit parities (fill_halos of HaloField) = fill_halo with those parities
    Field3 g1(g, Stagger::U, "u"), h1(g, Stagger::V, "v"), g2(g, Stagger::U, "u"), h2(g, Stagger::V, "v");
    Field2 u1(g, Stagger::U, "muu"), v1(g, Stagger::V, "muv"), u2(g, Stagger::U, "muu"), v2(g, Stagger::V, "muv");
    for (Field3* f : {&g1, &h1, &g2, &h2}) f->fill_host(val);
    for (Field2* f : {&u1, &v1, &u2, &v2}) f->fill_host(val);
    fill_halo(g1, g, Parity::OddFace, Parity::Even);
    fill_halo(h1, g, Parity::Even, Parity::OddFace);
    fill_halo(u1, g, Parity::OddFace, Parity::Even);
    fill_halo(v1, g, Parity::Even, Parity::Odd);
    fill_halos({HaloField(g2, Parity::OddFace, Parity::Even), HaloField(h2, Parity::Even, Parity::OddFace),
                HaloField(u2, Parity::OddFace, Parity::Even), HaloField(v2, Parity::Even, Parity::Odd)}, g);
    bad += host(g1) != host(g2);
    bad += host(h1) != host(h2);
    bad += host(u1) != host(u2);
    bad += host(v1) != host(v2);
  }
  {  // default parities, both ranks in one batch
    Field3 m1(g, Stagger::W, "w"), m2(g, Stagger::W, "w");
    Field2 n1(g, Stagger::M, "mu"), n2(g, Stagger::M, "mu");
    m1.fill_host(val); m2.fill_host(val); n1.fill_host(val); n2.fill_host(val);
    fill_halo(m1, g);
    fill_halo(n1, g);
    fill_halos({m2, n2}, g);
    bad += host(m1) != host(m2);
    bad += host(n1) != host(n2);
  }
  if (bx == BC::Specified) {  // flat copy outward (WRF set_physical_bc for specified)
    std::vector<real> hm = host(a1), hu = host(b1);
    const Layout &Lm = a1.layout(), &Lu = b1.layout();
    for (int k = 0; k < nz; ++k)
      for (int i = 1; i <= 3; ++i) {
        bad += hm[Lm.index(-i, 0, k)] != hm[Lm.index(0, 0, k)];
        bad += hm[Lm.index(nx - 1 + i, 0, k)] != hm[Lm.index(nx - 1, 0, k)];
        bad += hu[Lu.index(-i, 0, k)] != hu[Lu.index(0, 0, k)];
        bad += hu[Lu.index(nx + i, 0, k)] != hu[Lu.index(nx, 0, k)];
      }
  }
  if (bad) { std::printf("FAIL fill_halos nx=%d ny=%d bx=%d by=%d: %d fields differ\n", nx, ny, int(bx), int(by), bad); ++fails; }
}

int main() {
  for (BC bx : {BC::Periodic, BC::Symmetric, BC::Specified})
    for (BC by : {BC::Periodic, BC::Symmetric, BC::Specified}) {
      run(13, 1, 5, bx, by);
      run(13, 9, 5, bx, by);
      run(40, 33, 7, bx, by);
    }
  std::printf(fails ? "test_halo_multi: %d FAILED\n" : "test_halo_multi: all passed\n", fails);
  return fails ? 1 : 0;
}
