# SPDX-License-Identifier: GPL-3.0-or-later
cmake_minimum_required(VERSION 3.24)

set(CPPWRF_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/../../..")

# The Fortran side (WRF's module_cu_kfeta.o) is compiled and linked by run_test.sh (tests/phys/wrf_fortran.sh)

# 1. Table test: init_kf_tables against WRF's kf_lutab (dump_tables_f.f90 + dump_tables_c.c)
add_executable(test_tables_kf
  test_tables.cpp
  ${CPPWRF_ROOT}/src/phys/cu_kf/kf_tables.cpp
)
target_include_directories(test_tables_kf PRIVATE ${CPPWRF_ROOT} ${CPPWRF_ROOT}/src)
target_compile_definitions(test_tables_kf PRIVATE CPPWRF_DOUBLE)
target_compile_options(test_tables_kf PRIVATE -O3 -march=native -ffp-contract=off)

# 2. C++ Driver (CPU FP64)
add_executable(driver_kf_cpu
  driver_kf.cpp
  ${CPPWRF_ROOT}/src/phys/cu_kf/kf.cpp
  ${CPPWRF_ROOT}/src/phys/cu_kf/kf_tables.cpp
  ${CPPWRF_ROOT}/src/core/backend.cpp
)
target_include_directories(driver_kf_cpu PRIVATE
  ${CPPWRF_ROOT}/src
  ${CMAKE_CURRENT_SOURCE_DIR}
)
target_compile_definitions(driver_kf_cpu PRIVATE CPPWRF_DOUBLE)
target_compile_options(driver_kf_cpu PRIVATE -O3 -march=native -ffp-contract=off)
target_link_libraries(driver_kf_cpu PRIVATE
  OpenMP::OpenMP_CXX
)

# 3. CUDA Drivers (if CUDA enabled)
if(CMAKE_CUDA_COMPILER AND (NOT DEFINED CPPWRF_ENABLE_CUDA OR CPPWRF_ENABLE_CUDA))
  add_executable(driver_kf_cuda_dp
    driver_kf.cpp
    ${CPPWRF_ROOT}/src/phys/cu_kf/kf.cpp
    ${CPPWRF_ROOT}/src/phys/cu_kf/kf_tables.cpp
    ${CPPWRF_ROOT}/src/core/backend.cpp
  )
  set_source_files_properties(
    driver_kf.cpp
    ${CPPWRF_ROOT}/src/phys/cu_kf/kf.cpp
    ${CPPWRF_ROOT}/src/phys/cu_kf/kf_tables.cpp
    ${CPPWRF_ROOT}/src/core/backend.cpp
    PROPERTIES LANGUAGE CUDA
  )
  target_include_directories(driver_kf_cuda_dp PRIVATE
    ${CPPWRF_ROOT}/src
    ${CMAKE_CURRENT_SOURCE_DIR}
  )
  target_compile_definitions(driver_kf_cuda_dp PRIVATE CPPWRF_USE_CUDA CPPWRF_DOUBLE)
  target_compile_options(driver_kf_cuda_dp PRIVATE --expt-relaxed-constexpr)

  add_executable(driver_kf_cuda_sp
    driver_kf.cpp
    ${CPPWRF_ROOT}/src/phys/cu_kf/kf.cpp
    ${CPPWRF_ROOT}/src/phys/cu_kf/kf_tables.cpp
    ${CPPWRF_ROOT}/src/core/backend.cpp
  )
  set_source_files_properties(
    driver_kf.cpp
    ${CPPWRF_ROOT}/src/phys/cu_kf/kf.cpp
    ${CPPWRF_ROOT}/src/phys/cu_kf/kf_tables.cpp
    ${CPPWRF_ROOT}/src/core/backend.cpp
    PROPERTIES LANGUAGE CUDA
  )
  target_include_directories(driver_kf_cuda_sp PRIVATE
    ${CPPWRF_ROOT}/src
    ${CMAKE_CURRENT_SOURCE_DIR}
  )
  target_compile_definitions(driver_kf_cuda_sp PRIVATE CPPWRF_USE_CUDA)
  target_compile_options(driver_kf_cuda_sp PRIVATE --expt-relaxed-constexpr)
endif()

# 4. CTest entry
find_package(Python3 COMPONENTS Interpreter REQUIRED)
add_test(
  NAME test_phys_cu_kf
  COMMAND ${CMAKE_CURRENT_SOURCE_DIR}/run_test.sh ${CMAKE_CURRENT_BINARY_DIR}
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
)
set_tests_properties(test_phys_cu_kf PROPERTIES LABELS diff SKIP_RETURN_CODE 77)
