#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Unit tests for tools/wrf2cppwrf.py namelist translator.

Tests:
1. Pure Python Fortran namelist tokenizer and parser.
2. Translation and key-by-key comparison against CPPWRF reference configs.
3. Multiple domains detection and warning emission.
4. Error detection on unsupported physics/dynamics options.
5. 2-step model execution under tools/heavy.sh.

The tests of WRF reference runs read ${CPPWRF_WRF_RUNS} and ${CPPWRF_WRF_REF} (defaults as tests/verify/wrf_suite.py:
~/wrf_real480, ~/wrf_ref480) and skip when the files are missing; the model runs also need $CPPWRF_BIN.
"""

import os
import re
import subprocess
import sys
import tempfile
import unittest

# set in the environment: the configurations and the model read ${CPPWRF_WRF_RUNS}
os.environ.setdefault("CPPWRF_WRF_RUNS", os.path.expanduser("~/wrf_real480"))
os.environ.setdefault("CPPWRF_WRF_REF", os.path.expanduser("~/wrf_ref480"))


def wrf_runs_path(rel: str) -> str:
    """Path of a WRF reference run file under ${CPPWRF_WRF_RUNS}."""
    return os.path.join(os.environ["CPPWRF_WRF_RUNS"], rel)


def wrf_ref_path(rel: str) -> str:
    """Path of a WRF ideal-case run file under ${CPPWRF_WRF_REF}."""
    return os.path.join(os.environ["CPPWRF_WRF_REF"], rel)

from typing import Any, Dict, List, Optional

# Add workspace to path
REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, REPO_ROOT)

from tools.wrf2cppwrf import parse_namelist, WrfTranslator, NamelistParseError


CORE_PHYSICS = ("mp_physics", "cu_physics", "ra_lw_physics", "ra_sw_physics", "bl_pbl_physics", "sf_sfclay_physics",
                "sf_surface_physics")


def complete(text: str) -> str:
    """The options a test namelist leaves out and wrf.exe needs: without a physics_suite the seven physics options
    (Registry default -1: wrf.exe stops), diff_opt and km_opt (check_a_mundo stops without them), dx / dy (Registry
    default 200 m: the real case's time-step check and input_wrf's DX check stop wrf.exe). They get WRF's no-physics,
    no-diffusion values, every domain's entry, and 15 km."""
    m = re.search(r"\bmax_dom\s*=\s*(\d+)", text)
    n = int(m.group(1)) if m else 1
    adds = {"physics": [] if "physics_suite" in text else [f"{k} = {n}*0" for k in CORE_PHYSICS
                                                            if not re.search(rf"\b{k}\s*=", text)],
            "dynamics": [f"{k} = {v}" for k, v in (("diff_opt", 0), ("km_opt", 1)) if not re.search(rf"\b{k}\s*=", text)],
            "domains": [f"{k} = 15000" for k in ("dx", "dy") if not re.search(rf"\b{k}\s*=", text)]}
    for grp, items in adds.items():
        if not items:
            continue
        g = re.search(rf"&{grp}\b", text, re.I)
        if g:
            text = text[:g.end()] + " " + ", ".join(items) + "," + text[g.end():]
        else:
            text += f"\n&{grp} " + ", ".join(items) + " /\n"
    return text


def real_case(text: str) -> str:
    """A real-case namelist: domain 1 needs specified = .true. (Registry default .false.; with no condition on a
    side wrf.exe stops in share/module_bc.F boundary_condition_check, and the translator asks for --case); the
    options complete() adds."""
    return complete(text) + "\n&bdy_control specified = .true. /\n"


# real-case keys of the translation that wrf.exe checks against the input file: (namelist group, key, Registry
# default; None: written only when the namelist has it)
REAL_INPUT_CHECKS = {
    ("real", "p_top_requested"): ("domains", "p_top_requested", 5000.0),
    ("real", "iso_temp"): ("dynamics", "iso_temp", 200.0),
    ("real", "dx"): ("domains", "dx", 200.0),
    ("real", "dy"): ("domains", "dy", 200.0),
    ("dyn", "hybrid_opt"): ("dynamics", "hybrid_opt", 2),
    ("real", "e_we"): ("domains", "e_we", 32),
    ("real", "e_sn"): ("domains", "e_sn", 32),
    ("real", "e_vert"): ("domains", "e_vert", 31),
    ("real", "num_land_cat"): ("physics", "num_land_cat", 21),
}


def load_ini_dict(path_or_text: str, is_text: bool = False) -> dict:
    """Parse INI file or text into a dict of {section: {key: value}}."""
    sections = {}
    cur_sec = None
    if is_text:
        lines = path_or_text.splitlines()
    else:
        with open(path_or_text) as f:
            lines = f.readlines()
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            cur_sec = line[1:-1]
            sections[cur_sec] = {}
        elif "=" in line and cur_sec:
            k, v = line.split("=", 1)
            sections[cur_sec][k.strip()] = v.strip()
    return sections


class TestNamelistParser(unittest.TestCase):
    """Test suite for the f90nml-free Fortran namelist parser."""

    def test_basic_parsing(self):
        text = """
        &time_control
         run_days = 0,
         run_hours = 1,
         restart = .false.,
         debug_level = 0
        /
        &domains
         time_step = 60,
         dx = 15000,
         dy = 15000.0,
        /
        """
        nml = parse_namelist(text)
        self.assertIn("time_control", nml)
        self.assertIn("domains", nml)
        self.assertEqual(nml["time_control"]["run_days"], [0])
        self.assertEqual(nml["time_control"]["run_hours"], [1])
        self.assertEqual(nml["time_control"]["restart"], [False])
        self.assertEqual(nml["domains"]["time_step"], [60])
        self.assertEqual(nml["domains"]["dx"], [15000])
        self.assertEqual(nml["domains"]["dy"], [15000.0])

    def test_comments_and_whitespace(self):
        text = """
        ! Top-level comment
        &time_control ! inline comment
         run_days = 2, ! days
         ! full line comment in group
         run_hours = 12
        /
        """
        nml = parse_namelist(text)
        self.assertEqual(nml["time_control"]["run_days"], [2])
        self.assertEqual(nml["time_control"]["run_hours"], [12])

    def test_string_literals(self):
        text = '''
        &io
         filename = 'my_file.nc',
         msg = "Hello, world!",
         nested_quotes = 'It''s fine'
        /
        '''
        nml = parse_namelist(text)
        self.assertEqual(nml["io"]["filename"], ["my_file.nc"])
        self.assertEqual(nml["io"]["msg"], ["Hello, world!"])
        self.assertEqual(nml["io"]["nested_quotes"], ["It's fine"])

    def test_booleans(self):
        text = """
        &flags
         b1 = .true.,
         b2 = .FALSE.,
         b3 = .t.,
         b4 = .f.,
         b5 = T,
         b6 = F
        /
        """
        nml = parse_namelist(text)
        grp = nml["flags"]
        self.assertEqual(grp["b1"], [True])
        self.assertEqual(grp["b2"], [False])
        self.assertEqual(grp["b3"], [True])
        self.assertEqual(grp["b4"], [False])
        self.assertEqual(grp["b5"], [True])
        self.assertEqual(grp["b6"], [False])

    def test_repetition_syntax(self):
        text = """
        &dynamics
         diff_opt = 3*0,
         factors = 2*0.12, 1.0
        /
        """
        nml = parse_namelist(text)
        self.assertEqual(nml["dynamics"]["diff_opt"], [0, 0, 0])
        self.assertEqual(nml["dynamics"]["factors"], [0.12, 0.12, 1.0])

    def test_scientific_notation_and_fortran_d(self):
        text = """
        &floats
         a = 1.0d-4,
         b = 2.5D+02,
         c = 5000.,
         d = .12,
         e = -1.5e-3
        /
        """
        nml = parse_namelist(text)
        grp = nml["floats"]
        self.assertAlmostEqual(grp["a"][0], 1.0e-4)
        self.assertAlmostEqual(grp["b"][0], 250.0)
        self.assertAlmostEqual(grp["c"][0], 5000.0)
        self.assertAlmostEqual(grp["d"][0], 0.12)
        self.assertAlmostEqual(grp["e"][0], -1.5e-3)

    def test_multiple_domains_translation(self):
        text = """
        &time_control
         run_hours = 1,
         history_interval = 10, 10, 10,
         input_from_file = .true., .true., .true.
        /
        &domains
         time_step = 60,
         max_dom = 3,
         e_we = 120, 121, 91,
         e_sn = 90, 91, 61,
         e_vert = 45, 45, 45,
         dx = 15000, 5000, 1000,
         dy = 15000, 5000, 1000,
         parent_id = 0, 1, 2,
         i_parent_start = 1, 40, 30,
         j_parent_start = 1, 30, 20,
         parent_grid_ratio = 1, 3, 5,
         parent_time_step_ratio = 1, 3, 5,
         feedback = 1,
         smooth_option = 2
        /
        &dynamics
         khdif = 0, 0, 10,
         kvdif = 0, 0, 5
        /
        &bdy_control
         specified = .true., .false., .false.,
         nested = .false., .true., .true.
        /
        """
        nml = parse_namelist(complete(text))
        translator = WrfTranslator(nml)
        gen = translator.translate()
        self.assertEqual(translator.errors, [])
        self.assertEqual(translator.warnings, [])
        self.assertEqual(gen["domains"]["max_dom"], 3)
        self.assertEqual(gen["domains"]["feedback"], 1)
        self.assertEqual(gen["domains"]["smooth_option"], 2)
        self.assertEqual(gen["domains"]["i_parent_start"], 40)
        self.assertEqual(gen["domains"]["j_parent_start"], 30)
        self.assertEqual(gen["domains"]["parent_grid_ratio"], 3)
        self.assertEqual(gen["domains"]["parent_time_step_ratio"], 3)
        self.assertEqual(gen["d02"]["wrfinput"], "wrfinput_d02")
        # no [d0N] dt: the model takes the parent's dt / parent_time_step_ratio (20 s, 4 s) as WRF does and
        # refuses another value (src/cases/nest_driver.cpp); the history intervals below are in those steps
        self.assertNotIn("dt", gen["d02"])
        self.assertEqual(gen["d02"]["out_interval"], 30)
        self.assertEqual(gen["d02"]["diag_interval"], 30)
        self.assertEqual(gen["d03"]["parent_id"], 2)
        self.assertEqual(gen["d03"]["i_parent_start"], 30)
        self.assertEqual(gen["d03"]["j_parent_start"], 20)
        self.assertEqual(gen["d03"]["parent_grid_ratio"], 5)
        self.assertEqual(gen["d03"]["parent_time_step_ratio"], 5)
        self.assertEqual(gen["d03"]["wrfinput"], "wrfinput_d03")
        self.assertNotIn("dt", gen["d03"])
        self.assertEqual(gen["d03"]["out_interval"], 150)
        self.assertEqual(gen["d03"]["diag_interval"], 150)
        self.assertEqual(gen["d03"]["khdif"], 10)
        self.assertEqual(gen["d03"]["kvdif"], 5)


class TestRealCasesReproduction(unittest.TestCase):
    """Test suite comparing generated INI against configs/real_*.ini key by key."""

    def _compare_configs(self, nml_rel_path: str, ref_ini_rel_path: str,
                          ignore_keys: Optional[dict] = None, sections: Optional[tuple] = None):
        nml_path = wrf_runs_path(nml_rel_path)
        ref_path = os.path.join(REPO_ROOT, ref_ini_rel_path)
        if not os.path.exists(nml_path):
            self.skipTest(f"Namelist not found: {nml_path}")
        if not os.path.exists(ref_path):
            self.skipTest(f"Reference INI not found: {ref_path}")

        with open(nml_path) as f:
            nml = parse_namelist(f.read())
        translator = WrfTranslator(nml, namelist_path=nml_path)
        gen = translator.translate()
        ref = load_ini_dict(ref_path)
        self.assertEqual(translator.errors, [])

        ignore_keys = {s: set(keys) for s, keys in (ignore_keys or {}).items()}
        if gen["run"]["case"] == "real":
            # namelist values the model checks against wrfinput_d01 as wrf.exe does (start_em.F, input_wrf.F stop
            # when they differ): the namelist's value or the Registry default; the hand-written configs leave them
            # to the input file
            for (sec, key), (grp, nkey, default) in REAL_INPUT_CHECKS.items():
                nvals = nml.get(grp, {}).get(nkey)
                if not nvals and default is None:
                    self.assertNotIn(key, gen.get(sec, {}), f"[{sec}].{key}")
                    continue
                self.assertEqual(float(gen[sec][key]), float(nvals[0] if nvals else default), f"[{sec}].{key}")
                if key not in ref.get(sec, {}):
                    ignore_keys.setdefault(sec, set()).add(key)
        # WRF writes wrfrst files every restart_interval minutes whatever restart is; a hand-written config of a run
        # that ends before the first restart time has no [restart]
        rst = nml.get("time_control", {}).get("restart_interval", [0])[0]
        if rst > 0 and "restart" not in ref:
            self.assertLess(gen["run"]["run_time"], rst * 60)
            self.assertEqual(gen.pop("restart"), {"interval": rst * 60})

        all_secs = sorted(set(list(gen.keys()) + list(ref.keys())))
        if sections:  # only these sections (the hand-written configs add run/output settings)
            all_secs = [x for x in all_secs if x in sections]
        for s in all_secs:
            self.assertIn(s, gen, f"[{s}] missing in generated config")
            self.assertIn(s, ref, f"[{s}] extra in generated config")

            all_keys = sorted(set(list(gen[s].keys()) + list(ref[s].keys())))
            for k in all_keys:
                if ignore_keys and s in ignore_keys and k in ignore_keys[s]:
                    continue
                if sections and (k not in ref[s] or k not in gen[s]):
                    continue  # default values written by one side only
                self.assertIn(k, gen[s], f"[{s}].{k} missing in generated config")
                self.assertIn(k, ref[s], f"[{s}].{k} extra in generated config")

                # Compare normalized string values (treating '20' and '20.0' as equal)
                gv = str(gen[s][k]).replace(" ", "")
                rv = str(ref[s][k]).replace(" ", "")
                if gv != rv and (gv.endswith(".0") or rv.endswith(".0")):
                    try:
                        if float(gv) == float(rv):
                            gv = rv
                    except ValueError:
                        pass
                self.assertEqual(gv, rv, f"[{s}].{k} mismatch: generated '{gen[s][k]}' vs ref '{ref[s][k]}'")

    def test_real_r0_key_by_key(self):
        self._compare_configs("run_R0_r8/namelist.input", "configs/real_r0.ini")

    def test_real_r1_key_by_key(self):
        self._compare_configs("run_R1_r8/namelist.input", "configs/real_r1.ini")

    def test_real_r2_key_by_key(self):
        self._compare_configs("run_R2/namelist.input", "configs/real_r2.ini")

    def test_real_r3_key_by_key(self):
        self._compare_configs("run_R3/namelist.input", "configs/real_r3.ini")

    def test_real_mp6_key_by_key(self):
        self._compare_configs("run_mp6/namelist.input", "configs/real_mp6.ini")

    def test_real_p1_key_by_key(self):
        self._compare_configs("run_P1_r8/steps/namelist.input", "configs/real_p1_r8.ini", sections=("phys", "dyn"))

    def test_real_p2_key_by_key(self):
        self._compare_configs("run_P2_r8/steps/namelist.input", "configs/real_p2_r8.ini", sections=("phys", "dyn"))

    def test_real_p3_key_by_key(self):
        self._compare_configs("run_P3_r8/steps/namelist.input", "configs/real_p3_r8.ini", sections=("phys", "dyn"))

    def test_real_p8_key_by_key(self):
        self._compare_configs("run_P8_r8/steps/namelist.input", "configs/real_p8_r8.ini", sections=("phys", "dyn"))

    def test_real_n1_key_by_key(self):
        self._compare_configs("run_N1/namelist.input", "configs/real_n1.ini", sections=("domains", "d02"))

    def test_real_n2_key_by_key(self):
        self._compare_configs("run_N2/namelist.input", "configs/real_n2.ini", sections=("domains", "d02"))

    def test_real_n1_steps_key_by_key(self):
        self._compare_configs("run_N1_r8/steps/namelist.input", "configs/real_n1_steps.ini", sections=("domains", "d02"))

    def test_real_n2_steps_key_by_key(self):
        self._compare_configs("run_N2_r8/steps/namelist.input", "configs/real_n2_steps.ini", sections=("domains", "d02"))

    def test_real_p4_diff_opt_mapped(self):
        # run_P4 namelist specifies diff_opt = 1, km_opt = 4
        nml_path = wrf_runs_path("run_P4/namelist.input")
        if not os.path.exists(nml_path):
            self.skipTest(f"Namelist not found: {nml_path}")
        with open(nml_path) as f:
            nml = parse_namelist(f.read())
        t = WrfTranslator(nml, namelist_path=nml_path)
        gen = t.translate()
        self.assertEqual(gen["dyn"].get("diff_opt"), 1)
        self.assertEqual(gen["dyn"].get("km_opt"), 4)
        self.assertEqual(gen["phys"].get("mp_physics"), 6)


class TestIdealCases(unittest.TestCase):
    """Test suite for ideal cases translation."""

    def test_hill2d_mapping(self):
        nml_path = wrf_ref_path("run_hill_p0/namelist.input")
        if not os.path.exists(nml_path):
            self.skipTest(f"Namelist not found: {nml_path}")
        with open(nml_path) as f:
            nml = parse_namelist(f.read())
        t = WrfTranslator(nml, namelist_path=nml_path)
        gen = t.translate()
        self.assertEqual(gen["run"]["case"], "em_hill2d_x")
        self.assertEqual(gen["domain"]["nx"], 201)
        self.assertEqual(gen["domain"]["ny"], 1)
        self.assertEqual(gen["domain"]["nz"], 40)
        self.assertEqual(gen["domain"]["dx"], 2000)
        self.assertEqual(gen["time"]["dt"], 20)
        self.assertEqual(gen["time"]["time_step_sound"], 6)

    def test_quarter_ss_mapping(self):
        nml_path = wrf_ref_path("run_qss/namelist.input")
        if not os.path.exists(nml_path):
            self.skipTest(f"Namelist not found: {nml_path}")
        with open(nml_path) as f:
            nml = parse_namelist(f.read())
        t = WrfTranslator(nml, namelist_path=nml_path)
        gen = t.translate()
        self.assertEqual(gen["run"]["case"], "em_quarter_ss")
        self.assertEqual(gen["domain"]["nx"], 41)
        self.assertEqual(gen["domain"]["ny"], 41)
        self.assertEqual(gen["domain"]["nz"], 40)
        self.assertEqual(gen["time"]["dt"], 12)
        self.assertEqual(gen["time"]["time_step_sound"], 6)

    def test_straka_mapping(self):
        nml_path = wrf_ref_path("run_straka_d1/namelist.input")
        if not os.path.exists(nml_path):
            self.skipTest(f"Namelist not found: {nml_path}")
        with open(nml_path) as f:
            nml = parse_namelist(f.read())
        t = WrfTranslator(nml, namelist_path=nml_path)
        gen = t.translate()
        self.assertEqual(gen["run"]["case"], "em_grav2d_x")
        self.assertEqual(gen["domain"]["nx"], 512)
        self.assertEqual(gen["domain"]["ny"], 1)
        self.assertEqual(gen["domain"]["nz"], 64)
        self.assertEqual(gen["time"]["dt"], 1)
        self.assertEqual(gen["time"]["time_step_sound"], 6)

    def test_wrf_ideal_case_names_and_keys(self):
        # Every WRF ideal_case that CPPWRF ports maps to the src/cases/wrf_ideal.cpp case name; the
        # sounding is the input_sounding next to the namelist; hybrid_opt = 0 is kept (the model's
        # default is 2); open_xs/open_xe give bc_x = open.
        tmp = tempfile.mkdtemp()
        nml_path = os.path.join(tmp, "namelist.input")
        expected = {1: "em_hill2d_x", 2: "em_quarter_ss", 4: "em_squall2d_x", 5: "em_squall2d_y", 6: "em_grav2d_x"}
        for ideal_case, name in expected.items():
            text = f"""
            &time_control run_minutes = 10 /
            &domains time_step = 3, e_we = 202, e_sn = 3, e_vert = 81, dx = 250, dy = 250, ztop = 20000 /
            &dynamics hybrid_opt = 0 /
            &bdy_control periodic_x = .false., open_xs = .true., open_xe = .true., periodic_y = .true. /
            &ideal ideal_case = {ideal_case} /
            """
            t = WrfTranslator(parse_namelist(complete(text)), namelist_path=nml_path)
            gen = t.translate()
            self.assertEqual(t.errors, [], msg=f"ideal_case = {ideal_case}")
            self.assertEqual(gen["run"]["case"], name)
            self.assertEqual(gen["case"]["sounding_file"], os.path.join(tmp, "input_sounding"))
            self.assertEqual(gen["dyn"]["hybrid_opt"], 0)
            self.assertEqual(gen["domain"]["bc_x"], "open")
            self.assertEqual(gen["domain"]["dy"], 250)
            # no damp_opt in the namelist: WRF's Registry default 3 (the model's own default is 0)
            self.assertEqual(gen["dyn"]["damp_opt"], 3)


class TestValidationAndWarnings(unittest.TestCase):
    """Test error and warning detection on unsupported/deviating options."""

    def test_unsupported_mp_physics(self):
        text = """
        &time_control /
        &domains time_step = 60 /
        &physics mp_physics = 2 /
        &dynamics /
        """
        nml = parse_namelist(real_case(text))
        t = WrfTranslator(nml)
        t.translate()
        self.assertTrue(any("mp_physics = 2" in e for e in t.errors), t.errors)

    def test_unsupported_diff_opt(self):
        text = """
        &time_control /
        &domains time_step = 60 /
        &dynamics diff_opt = 3 /
        """
        nml = parse_namelist(real_case(text))
        t = WrfTranslator(nml)
        t.translate()
        self.assertTrue(any("diff_opt = 3" in e for e in t.errors), t.errors)

    def test_hydrostatic_error(self):
        text = """
        &time_control /
        &domains time_step = 60 /
        &dynamics non_hydrostatic = .false. /
        """
        nml = parse_namelist(real_case(text))
        t = WrfTranslator(nml)
        t.translate()
        self.assertTrue(any("non_hydrostatic = .false." in e for e in t.errors))

    def test_noahmp_mapping(self):
        text = """
        &time_control /
        &domains time_step = 60 /
        &physics sf_sfclay_physics = 1, sf_surface_physics = 4, bl_pbl_physics = 1 /
        &noah_mp dveg = 4, opt_runsrf = 3, opt_runsub = 3 /
        &dynamics /
        """
        nml = parse_namelist(real_case(text))
        t = WrfTranslator(nml)
        gen = t.translate()
        self.assertEqual(t.warnings, [])
        self.assertEqual(t.errors, [])
        self.assertEqual(gen["phys"]["sf_surface_physics"], 4)
        self.assertEqual(gen["phys"]["num_soil_layers"], 4)
        self.assertEqual(gen["phys"]["dveg"], 4)
        self.assertEqual(gen["phys"]["opt_runsrf"], 3)
        self.assertEqual(gen["phys"]["opt_runsub"], 3)

    def test_extended_physics_options_mapping(self):
        text = """
        &time_control /
        &domains time_step = 60 /
        &physics
         mp_physics = 6,
         mp_tend_lim = 5.0,
         hail_opt = 1,
         use_mp_re = 0,
         sf_sfclay_physics = 1,
         sf_surface_physics = 2,
         num_soil_layers = 4,
         bl_pbl_physics = 1,
         ysu_topdown_pblmix = 0,
         cu_physics = 3,
         ishallow = 1,
         clos_choice = 2,
         kfeta_trigger = 3,
         convtrans_avglen_m = 45.0,
         ra_lw_physics = 4,
         ra_sw_physics = 4,
         radt = 10,
         icloud = 0,
         cldovrlp = 4,
         idcor = 1,
         o3input = 0,
         ghg_input = 0,
         aer_opt = 0,
         rdmaxalb = .false.,
         opt_thcnd = 2,
         kim_tofd = .true.,
         tofd_factor = 0.005
        /
        &dynamics /
        """
        nml = parse_namelist(real_case(text))
        t = WrfTranslator(nml)
        gen = t.translate()
        self.assertEqual(t.errors, [])
        p = gen["phys"]
        self.assertEqual(p["mp_tend_lim"], 5.0)
        self.assertEqual(p["hail_opt"], 1)
        self.assertEqual(p["use_mp_re"], 0)
        self.assertEqual(p["num_soil_layers"], 4)
        self.assertEqual(p["ysu_topdown_pblmix"], 0)
        self.assertEqual(p["ishallow"], 1)
        self.assertEqual(p["clos_choice"], 2)
        self.assertEqual(p["kfeta_trigger"], 3)
        self.assertEqual(p["convtrans_avglen_m"], 45.0)
        self.assertEqual(p["icloud"], 0)
        self.assertEqual(p["cldovrlp"], 4)
        self.assertEqual(p["idcor"], 1)
        self.assertEqual(p["o3input"], 0)
        self.assertEqual(p["ghg_input"], 0)
        self.assertEqual(p["rdmaxalb"], False)
        self.assertEqual(p["opt_thcnd"], 2)
        self.assertEqual(p["kim_tofd"], True)
        self.assertEqual(p["tofd_factor"], 0.005)

    def test_do_radar_ref(self):
        # do_radar_ref 1: REFL_10CM of WSM6 and Thompson at history steps; 0 (default) is not written; other values
        # are rejected
        def translate(value):
            t = WrfTranslator(parse_namelist(real_case(f"""
            &time_control /
            &domains time_step = 60 /
            &physics mp_physics = 6, do_radar_ref = {value} /
            &dynamics /
            """)))
            return t, t.translate()
        t, gen = translate(1)
        self.assertEqual(t.errors, [])
        self.assertEqual(gen["phys"]["do_radar_ref"], 1)
        t, gen = translate(0)
        self.assertEqual(t.errors, [])
        self.assertNotIn("do_radar_ref", gen["phys"])
        t, _ = translate(2)
        self.assertTrue(any("do_radar_ref = 2 is not supported" in e for e in t.errors), t.errors)

    def test_usemonalb_rdlai2d(self):
        # usemonalb: landuse_init for every LSM; rdlai2d: Noah only (Noah-MP and no LSM ignore it)
        def phys(extra):
            t = WrfTranslator(parse_namelist(real_case(f"""
            &time_control /
            &domains time_step = 60 /
            &physics {extra} /
            &dynamics /
            """)))
            gen = t.translate()
            self.assertEqual(t.errors, [], extra)
            return gen.get("phys", {})
        p = phys("sf_sfclay_physics = 1, sf_surface_physics = 2, bl_pbl_physics = 1, usemonalb = .true., rdlai2d = .true.")
        self.assertEqual((p["usemonalb"], p["rdlai2d"]), (True, True))
        p = phys("sf_sfclay_physics = 1, sf_surface_physics = 4, bl_pbl_physics = 1, usemonalb = .true., rdlai2d = .true.")
        self.assertEqual(p["usemonalb"], True)
        self.assertNotIn("rdlai2d", p)
        p = phys("sf_sfclay_physics = 1, sf_surface_physics = 2, bl_pbl_physics = 1, usemonalb = .false., rdlai2d = .false.")
        self.assertNotIn("usemonalb", p)
        self.assertNotIn("rdlai2d", p)
        p = phys("usemonalb = .true.")
        self.assertEqual(p["usemonalb"], True)

    def test_slab_lsm(self):
        # sf_surface_physics = 1 (module_sf_slab.F): 5 soil layers (the Registry default), ifsnow 1 (default) or 0
        def phys(extra):
            t = WrfTranslator(parse_namelist(real_case(f"""
            &time_control /
            &domains time_step = 60 /
            &physics sf_sfclay_physics = 1, sf_surface_physics = 1, bl_pbl_physics = 1{extra} /
            &dynamics /
            """)))
            gen = t.translate()
            return t.errors, gen.get("phys", {})
        err, p = phys("")
        self.assertEqual(err, [])
        self.assertEqual((p["sf_surface_physics"], p["num_soil_layers"]), (1, 5))
        self.assertNotIn("ifsnow", p)
        err, p = phys(", num_soil_layers = 5, ifsnow = 0")
        self.assertEqual(err, [])
        self.assertEqual(p["ifsnow"], 0)
        for extra, msg in ((", num_soil_layers = 4", "num_soil_layers = 4"), (", ifsnow = 2", "ifsnow = 2"),
                           (", fractional_seaice = 1", "fractional_seaice = 1"),
                           (", sst_update = 1", "sst_update = 1 with sf_surface_physics = 1")):
            err, _ = phys(extra)
            self.assertIn(msg, " ".join(err), extra)

    def test_acm2_pleim_xiu(self):
        # bl_pbl_physics = 7 (module_bl_acm.F) over sf_sfclay_physics = 1 or 7 (module_physics_init: 'use sfclay or
        # pxsfc scheme for this pbl option'), with qc and qi; the Pleim-Xiu surface layer with ACM2 and Noah; the PX
        # land surface (sf_surface_physics = 7) is not ported
        def phys(sfc, pbl, extra="", mp=6, lsm=2):
            t = WrfTranslator(parse_namelist(real_case(f"""
            &time_control /
            &domains time_step = 60 /
            &physics mp_physics = {mp}, sf_sfclay_physics = {sfc}, sf_surface_physics = {lsm}, bl_pbl_physics = {pbl}{extra} /
            &dynamics /
            """)))
            gen = t.translate()
            return t.errors, gen.get("phys", {})
        for sfc in (1, 7):
            err, p = phys(sfc, 7)
            self.assertEqual(err, [])
            self.assertEqual((p["sf_sfclay_physics"], p["bl_pbl_physics"]), (sfc, 7))
        err, p = phys(7, 7, ", bldt = 3")
        self.assertEqual((err, p["bldt"]), ([], 3))
        for args, msg in (((2, 7), "needs sf_sfclay_physics = 1 or 7"), ((5, 7), "needs sf_sfclay_physics = 1 or 7"),
                          ((7, 1), "sf_sfclay_physics = 7 (Pleim-Xiu) is supported with"),
                          ((7, 0), "sf_sfclay_physics = 7 (Pleim-Xiu) is supported with"),
                          ((7, 7, "", 1), "needs a microphysics with qc and qi"),
                          ((1, 7, "", 0), "needs a microphysics with qc and qi"),
                          ((7, 7, "", 6, 4), "sf_sfclay_physics = 7 (Pleim-Xiu) is supported with"),
                          ((7, 7, ", fractional_seaice = 1"), "fractional_seaice = 1"),
                          ((7, 7, ", isfflx = 0"), "sf_sfclay_physics = 7 with isfflx = 0"),
                          ((7, 7, ", num_soil_layers = 2", 6, 7), "sf_surface_physics = 7 (Pleim-Xiu land surface")):
            err, _ = phys(*args)
            self.assertIn(msg, " ".join(err), args)

    def test_morrison_two_moment(self):
        # mp_physics = 10 (module_mp_morr_two_moment.F): moist qv qc qr qi qs qg and scalar qni qns qnr qng (Registry
        # package morr_two_moment); morr_rimed_ice = 1 (default, hail) or graupel for any other value; not ported:
        # mp_physics = 40, progn = 1, do_radar_ref = 1 with Morrison, the ideal cases
        def tr(extra="", mp=10, case=real_case, cu=1):
            t = WrfTranslator(parse_namelist(case(f"""
            &time_control /
            &domains time_step = 60 /
            &physics mp_physics = {mp}, sf_sfclay_physics = 1, sf_surface_physics = 2, bl_pbl_physics = 1,
                     cu_physics = {cu}{extra} /
            &dynamics /
            """)))
            gen = t.translate()
            return t, gen
        t, g = tr()
        self.assertEqual(t.errors, [])
        self.assertEqual(g["moist"]["species"], "qv,qc,qr,qi,qs,qg,qni,qns,qnr,qng")
        self.assertEqual(g["phys"]["mp_physics"], 10)
        self.assertNotIn("morr_rimed_ice", g["phys"])
        for v, note in (("0", False), ("2", True)):
            t, g = tr(f", morr_rimed_ice = {v}", cu=0)
            self.assertEqual(t.errors, [], v)
            self.assertEqual(g["phys"]["morr_rimed_ice"], 0, v)
            self.assertEqual(any("graupel" in n for n in t.notices), note, v)
        t, g = tr(", morr_rimed_ice = 0", mp=6)  # read by Morrison only
        self.assertEqual(t.errors, [])
        self.assertNotIn("morr_rimed_ice", g["phys"])
        for args, msg in (((", do_radar_ref = 1",), "do_radar_ref = 1 with mp_physics = 10"),
                          ((", progn = 1",), "progn = [1]"),
                          (("", 40), "mp_physics = 40 (Morrison with aerosols"),
                          ((", progn = 1", 6), "progn = [1]")):
            t, _ = tr(*args)
            self.assertIn(msg, " ".join(t.errors), args)
        t = WrfTranslator(parse_namelist(complete("&time_control /\n&domains time_step = 6 /\n"
                                                   "&physics mp_physics = 10 /\n")), override_case="quarter_ss")
        t.translate()
        self.assertIn("mp_physics = 10 (Morrison two-moment) is supported for real-data runs only", " ".join(t.errors))

    def test_force_read_thompson(self):
        def phys(mp, extra):
            t = WrfTranslator(parse_namelist(real_case(f"""
            &time_control /
            &domains time_step = 60 /
            &physics mp_physics = {mp}, {extra} /
            &dynamics /
            """)))
            gen = t.translate()
            self.assertEqual(t.errors, [])
            self.assertFalse([w for w in t.warnings if "thompson" in w])
            return gen["phys"]
        self.assertTrue(phys(8, "force_read_thompson = .true.")["force_read_thompson"])
        self.assertNotIn("force_read_thompson", phys(8, "force_read_thompson = .false."))
        self.assertNotIn("force_read_thompson", phys(6, "force_read_thompson = .true."))  # read only by Thompson
        self.assertNotIn("write_thompson_tables", phys(8, "write_thompson_tables = .false."))

    def test_thompson_aerosol_aware(self):
        """mp_physics = 28 with aer_init_opt = 0: the thompsonaero scalars, wif_input_opt 0 / 1, grav_settling reset to 0
        (check_a_mundo); wif_input_opt = 2, use_aero_icbc, use_rap_aero_icbc, qna_update, dust_emis, MYNN and nests
        are errors."""
        def tr(extra, domains="", case=real_case):
            t = WrfTranslator(parse_namelist(case(f"&time_control /\n&domains time_step = 60{domains} /\n"
                                                  f"&physics mp_physics = 28{extra} /\n&dynamics /\n")))
            return t, t.translate()
        t, gen = tr(", sf_sfclay_physics = 1, sf_surface_physics = 2, bl_pbl_physics = 1, grav_settling = 1",
                    ", wif_input_opt = 1")
        self.assertEqual(t.errors, [])
        self.assertEqual(gen["moist"]["species"], "qv,qc,qr,qi,qs,qg,qni,qnr,qnc,qnwfa,qnifa,qnbca")
        self.assertEqual((gen["phys"]["mp_physics"], gen["phys"]["wif_input_opt"]), (28, 1))
        self.assertNotIn("grav_settling", gen["phys"])
        self.assertTrue(any("grav_settling" in n and "reset to 0" in n for n in t.notices), t.notices)
        t, gen = tr(", force_read_thompson = .true.")
        self.assertEqual(t.errors, [])
        self.assertTrue(gen["phys"]["force_read_thompson"])
        self.assertNotIn("wif_input_opt", gen["phys"])
        for extra, domains, err in ((", sf_sfclay_physics = 1, bl_pbl_physics = 5", "", "bl_mynn_mixaerosols"),
                                    ("", ", wif_input_opt = 2", "wif_input_opt = 2"),
                                    (", use_aero_icbc = .true.", "", "use_aero_icbc"),
                                    (", use_rap_aero_icbc = .true.", "", "use_rap_aero_icbc"),
                                    (", qna_update = 1", "", "qna_update"),
                                    (", dust_emis = 1", "", "dust_emis")):
            t, _ = tr(extra, domains)
            self.assertIn(err, " ".join(t.errors), (extra, domains))
        # wif_input_opt is read only by the aerosol-aware schemes
        t = WrfTranslator(parse_namelist(real_case("&time_control /\n&domains time_step = 60, wif_input_opt = 1 /\n"
                                                   "&physics mp_physics = 8 /\n&dynamics /\n")))
        t.translate()
        self.assertEqual(t.errors, [])

    def test_opt_thcnd(self):
        base = """
        &time_control /
        &domains time_step = 60 /
        &physics sf_sfclay_physics = 1, sf_surface_physics = 2, num_soil_layers = 4, bl_pbl_physics = 1,
         opt_thcnd = {} /
        &dynamics /
        """
        t = WrfTranslator(parse_namelist(real_case(base.format(2))))
        gen = t.translate()
        self.assertEqual(t.errors, [])
        self.assertEqual(gen["phys"]["opt_thcnd"], 2)
        t = WrfTranslator(parse_namelist(real_case(base.format(1))))
        gen = t.translate()
        self.assertEqual(t.errors, [])
        self.assertNotIn("opt_thcnd", gen["phys"])
        t = WrfTranslator(parse_namelist(real_case(base.format(3))))
        t.translate()
        self.assertTrue(any("opt_thcnd = 3" in e for e in t.errors))

    def test_unported_dynamics_switches_rejected(self):
        for key, val in (("diff_6th_slopeopt", "1"), ("sfs_opt", "1"), ("m_opt", "1"), ("tracer_mix6_off", ".true.")):
            text = f"&time_control /\n&domains time_step = 60 /\n&physics /\n&dynamics {key} = {val} /\n"
            t = WrfTranslator(parse_namelist(real_case(text)))
            t.translate()
            self.assertTrue(any(key in e for e in t.errors), key)
        t = WrfTranslator(parse_namelist(real_case("&time_control /\n&domains time_step = 60 /\n&physics /\n&dynamics sfs_opt = 0 /\n")))
        t.translate()
        self.assertEqual(t.errors, [])

    def test_seaice_parameters_rejected(self):
        text = """
        &time_control /
        &domains time_step = 60 /
        &physics sf_sfclay_physics = 1, sf_surface_physics = 2, num_soil_layers = 4, bl_pbl_physics = 1,
         seaice_albedo_default = {} /
        &dynamics /
        """
        t = WrfTranslator(parse_namelist(real_case(text.format(0.65))))
        t.translate()
        self.assertEqual(t.errors, [])
        t = WrfTranslator(parse_namelist(real_case(text.format(0.8))))
        t.translate()
        self.assertTrue(any("seaice_albedo_default = 0.8" in e for e in t.errors))

    def test_extended_dynamics_options_mapping(self):
        text = """
        &time_control /
        &domains time_step = 60 /
        &dynamics
         diff_opt = 2,
         km_opt = 2,
         c_s = 0.18,
         c_k = 0.12,
         mix_isotropic = 1,
         mix_upper_bound = 0.2,
         mix_full_fields = .true.,
         tke_drag_coefficient = 0.01,
         tke_heat_flux = 0.05,
         tke_upper_bound = 500.0,
         moist_mix2_off = .true.,
         scalar_mix2_off = .true.,
         tke_mix2_off = .true.,
         moist_mix6_off = .true.,
         scalar_mix6_off = .true.,
         tke_mix6_off = .true.,
         w_damping = 1,
         w_crit_cfl = 1.2,
         scalar_adv_opt = 0,
         tke_adv_opt = 0,
         epssm = 0.2,
         smdiv = 0.15,
         emdiv = 0.02,
         etac = 0.25
        /
        """
        nml = parse_namelist(real_case(text))
        t = WrfTranslator(nml)
        gen = t.translate()
        self.assertEqual(t.errors, [])
        d = gen["dyn"]
        self.assertEqual(d["c_s"], 0.18)
        self.assertEqual(d["c_k"], 0.12)
        self.assertEqual(d["mix_isotropic"], 1)
        self.assertEqual(d["mix_upper_bound"], 0.2)
        self.assertEqual(d["mix_full_fields"], True)
        self.assertEqual(d["tke_drag_coefficient"], 0.01)
        self.assertEqual(d["tke_heat_flux"], 0.05)
        self.assertEqual(d["tke_upper_bound"], 500.0)
        self.assertEqual(d["moist_mix2_off"], True)
        self.assertEqual(d["scalar_mix2_off"], True)
        self.assertEqual(d["tke_mix2_off"], True)
        self.assertEqual(d["moist_mix6_off"], True)
        self.assertEqual(d["scalar_mix6_off"], True)
        self.assertEqual(d["tke_mix6_off"], True)
        self.assertEqual(d["w_crit_cfl"], 1.2)
        self.assertEqual(d["scalar_adv_opt"], 0)
        self.assertEqual(d["tke_adv_opt"], 0)
        self.assertEqual(d["epssm"], 0.2)
        self.assertEqual(d["smdiv"], 0.15)
        self.assertEqual(d["emdiv"], 0.02)
        self.assertEqual(d["etac"], 0.25)

    def test_physics_suite_conus(self):
        """WRF's default test/em_real namelist: physics_suite CONUS, -1 options, gwd_opt and fractional_seaice."""
        text = ("&time_control /\n&domains time_step = 90, max_dom = 1 /\n"
                "&physics physics_suite = 'CONUS', mp_physics = -1, cu_physics = -1, ra_lw_physics = -1,\n"
                " ra_sw_physics = -1, bl_pbl_physics = -1, sf_sfclay_physics = -1, sf_surface_physics = -1,\n"
                " radt = 15, fractional_seaice = 1 /\n&dynamics gwd_opt = 1, diff_opt = 2, km_opt = 4 /\n")
        t = WrfTranslator(parse_namelist(real_case(text)))
        sec = t.translate()
        self.assertEqual(t.errors, [])
        expect = {"mp_physics": 8, "cu_physics": 6, "ra_lw_physics": 4, "ra_sw_physics": 4, "bl_pbl_physics": 2,
                  "sf_sfclay_physics": 2, "sf_surface_physics": 2, "fractional_seaice": 1}
        for k, v in expect.items():
            self.assertEqual(sec["phys"][k], v, k)
        self.assertEqual(sec["dyn"]["gwd_opt"], 1)

    def test_sst_update(self):
        """sst_update = 1: the auxinput4 interval and a custom wrflowinp name."""
        text = ("&time_control auxinput4_inname = 'lowinp_d<domain>', auxinput4_interval = 180,\n"
                " io_form_auxinput4 = 2 /\n&domains time_step = 60 /\n&physics sst_update = 1, mp_physics = 6, sf_sfclay_physics = 1,\n"
                " sf_surface_physics = 2, bl_pbl_physics = 1 /\n")
        t = WrfTranslator(parse_namelist(real_case(text)))
        sec = t.translate()
        self.assertEqual(t.errors, [])
        self.assertEqual(sec["phys"]["sst_update"], 1)
        self.assertEqual(sec["phys"]["auxinput4_interval"], 180)
        self.assertEqual(sec["real"]["wrflowinp"], "lowinp_d01")

    def test_sst_skin_tmn_update(self):
        """sst_skin = 1 and tmn_update = 1 (with lagday) with Noah; the other LSMs, lagday = 1, values other than 0 / 1
        and the adaptive time step are errors; lagday without tmn_update stays an unported option."""
        base = ("&time_control /\n&domains time_step = 60 /\n&physics mp_physics = 6, sf_sfclay_physics = 1,\n"
                " sf_surface_physics = {lsm}, bl_pbl_physics = 1, {opts} /\n")
        t = WrfTranslator(parse_namelist(real_case(base.format(lsm=2, opts="sst_skin = 1, tmn_update = 1"))))
        sec = t.translate()
        self.assertEqual(t.errors, [])
        self.assertEqual(sec["phys"]["sst_skin"], 1)
        self.assertEqual(sec["phys"]["tmn_update"], 1)
        self.assertNotIn("lagday", sec["phys"])
        t = WrfTranslator(parse_namelist(real_case(base.format(lsm=2, opts="tmn_update = 1, lagday = 5"))))
        sec = t.translate()
        self.assertEqual(t.errors, [])
        self.assertEqual(sec["phys"]["lagday"], 5)
        self.assertNotIn("sst_skin", sec["phys"])
        for lsm, opts, err in ((4, "sst_skin = 1", "sst_skin = 1 is supported with sf_surface_physics = 2"),
                               (1, "tmn_update = 1", "tmn_update = 1 is supported with sf_surface_physics = 2"),
                               (2, "tmn_update = 1, lagday = 1", "requires lagday=150"),
                               (2, "sst_skin = 2", "sst_skin = 2 is not supported"),
                               (2, "lagday = 5", "lagday = [5] is not supported")):
            t = WrfTranslator(parse_namelist(real_case(base.format(lsm=lsm, opts=opts))))
            t.translate()
            self.assertIn(err, " ".join(t.errors), f"{lsm} {opts}: {t.errors}")

    def test_physics_suite_tropical_keeps_explicit_values(self):
        text = ("&time_control /\n&domains time_step = 60 /\n"
                "&physics physics_suite = 'tropical', cu_physics = 1 /\n")
        t = WrfTranslator(parse_namelist(real_case(text)))
        sec = t.translate()
        self.assertEqual(t.errors, [])
        self.assertEqual(sec["phys"]["mp_physics"], 6)
        self.assertEqual(sec["phys"]["cu_physics"], 1)
        self.assertEqual(sec["phys"]["bl_pbl_physics"], 1)
        self.assertEqual(sec["phys"]["sf_sfclay_physics"], 1)

    def test_physics_suite_errors(self):
        for fragment, expected_err in [
                ("&physics mp_physics = -1 /", "needs a physics_suite"),
                ("&physics physics_suite = 'arctic' /", "not recognized"),
                ("&dynamics gwd_opt = 3 /", "gwd_opt = 3"),
                ("&physics sf_sfclay_physics = 1, sf_surface_physics = 2, fractional_seaice = 2 /",
                 "fractional_seaice = 2"),
                ("&physics sf_sfclay_physics = 1, sf_surface_physics = 2, bl_pbl_physics = 2 /",
                 "use myjsfc scheme"),
                ("&physics sf_sfclay_physics = 2, sf_surface_physics = 2, bl_pbl_physics = 1 /",
                 "use sfclay scheme"),
                ("&physics sf_sfclay_physics = 2, sf_surface_physics = 2, bl_pbl_physics = 2, isfflx = 0 /",
                 "uninitialised memory")]:
            t = WrfTranslator(parse_namelist(real_case(f"&time_control /\n&domains time_step = 60 /\n{fragment}\n")))
            t.translate()
            self.assertIn(expected_err, " ".join(t.errors), fragment)

    def test_nest_gwd_opt_equal_or_zero(self):
        """check_a_mundo: a nest's gwd_opt is domain 1's or 0."""
        doms = ("&domains time_step = 60, max_dom = 2, e_we = 100, 61, e_sn = 100, 61, e_vert = 45, 45,"
                " parent_id = 0, 1, i_parent_start = 1, 30, j_parent_start = 1, 30,"
                " parent_grid_ratio = 1, 3, parent_time_step_ratio = 1, 3 /\n")
        for gwd, bad in (("0, 1", True), ("1, 0", False), ("1", False), ("1, 1", False)):
            t = WrfTranslator(parse_namelist(f"&time_control /\n{doms}&dynamics gwd_opt = {gwd} /\n"))
            t.translate()
            self.assertEqual(any("gwd_opt must be equal for all domains" in e for e in t.errors), bad, gwd)

    def test_nest_mynn_options_checked_on_every_domain(self):
        """sf_mynn_sfcflux_land / _water are max_domains options: CPPWRF needs one value on all domains; the GFS
        forms (land 4, water 5) are not ported."""
        doms = ("&domains time_step = 60, max_dom = 2, e_we = 100, 61, e_sn = 100, 61, e_vert = 45, 45,"
                " parent_id = 0, 1, i_parent_start = 1, 30, j_parent_start = 1, 30,"
                " parent_grid_ratio = 1, 3, parent_time_step_ratio = 1, 3 /\n")
        phys = "mp_physics = 6, 6, sf_sfclay_physics = 5, 5, sf_surface_physics = 2, 2, bl_pbl_physics = 5, 5"
        for opt, bad in (("sf_mynn_sfcflux_water = 1, 0", True), ("sf_mynn_sfcflux_water = 1, 1", False),
                         ("sf_mynn_sfcflux_water = 1", False), ("sf_mynn_sfcflux_land = 0, 2", True),
                         ("sf_mynn_sfcflux_land = 0", False), ("sf_mynn_sfcflux_water = 0, 0", False),
                         ("sf_mynn_sfcflux_land = 2, 2", False), ("sf_mynn_sfcflux_water = 2*5", True),
                         ("sf_mynn_sfcflux_land = 2*4", True)):
            t = WrfTranslator(parse_namelist(real_case(f"&time_control /\n{doms}&physics {phys}, {opt} /\n")))
            t.translate()
            self.assertEqual(any("sf_mynn_sfcflux" in e for e in t.errors), bad, (opt, t.errors))

    def test_mynn_pbl_surface_layers(self):
        """module_physics_init.F pbl_init: the MYNN PBL runs with sf_sfclay_physics 5, 1 or 2 and stops otherwise;
        CPPWRF rejects it with fractional_seaice = 1 (sfclayrev / MYJSFC sea-ice wrappers not verified with MYNN)."""
        for sf, extra, err in (("1", "", None), ("2", "", None), ("5", "", None),
                               ("0", "", "needs sf_sfclay_physics = 1, 2 or 5"),
                               ("1", ", fractional_seaice = 1", "fractional_seaice = 1 is not supported"),
                               ("2", ", fractional_seaice = 1", "fractional_seaice = 1 is not supported")):
            phys = f"&physics mp_physics = 8, sf_sfclay_physics = {sf}, sf_surface_physics = 2, bl_pbl_physics = 5{extra} /"
            t = WrfTranslator(parse_namelist(real_case(f"&time_control /\n&domains time_step = 60 /\n{phys}\n")))
            cfg = t.translate()
            if err is None:
                self.assertEqual(t.errors, [], (sf, extra))
                self.assertEqual((cfg["phys"]["bl_pbl_physics"], cfg["phys"]["sf_sfclay_physics"]), (5, int(sf)))
            else:
                self.assertIn(err, " ".join(t.errors), (sf, extra))

    def test_dudhia_shortwave(self):
        # RRTMG LW with Dudhia SW (module_ra_sw.F); swrad_scat (swinit) only with Dudhia
        for extra, scat in (("", None), (", swrad_scat = 0.5", 0.5)):
            phys = f"&physics ra_lw_physics = 4, ra_sw_physics = 1, radt = 15, sf_sfclay_physics = 1{extra} /"
            t = WrfTranslator(parse_namelist(real_case(f"&time_control /\n&domains time_step = 60 /\n{phys}\n")))
            cfg = t.translate()
            self.assertEqual(t.errors, [], extra)
            self.assertEqual((cfg["phys"]["ra_lw_physics"], cfg["phys"]["ra_sw_physics"]), (4, 1))
            self.assertEqual(cfg["phys"].get("swrad_scat"), scat)
        phys = "&physics ra_lw_physics = 4, ra_sw_physics = 4, sf_sfclay_physics = 1, swrad_scat = 0.5 /"
        t = WrfTranslator(parse_namelist(real_case(f"&time_control /\n&domains time_step = 60 /\n{phys}\n")))
        cfg = t.translate()
        self.assertEqual(t.errors, [])
        self.assertNotIn("swrad_scat", cfg["phys"])

    def test_rrtm_longwave(self):
        # RRTM LW (module_ra_rrtm.F) with RRTMG or Dudhia SW
        for sw in (4, 1):
            phys = f"&physics ra_lw_physics = 1, ra_sw_physics = {sw}, radt = 15, sf_sfclay_physics = 1 /"
            t = WrfTranslator(parse_namelist(real_case(f"&time_control /\n&domains time_step = 60 /\n{phys}\n")))
            cfg = t.translate()
            self.assertEqual(t.errors, [], sw)
            self.assertEqual((cfg["phys"]["ra_lw_physics"], cfg["phys"]["ra_sw_physics"]), (1, sw))

    def test_unsupported_physics_and_dynamics_errors(self):
        cases = [
            # share/module_check_a_mundo.F: "bl_mynn_edmf > 0 requires both shcu_physics=0 & ishallow=0"
            ("&physics mp_physics = 6, sf_sfclay_physics = 5, bl_pbl_physics = 5, ishallow = 1 /",
             "requires shcu_physics = 0 and ishallow = 0"),
            ("&physics cu_physics = 3, clos_choice = 99 /", "clos_choice = 99"),
            ("&physics cu_physics = 1, kfeta_trigger = 2 /", "kfeta_trigger = 2"),
            ("&physics sf_surface_physics = 2, num_soil_layers = 5 /", "num_soil_layers = 5"),
            ("&physics sf_surface_physics = 4, opt_crop = 1 /", "opt_crop = 1"),
            ("&physics ra_lw_physics = 4, ra_sw_physics = 0 /", "a longwave scheme needs a shortwave scheme"),
            ("&physics ra_lw_physics = 0, ra_sw_physics = 1 /", "a longwave scheme needs a shortwave scheme"),
            ("&physics ra_lw_physics = 1, ra_sw_physics = 0 /", "a longwave scheme needs a shortwave scheme"),
            ("&physics ra_lw_physics = 1, ra_sw_physics = 2 /", "ra_sw_physics = 2 is not supported"),
            ("&physics ra_lw_physics = 3, ra_sw_physics = 4 /", "ra_lw_physics = 3 is not supported"),
            ("&physics ra_lw_physics = 4, ra_sw_physics = 2 /", "ra_sw_physics = 2 is not supported"),
            ("&physics ra_lw_physics = 4, ra_sw_physics = 1, cu_physics = 3, cu_rad_feedback = .true. /",
             "cu_rad_feedback with Grell-Freitas cumulus and the Dudhia shortwave"),
            ("&physics ra_lw_physics = 4, ra_sw_physics = 4, aer_opt = 1 /", "aer_opt = 1"),
            ("&physics ra_lw_physics = 4, ra_sw_physics = 4, cldovrlp = 9 /", "cldovrlp = 9"),
            ("&physics ra_lw_physics = 4, ra_sw_physics = 4, cldovrlp = -1 /", "cldovrlp = -1"),
            ("&physics shcu_physics = 2 /", "shcu_physics"),
            ("&physics topo_wind = 1 /", "topo_wind"),
            ("&dynamics moist_adv_opt = 2 /", "moist_adv_opt = 2"),
            ("&dynamics diff_6th_opt = 3 /", "diff_6th_opt = 3"),
            ("&dynamics h_mom_adv_order = 5, h_sca_adv_order = 6 /", "h_sca_adv_order = 6"),
            ("&dynamics hybrid_opt = 9 /", "hybrid_opt = 9"),
        ]
        for fragment, expected_err in cases:
            text = f"&time_control /\n&domains time_step = 60 /\n{fragment}\n"
            nml = parse_namelist(real_case(text))
            t = WrfTranslator(nml)
            t.translate()
            joined = " ".join(t.errors)
            self.assertIn(expected_err, joined, f"Expected '{expected_err}' in errors for {fragment}, got {t.errors}")

    def test_real_case_needs_specified(self):
        # specified defaults to .false. (Registry); a real case without it has no lateral boundary condition on
        # domain 1 and wrf.exe stops in share/module_bc.F boundary_condition_check
        text = complete("&time_control /\n&domains time_step = 60 /\n")
        t = WrfTranslator(parse_namelist(text))
        t.translate()
        self.assertEqual(len(t.errors), 1, t.errors)
        self.assertIn("pass --case", t.errors[0])
        t = WrfTranslator(parse_namelist(text), override_case="real")
        t.translate()
        self.assertEqual(len(t.errors), 1, t.errors)
        self.assertIn("specified = .false. in a real case", t.errors[0])
        t = WrfTranslator(parse_namelist(real_case(text)), override_case="real")
        self.assertEqual(t.translate()["run"]["case"], "real")
        self.assertEqual(t.errors, [])

    def test_ishallow_without_grell_freitas(self):
        # WRF passes ishallow to the G3 and GF schemes only (phys/module_cumulus_driver.F) and check_a_mundo has no
        # rule for it with other cumulus schemes: Kain-Fritsch with ishallow = 1 runs as without it
        t = WrfTranslator(parse_namelist(real_case("&time_control /\n&domains time_step = 60 /\n"
                                                   "&physics cu_physics = 1, ishallow = 1 /\n")))
        t.translate()
        self.assertEqual(t.errors, [])

    def test_invalid_nest_configurations_errors(self):
        base = """
        &time_control input_from_file = .true., .true. /
        &domains
         time_step = 60, max_dom = 2, dx = 30000, 10000, dy = 30000, 10000,
         e_we = 120, {e_we}, e_sn = 90, 91, e_vert = 45, {e_vert},
         parent_id = 0, 1, i_parent_start = 1, {i_start}, j_parent_start = 1, 30,
         parent_grid_ratio = 1, 3, parent_time_step_ratio = 1, 3{extra}
        /
        &bdy_control specified = .true., .false. /
        """

        def errors(e_we=121, e_vert=45, i_start=40, extra=""):
            t = WrfTranslator(parse_namelist(complete(base.format(e_we=e_we, e_vert=e_vert, i_start=i_start, extra=extra))))
            t.translate()
            return t.errors

        self.assertEqual(errors(), [])
        # 1. (e_we - s_we) not a multiple of parent_grid_ratio: "Nested dimensions are illegal" (dyn_em/start_em.F)
        e = errors(e_we=120)
        self.assertEqual(len(e), 1, e)
        self.assertIn("not divisible by parent_grid_ratio", e[0])

        # 2. the nest (40 parent cells from i_parent_start) must end 2 parent cells inside d01 (nx = 119): SINT's
        # stencil reaches 2 cells beyond the nest; 78 + 40 - 1 = 117 is the last allowed end
        self.assertEqual(errors(i_start=78), [])
        for i_start in (79, 100):
            e = errors(i_start=i_start)
            self.assertEqual(len(e), 1, e)
            self.assertIn("reaches within 2 cells of parent domain d01's edge", e[0])

        # 3. Mismatched e_vert and invalid smooth_option
        e = errors(e_vert=60, extra=",\n         smooth_option = 5")
        self.assertTrue(any("e_vert" in x for x in e), e)
        self.assertTrue(any("smooth_option = 5" in x for x in e), e)

        # 4. Noah-MP with nests: wrf.exe 4.8.0 aborts
        t = WrfTranslator(parse_namelist(complete(base.format(e_we=121, e_vert=45, i_start=40, extra="") +
                                                  "&physics sf_surface_physics = 4, 4, sf_sfclay_physics = 1, 1 /\n")))
        t.translate()
        self.assertTrue(any("Noah-MP" in x for x in t.errors), t.errors)


class TestWrfNamelistSemantics(unittest.TestCase):
    """WRF's namelist read, check_a_mundo, start_em and input_wrf rules (variants_pm_R32_*.txt on the VM)."""

    NEST = ("&time_control input_from_file = .true., .true. /\n"
            "&domains time_step = 60, max_dom = 2, e_we = 120, 121, e_sn = 90, 91, e_vert = 45, 45, dx = 15000,"
            " dy = 15000, parent_id = 0, 1, i_parent_start = 1, 40, j_parent_start = 1, 30, parent_grid_ratio = 1, 3,"
            " parent_time_step_ratio = 1, 3 /\n&bdy_control specified = .true., .false. /\n")
    FULL = ("&time_control /\n&domains time_step = 60, dx = 15000, dy = 15000 /\n"
            "&physics mp_physics = 0, cu_physics = 0, ra_lw_physics = 0, ra_sw_physics = 0, bl_pbl_physics = 0,"
            " sf_sfclay_physics = 0, sf_surface_physics = 0 /\n&dynamics diff_opt = 0, km_opt = 1 /\n"
            "&bdy_control specified = .true. /\n")

    @staticmethod
    def translate(text):
        t = WrfTranslator(parse_namelist(complete(text)))
        return t, t.translate()

    @staticmethod
    def errors(text):
        t = WrfTranslator(parse_namelist(text))
        t.translate()
        return t.errors

    def test_parser_fortran_semantics(self):
        # config_reads.inc: REWIND and one READ per group (a repeated group is not read); key(i) assigns from
        # element i, a repeated key again from its first element, null values keep the element
        nml = parse_namelist("&physics cudt = 5, 5, cudt(2) = 0, radt = , 10, bldt = 1, bldt = 2 /\n"
                             "&dynamics km_opt = 2*, 4 /\n&physics cudt = 9 /\n")
        self.assertEqual(nml["physics"]["cudt"], [5, 0])
        self.assertEqual(nml["physics"]["radt"], [None, 10])
        self.assertEqual(nml["physics"]["bldt"], [2])
        self.assertEqual(nml["dynamics"]["km_opt"], [None, None, 4])
        # gfortran's logical input: an optional '.', then T or F (true, F, .tru); a number is an error
        nml = parse_namelist("&bdy_control specified = true, nested = F, periodic_x = .tru /\n")
        self.assertEqual(nml["bdy_control"], {"specified": [True], "nested": [False], "periodic_x": [True]})
        with self.assertRaises(NamelistParseError):
            parse_namelist("&bdy_control specified = 1 /\n")
        # radt(1) unset: the Registry default 0
        t, sec = self.translate(self.NEST + "&physics cu_physics = 2*1, radt(2) = 3 /\n")
        self.assertEqual(t.errors, [])
        self.assertNotIn("radt", sec["phys"])
        self.assertEqual(sec["d02"]["phys_radt"], 3)

    def test_cu_rad_feedback_cldovrlp_0(self):
        # cldovrlp 0: RRTMG without clouds; cu_rad_feedback per domain (phy_init's icloud_cu); shallowcu_forced_ra
        # acts only with KF-CuP (cu_physics 10)
        t, sec = self.translate(self.NEST + "&physics cu_physics = 1, 1, ra_lw_physics = 2*4, ra_sw_physics = 2*4, "
                                "cldovrlp = 0, cu_rad_feedback = .true., .false., shallowcu_forced_ra = 2*.true. /\n")
        self.assertEqual(t.errors, [])
        self.assertEqual(sec["phys"]["cldovrlp"], 0)
        self.assertEqual(sec["phys"]["cu_rad_feedback"], True)
        self.assertEqual(sec["d02"]["phys_cu_rad_feedback"], False)
        # a nest without an entry: the Registry default .false.
        t, sec = self.translate(self.NEST + "&physics cu_physics = 3, 3, cu_rad_feedback = .true. /\n")
        self.assertEqual(t.errors, [])
        self.assertEqual(sec["d02"]["phys_cu_rad_feedback"], False)
        t, sec = self.translate(self.NEST + "&physics cu_physics = 6, 6, cu_rad_feedback = .false., .true. /\n")
        self.assertEqual(t.errors, [])
        self.assertNotIn("cu_rad_feedback", sec["phys"])
        self.assertEqual(sec["d02"]["phys_cu_rad_feedback"], True)

    def test_nest_entries_take_registry_defaults(self):
        # r32cudt1 / r32bldt1: a nest without a cudt / bldt entry calls the scheme every step (Registry default 0,
        # rconfig CUDT / BLDT in upper case)
        t, sec = self.translate(self.NEST + "&physics cu_physics = 1, 1, cudt = 5, bldt = 1 /\n")
        self.assertEqual(t.errors, [])
        self.assertEqual(sec["phys"]["cudt"], 5)
        self.assertEqual(sec["d02"]["phys_cudt"], 0)
        self.assertEqual(sec["d02"]["phys_bldt"], 0)

    def test_mp_physics_of_the_highest_domain(self):
        # frame/module_configure.F: every domain runs mp_physics(max_dom)
        t, sec = self.translate(self.NEST + "&physics mp_physics = 8, 6 /\n")
        self.assertEqual(t.errors, [])
        self.assertEqual(sec["phys"]["mp_physics"], 6)
        t, _ = self.translate(self.NEST + "&physics mp_physics = 6 /\n")  # domain 2 has the default -1
        self.assertTrue(any("mp_physics = -1" in e for e in t.errors), t.errors)

    def test_cu_physics_on_a_nest(self):
        # check_a_mundo: a nest's cu_physics is domain 1's or 0
        t, _ = self.translate(self.NEST + "&physics cu_physics = 1, 0 /\n")
        self.assertEqual(t.errors, [])
        t, _ = self.translate(self.NEST + "&physics cu_physics = 0, 1 /\n")
        self.assertTrue(any("cu_physics must be equal" in e for e in t.errors), t.errors)

    def test_options_wrf_needs(self):
        self.assertEqual(self.errors(self.FULL), [])
        for text, err in ((self.FULL.replace("time_step = 60, ", ""), "time_step is not set"),
                          (self.FULL.replace("diff_opt = 0, ", ""), "diff_opt and km_opt must both be set"),
                          (self.FULL.replace("mp_physics = 0, ", ""), "mp_physics = -1"),
                          (self.FULL.replace("time_step = 60", "time_step = 100"), "reasonable_time_step_ratio"),
                          (self.FULL.replace("dx = 15000, dy = 15000", ""), "reasonable_time_step_ratio")):
            self.assertTrue(any(err in e for e in self.errors(text)), (text, err))
        self.assertEqual(self.errors(self.FULL.replace("time_step = 60", "time_step = 100, reasonable_time_step_ratio = 7")), [])

    def test_unported_options(self):
        # r32tempo: WRF writes QNCLOUD, QNWFA, QNIFA; r32cor / r32curv: do_coriolis, do_curvature are not used by
        # wrf.exe; r32nssl: check_a_mundo turns the NSSL options off without NSSL microphysics
        for text, err in ((self.FULL.replace("&physics ", "&physics tempo_aerosolaware = 1, "), "tempo_aerosolaware"),
                          (self.FULL + "&afwa afwa_diag_opt = 1 /\n", "afwa_diag_opt"),
                          (self.FULL.replace("&domains ", "&domains perturb_input = .true., "), "perturb_input"),
                          (self.FULL.replace("&time_control ", "&time_control io_form_history = 102, "), "io_form_history = 102"),
                          (self.FULL.replace("&time_control ", "&time_control history_outname = 'out/x_d<domain>', "),
                           "history_outname")):
            self.assertTrue(any(err in e for e in self.errors(text)), (text, err))
        for text in (self.FULL.replace("&physics ", "&physics tempo_aerosolaware = 0, "),
                     self.FULL.replace("&dynamics ", "&dynamics do_coriolis = .false., do_curvature = .false., "),
                     self.FULL.replace("&physics ", "&physics nssl_2moment_on = 1, "),
                     self.FULL.replace("&dynamics ", "&dynamics damp_opt = 0, zdamp = 3000., ")):
            self.assertEqual(self.errors(text), [], text)

    def test_single_entry_options(self):
        # r34_t1_*: WRF's namelist read stops on more values than a single-entry option (Registry "1") holds
        for opt in ("isfflx = 1, 1", "cldovrlp = 2, 2", "bl_mynn_closure = 2.6, 2.6"):
            text = self.FULL.replace("&physics ", f"&physics {opt}, ")
            self.assertTrue(any("takes one value" in e for e in self.errors(text)), opt)
        for opt in ("isfflx = 1", "cudt = 5, 5"):  # cudt: max_domains entries
            self.assertEqual(self.errors(self.FULL.replace("&physics ", f"&physics {opt}, ")), [], opt)

    def test_namelist_outside_real_dir(self):
        # the model reads the output options and global attributes from real.dir/namelist.input unless
        # output.wrf_namelist names the translated namelist
        tmp = tempfile.mkdtemp()
        for d in ("a", "b"):
            os.makedirs(os.path.join(tmp, d))
            with open(os.path.join(tmp, d, "namelist.input"), "w") as f:
                f.write(self.FULL)
        nml = os.path.join(tmp, "a", "namelist.input")
        for real_dir, expect in ((None, None), (os.path.join(tmp, "a"), None), (os.path.join(tmp, "b"), nml)):
            t = WrfTranslator(parse_namelist(self.FULL), namelist_path=nml, real_dir=real_dir)
            sec = t.translate()
            self.assertEqual(t.errors, [])
            self.assertEqual(sec["output"].get("wrf_namelist"), expect, real_dir)

    def test_output_file_names(self):
        # history_outname / rst_outname: the model names its files as construct_filename2a does; a directory part
        # (CPPWRF writes into output.dir) or an empty name is an error
        def errors(extra):
            t = WrfTranslator(parse_namelist(self.FULL.replace("&time_control ", "&time_control history_interval = 1, " + extra)),
                              output_format="wrfout")
            t.translate()
            return t.errors
        for extra in ("history_outname = 'hist_d<domain>_<year><month><day>_<hour>', ",
                      "restart_interval = 1, rst_outname = 'rst_d<domain>_<date>.nc', ",
                      "use_netcdf_classic = .true., "):  # the model writes NetCDF classic files
            self.assertEqual(errors(extra), [], extra)
        for extra, err in (("history_outname = 'out/wrfout_d<domain>_<date>', ", "history_outname"),
                           ("history_outname = '', ", "history_outname"),
                           ("restart_interval = 1, rst_outname = '/x/wrfrst_d<domain>', ", "rst_outname")):
            self.assertTrue(any(err in e for e in errors(extra)), (extra, errors(extra)))

    def test_input_file_checks(self):
        # input_wrf.F stops when e_we / e_sn / e_vert / num_land_cat differ from the input (r32ewe, r32nlc): the
        # model compares the values the translator passes, a missing entry being the Registry default
        t, sec = self.translate(self.NEST + "&physics num_land_cat = 20 /\n")
        self.assertEqual(t.errors, [])
        self.assertEqual([sec["real"][k] for k in ("e_we", "e_sn", "e_vert", "num_land_cat")], [120, 90, 45, 20])
        self.assertEqual([sec["d02"][k] for k in ("e_we", "e_sn", "e_vert")], [121, 91, 45])
        t, sec = self.translate("&time_control /\n&domains time_step = 60 /\n&bdy_control specified = .true. /\n")
        self.assertEqual([sec["real"][k] for k in ("e_we", "e_sn", "e_vert", "num_land_cat")], [32, 32, 31, 21])

    def test_sst_update_on_nests(self):
        # set_timekeeping_alarms: each domain reads its wrflowinp_d0N every auxinput4_interval(id); a missing
        # entry is 0 and that domain's alarm never rings
        text = self.NEST.replace("input_from_file", "auxinput4_inname = 'lowinp_d<domain>', auxinput4_interval = 360,"
                                 " io_form_auxinput4 = 2, input_from_file") + \
            "&physics sst_update = 1, mp_physics = 2*6, sf_sfclay_physics = 2*1, sf_surface_physics = 2*2," \
            " bl_pbl_physics = 2*1 /\n"
        t, sec = self.translate(text)
        self.assertEqual(t.errors, [])
        self.assertEqual(sec["phys"]["auxinput4_interval"], 360)
        self.assertEqual(sec["d02"]["phys_auxinput4_interval"], 0)
        self.assertEqual(sec["d02"]["wrflowinp"], "lowinp_d02")

    FDDA_PHYS = "&physics mp_physics = 2*6, sf_sfclay_physics = 2*1, sf_surface_physics = 2*2, bl_pbl_physics = 2*1 /\n"

    def test_grid_fdda(self):
        # grid_fdda = 1 (PSUFDDAGD): the &fdda options to [fdda], a nest's own entries to [d02] fdda_*, the auxinput10
        # file name from gfdda_inname (real.exe writes wrffdda_d0N; WRF's default name is gfdda_d<domain>)
        text = self.NEST + self.FDDA_PHYS + (
            "&fdda grid_fdda = 1, 1, gfdda_inname = 'wrffdda_d<domain>', gfdda_interval_m = 360, 360,"
            " gfdda_end_h = 6, 3, io_form_gfdda = 2, guv = 0.0003, 0.0006, gt = 0.0003, 0.0003, gq = 0.0003, 0.0003,"
            " fgdt = 3, 3, if_no_pbl_nudging_uv = 1, 1, if_zfac_t = 1, 1, k_zfac_t = 5, 5, if_ramping = 1,"
            " dtramp_min = -30. /\n")
        t, sec = self.translate(text)
        self.assertEqual(t.errors, [])
        f = sec["fdda"]
        self.assertEqual((f["grid_fdda"], f["gfdda_interval_m"], f["gfdda_end_h"]), (1, 360, 6))
        self.assertEqual((f["guv"], f["fgdt"], f["if_no_pbl_nudging_uv"], f["k_zfac_t"]), (0.0003, 3, 1, 5))
        self.assertEqual((f["if_ramping"], f["dtramp_min"]), (1, -30.0))
        self.assertEqual(sec["d02"]["fdda_guv"], 0.0006)
        self.assertEqual(sec["d02"]["fdda_gfdda_end_h"], 3)
        self.assertNotIn("fdda_gt", sec["d02"])
        self.assertNotIn("wrffdda", sec.get("real", {}))
        # the default name: the model reads gfdda_d01 / gfdda_d02 from real.dir
        t, sec = self.translate(text.replace("gfdda_inname = 'wrffdda_d<domain>',", ""))
        self.assertEqual(t.errors, [])
        self.assertEqual(sec["real"]["wrffdda"], "gfdda_d01")
        self.assertEqual(sec["d02"]["wrffdda"], "gfdda_d02")
        # grid_fdda = 1 on the nest only
        t, sec = self.translate(text.replace("grid_fdda = 1, 1", "grid_fdda = 0, 1"))
        self.assertEqual(t.errors, [])
        self.assertEqual((sec["fdda"]["grid_fdda"], sec["d02"]["fdda_grid_fdda"]), (0, 1))
        # without grid_fdda the &fdda options have no effect (check_a_mundo zeroes the gfdda end and interval)
        t, sec = self.translate(text.replace("grid_fdda = 1, 1", "grid_fdda = 0, 0"))
        self.assertEqual(t.errors, [])
        self.assertNotIn("fdda", sec)

    def test_grid_fdda_errors(self):
        base = ("&fdda grid_fdda = 1, 1, gfdda_inname = 'wrffdda_d<domain>', gfdda_interval_m = 360, 360,"
                " gfdda_end_h = 6, 6, guv = 0.0003, 0.0003 X /\n")
        for extra, expected in [
                (", grid_fdda = 2, 1", "grid_fdda = 2 (spectral nudging)"),
                (", grid_sfdda = 1, 1", "grid_sfdda"),
                (", gfdda_begin_h = 1, 1", "gfdda_begin_h"),
                (", gfdda_end_d = 1, 1", "gfdda_end_d is ignored"),
                (", gfdda_interval_h = 6, 6", "gfdda_interval_h is ignored"),
                (", gfdda_interval_m = 0, 360", "gfdda_interval_m must be > 0"),
                (", gt = -0.1, 0.0003", "Gt must be positive"),
                (", io_form_gfdda = 0", "io_form_gfdda = 2"),
                (", gfdda_end = 360, 360", "gfdda_end = 360"),
                (", gfdda_inname = 'analyses'", "without <domain>")]:
            t, _ = self.translate(self.NEST + self.FDDA_PHYS + base.replace(" X", extra))
            self.assertTrue(any(expected in e for e in t.errors), (extra, t.errors))
        # the physics suite and no adaptive time step
        t, _ = self.translate(self.NEST + base.replace(" X", ""))
        self.assertTrue(any("needs a real-data case with the physics suite" in e for e in t.errors), t.errors)
        t, _ = self.translate(self.NEST.replace("time_step = 60,", "time_step = 60, use_adaptive_time_step = .true.,")
                              + self.FDDA_PHYS + base.replace(" X", ""))
        self.assertTrue(any("grid_fdda = 1 with use_adaptive_time_step" in e for e in t.errors), t.errors)

    def test_buckets_and_prec_acc(self):
        # diagnostic_output_calc: bucket_mm, bucket_J (one entry) and prec_acc_dt (every domain's entry; check_a_mundo's
        # prec_acc_opt = 1 when some domain has prec_acc_dt > 0); a nest's missing entry is the Registry default 0
        phys = ("&physics mp_physics = 2*6, sf_sfclay_physics = 2*1, sf_surface_physics = 2*2, bl_pbl_physics = 2*1,"
                " bucket_mm = 1., bucket_J = 1.e7, prec_acc_dt = 10. /\n")
        t, sec = self.translate(self.NEST + phys.replace(" /\n", ", ra_lw_physics = 2*4, ra_sw_physics = 2*4 /\n"))
        self.assertEqual(t.errors, [])
        self.assertEqual((sec["phys"]["bucket_mm"], sec["phys"]["bucket_j"]), (1.0, 1.e7))
        self.assertEqual((sec["phys"]["prec_acc_dt"], sec["phys"]["prec_acc_opt"]), (10.0, 1))
        self.assertEqual(sec["d02"]["phys_prec_acc_dt"], 0.0)
        t, sec = self.translate(self.NEST + phys.replace("prec_acc_dt = 10.", "prec_acc_dt = 0., 5.").replace(
            "bucket_J = 1.e7, ", ""))
        self.assertEqual(t.errors, [])
        self.assertNotIn("prec_acc_dt", sec["phys"])
        self.assertEqual((sec["phys"]["prec_acc_opt"], sec["d02"]["phys_prec_acc_dt"]), (1, 5.0))
        t, sec = self.translate(self.NEST + phys.replace(" bucket_mm = 1., bucket_J = 1.e7, prec_acc_dt = 10.",
                                                         " bucket_mm = -1., prec_acc_dt = 0."))
        self.assertEqual(t.errors, [])
        self.assertFalse({"bucket_mm", "bucket_j", "prec_acc_dt", "prec_acc_opt"} & set(sec["phys"]))
        # ra_init: bucket_J without RRTMG radiation stops wrf.exe
        t, sec = self.translate(self.NEST + phys)
        self.assertTrue(any("Need CAM or RRTMG" in e for e in t.errors))
        rad = phys.replace(" /\n", ", ra_lw_physics = 2*4, ra_sw_physics = 2*4 /\n")
        t, sec = self.translate(self.NEST + rad)
        self.assertEqual(t.errors, [])
        t, sec = self.translate(self.NEST + rad.replace("ra_sw_physics = 2*4", "ra_sw_physics = 4, 0"))
        self.assertTrue(any("Need CAM or RRTMG" in e for e in t.errors))
        # without the column physics (microphysics only) CPPWRF has no port: an error
        for opt in ("bucket_mm = 1.", "bucket_J = 1.e7", "prec_acc_dt = 10."):
            t, sec = self.translate(self.NEST + f"&physics mp_physics = 2*6, {opt} /\n")
            self.assertTrue(any("bucket_mm / bucket_J / prec_acc_dt" in e for e in t.errors), opt)

    def test_output_and_nwp_diagnostics(self):
        # output_diagnostics = 1 (clwrf_output_calc): every domain's auxhist3_interval (minutes; a domain without one
        # stops wrf.exe), the auxhist3 files with io_form_auxhist3 = 2 (wrfout format only); nwp_diagnostics stays an
        # error (check_a_mundo also sets do_radar_ref = 1)
        phys = "&physics mp_physics = 2*6, sf_sfclay_physics = 2*1, sf_surface_physics = 2*2, bl_pbl_physics = 2*1 /\n"

        def run(tc, physics=phys, fmt="wrfout"):
            text = self.NEST.replace("&time_control ", f"&time_control history_interval = 2*10, {tc}, ") + physics
            t = WrfTranslator(parse_namelist(complete(text)), output_format=fmt)
            return t, t.translate()
        ok = "output_diagnostics = 1, auxhist3_interval = 10, 20, io_form_auxhist3 = 2"
        t, sec = run(ok)
        self.assertEqual(t.errors, [])
        self.assertEqual((sec["phys"]["output_diagnostics"], sec["phys"]["auxhist3_interval"]), (1, 10))
        self.assertEqual(sec["d02"]["phys_auxhist3_interval"], 20)
        self.assertTrue(sec["output"]["auxhist3"])
        # io_form_auxhist3 = 0: the statistics (restart fields) without auxhist3 files
        t, sec = run("output_diagnostics = 1, auxhist3_interval = 2*10")
        self.assertEqual(t.errors, [])
        self.assertEqual(sec["phys"]["output_diagnostics"], 1)
        self.assertNotIn("auxhist3", sec["output"])
        self.assertNotIn("phys_auxhist3_interval", sec["d02"])
        for tc, err in (("output_diagnostics = 1, auxhist3_interval = 10", "NO 'auxhist3_interval'"),  # d02: none
                        (ok + ", auxhist3_interval_s = 30", "auxhist3_interval_s"),
                        (ok + ", auxhist3_begin_m = 30", "auxhist3_begin_m"),
                        (ok.replace("io_form_auxhist3 = 2", "io_form_auxhist3 = 11"), "io_form_auxhist3 = 11"),
                        (ok.replace("output_diagnostics = 1", "output_diagnostics = 2"), "output_diagnostics = 2")):
            t, _ = run(tc)
            self.assertTrue(any(err in e for e in t.errors), (tc, t.errors))
        # auxhist3 files need WRF-format output; the statistics need the column physics
        t, _ = run(ok, fmt="native")
        self.assertTrue(any("io_form_auxhist3 = 2" in e for e in t.errors), t.errors)
        t, _ = run(ok, physics="&physics mp_physics = 2*6 /\n")
        self.assertTrue(any("output_diagnostics = 1 needs the column physics" in e for e in t.errors), t.errors)
        t, _ = run("nwp_diagnostics = 1")
        self.assertTrue(any("nwp_diagnostics = 1" in e and "do_radar_ref" in e for e in t.errors), t.errors)

    def test_mynn_options_of_every_domain(self):
        text = self.NEST + ("&physics mp_physics = 2*8, sf_sfclay_physics = 2*5, bl_pbl_physics = 2*5,"
                            " bl_mynn_edmf_dd = 0, 1 /\n")
        t, _ = self.translate(text)
        self.assertTrue(any("bl_mynn_edmf_dd = 1" in e for e in t.errors), t.errors)
        # a ported option must be the same on all domains
        text = self.NEST + ("&physics mp_physics = 2*8, sf_sfclay_physics = 2*5, bl_pbl_physics = 2*5,"
                            " bl_mynn_edmf = 1, 0 /\n")
        t, _ = self.translate(text)
        self.assertTrue(any("bl_mynn_edmf with different values per domain" in e for e in t.errors), t.errors)
        text = self.NEST + ("&physics mp_physics = 2*8, sf_sfclay_physics = 2*5, bl_pbl_physics = 2*5,"
                            " bl_mynn_edmf = 2*0, bl_mynn_mixlength = 2 /\n")
        t, sec = self.translate(text)
        self.assertEqual(t.errors, [])
        self.assertEqual((sec["phys"]["bl_mynn_edmf"], sec["phys"]["bl_mynn_mixlength"]), (0, 2))

    def test_mynn_ported_options(self):
        """module_bl_mynnedmf.F90: the ported option values reach [phys]; unported ones are errors."""
        base = "&physics mp_physics = 8, sf_sfclay_physics = 5, sf_surface_physics = 2, bl_pbl_physics = 5, "
        for opt, val, key, want in (("bl_mynn_cloudpdf", "0", "bl_mynn_cloudpdf", 0),
                                    ("bl_mynn_cloudpdf", "-1", "bl_mynn_cloudpdf", -1),
                                    ("bl_mynn_mixlength", "0", "bl_mynn_mixlength", 0),
                                    ("bl_mynn_edmf_mom", "0", "bl_mynn_edmf_mom", 0),
                                    ("bl_mynn_edmf_tke", "1", "bl_mynn_edmf_tke", 1),
                                    ("bl_mynn_cloudmix", "0", "bl_mynn_cloudmix", 0),
                                    ("bl_mynn_mixqt", "1", "bl_mynn_mixqt", 1),
                                    ("bl_mynn_ess", "0", "bl_mynn_ess", 0),
                                    ("bl_mynn_mixscalars", "1", "bl_mynn_mixscalars", 1),
                                    ("bl_mynn_output", "1", "bl_mynn_output", 1),
                                    ("tke_budget", "1", "tke_budget", 1),
                                    ("bl_mynn_tkeadvect", ".true.", "bl_mynn_tkeadvect", True),
                                    ("bl_mynn_closure", "2.5", "bl_mynn_closure", 2.5),
                                    ("bl_mynn_closure", "3.0", "bl_mynn_closure", 3.0),
                                    ("sf_mynn_sfcflux_land", "2", "sf_mynn_sfcflux_land", 2),
                                    ("sf_mynn_sfcflux_water", "0", "sf_mynn_sfcflux_water", 0),
                                    ("isftcflx", "1", "isftcflx", 1), ("iz0tlnd", "2", "iz0tlnd", 2)):
            t = WrfTranslator(parse_namelist(real_case(f"&time_control /\n&domains time_step = 60 /\n{base}{opt} = {val} /\n")))
            cfg = t.translate()
            self.assertEqual(t.errors, [], (opt, val))
            self.assertEqual(cfg["phys"][key], want, (opt, val))
        for opt, val, err in (("bl_mynn_edmf", "2", "bl_mynn_edmf = 2"), ("bl_mynn_edmf_dd", "1", "bl_mynn_edmf_dd = 1"),
                              ("bl_mynn_mixlength", "3", "bl_mynn_mixlength = 3"),
                              ("bl_mynn_closure", "2.7", "bl_mynn_closure = 2.7"),
                              ("bl_mynn_mixnumcon", "1", "bl_mynn_mixnumcon = 1"),
                              ("sf_mynn_sfcflux_water", "5", "sf_mynn_sfcflux_water = 5"),
                              ("sf_mynn_sfcflux_land", "4", "sf_mynn_sfcflux_land = 4")):
            t = WrfTranslator(parse_namelist(real_case(f"&time_control /\n&domains time_step = 60 /\n{base}{opt} = {val} /\n")))
            t.translate()
            self.assertIn(err, " ".join(t.errors), (opt, val))

    def test_grav_settling(self):
        """module_sf_fogdes.F / module_bl_fogdes.F: grav_settling 1, 2 reach [phys]; 3, per-domain values and
        a run without a PBL scheme are errors."""
        base = "&physics mp_physics = 8, sf_sfclay_physics = 1, sf_surface_physics = 2, "
        for pbl, val, want in (("1", "1", 1), ("5", "2", 2)):
            t = WrfTranslator(parse_namelist(real_case(
                f"&time_control /\n&domains time_step = 60 /\n{base}bl_pbl_physics = {pbl}, grav_settling = {val} /\n")))
            cfg = t.translate()
            self.assertEqual(t.errors, [], val)
            self.assertEqual(cfg["phys"]["grav_settling"], want)
        t = WrfTranslator(parse_namelist(real_case(
            f"&time_control /\n&domains time_step = 60 /\n{base}bl_pbl_physics = 1 /\n")))
        self.assertNotIn("grav_settling", t.translate()["phys"])
        for nl, err in ((f"{base}bl_pbl_physics = 1, grav_settling = 3 /", "grav_settling = [3]"),
                        (f"{base}bl_pbl_physics = 0, grav_settling = 1 /", "needs a microphysics scheme")):
            t = WrfTranslator(parse_namelist(real_case(f"&time_control /\n&domains time_step = 60 /\n{nl}\n")))
            t.translate()
            self.assertIn(err, " ".join(t.errors), nl)


    def test_adaptive_time_step(self):
        """use_adaptive_time_step (adapt_timestep_em.F): d01's options and the history / boundary intervals reach
        [time]; nests and sst_update are errors."""
        t = WrfTranslator(parse_namelist(real_case(
            "&time_control history_interval_s = 600 /\n&domains time_step = 60, use_adaptive_time_step = .true., "
            "target_cfl = 1.1, max_time_step = 90, step_to_output_time = .false. /\n&physics /\n")))
        cfg = t.translate()
        self.assertEqual(t.errors, [])
        tm = cfg["time"]
        self.assertTrue(tm["adaptive"])
        self.assertEqual((tm["target_cfl"], tm["max_time_step"], tm["step_to_output_time"]), (1.1, 90, False))
        self.assertEqual((tm["history_interval_s"], tm["interval_seconds"]), (600, 21600))
        self.assertNotIn("target_hcfl", tm)
        for nl, err in (("&domains time_step = 60, use_adaptive_time_step = .true. /\n&physics sst_update = 1 /",
                         "sst_update"),):
            t = WrfTranslator(parse_namelist(real_case(f"&time_control /\n{nl}\n")))
            t.translate()
            self.assertIn(err, " ".join(t.errors), nl)


class TestExecution2Steps(unittest.TestCase):
    """Verify that generated INI executes for 2 steps (binary: $CPPWRF_BIN, default build/cppwrf)."""

    def test_run_r0_2steps(self):
        exe = os.environ.get("CPPWRF_BIN", os.path.join(REPO_ROOT, "build", "cppwrf"))
        if not os.path.exists(exe):
            self.skipTest(f"{exe} not found (set CPPWRF_BIN)")

        nml_path = wrf_runs_path("run_R0_r8/namelist.input")
        if not os.path.exists(nml_path):
            self.skipTest(f"Namelist not found: {nml_path}")

        with tempfile.NamedTemporaryFile(suffix=".ini", mode="w", delete=False) as tf:
            ini_path = tf.name

        try:
            # Generate INI using translator CLI
            cmd_trans = [sys.executable, os.path.join(REPO_ROOT, "tools", "wrf2cppwrf.py"),
                         nml_path, "-o", ini_path]
            ret_trans = subprocess.run(cmd_trans, capture_output=True, text=True)
            self.assertEqual(ret_trans.returncode, 0, f"Translator failed: {ret_trans.stderr}")

            # Run 2 steps with heavy.sh
            cmd_run = [os.path.join(REPO_ROOT, "tools", "heavy.sh"), exe, ini_path,
                       "--set", "run.run_time=120"]
            ret_run = subprocess.run(cmd_run, capture_output=True, text=True, cwd=REPO_ROOT)
            self.assertEqual(ret_run.returncode, 0, f"Run failed: {ret_run.stderr}\n{ret_run.stdout}")
            self.assertIn("done, 2 steps", ret_run.stdout)
        finally:
            if os.path.exists(ini_path):
                os.remove(ini_path)

    def test_run_n1_2steps(self):
        exe = os.environ.get("CPPWRF_BIN", os.path.join(REPO_ROOT, "build", "cppwrf"))
        if not os.path.exists(exe):
            self.skipTest(f"{exe} not found (set CPPWRF_BIN)")

        nml_path = wrf_runs_path("run_N1_r8/steps/namelist.input")
        if not os.path.exists(nml_path):
            self.skipTest(f"Namelist not found: {nml_path}")

        with tempfile.NamedTemporaryFile(suffix=".ini", mode="w", delete=False) as tf:
            ini_path = tf.name

        try:
            cmd_trans = [sys.executable, os.path.join(REPO_ROOT, "tools", "wrf2cppwrf.py"),
                         nml_path, "-o", ini_path]
            ret_trans = subprocess.run(cmd_trans, capture_output=True, text=True)
            self.assertEqual(ret_trans.returncode, 0, f"Translator failed: {ret_trans.stderr}")

            cmd_run = [os.path.join(REPO_ROOT, "tools", "heavy.sh"), exe, ini_path,
                       "--set", "run.run_time=120"]
            ret_run = subprocess.run(cmd_run, capture_output=True, text=True, cwd=REPO_ROOT)
            self.assertEqual(ret_run.returncode, 0, f"Nested run failed: {ret_run.stderr}\n{ret_run.stdout}")
        finally:
            if os.path.exists(ini_path):
                os.remove(ini_path)


if __name__ == "__main__":
    unittest.main()
