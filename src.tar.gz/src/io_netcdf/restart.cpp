// SPDX-License-Identifier: GPL-3.0-or-later
#include "io_netcdf/restart.hpp"

#include <cstdint>
#include <cstring>
#include <filesystem>
#include <map>
#include <stdexcept>
#include <vector>

namespace cppwrf::io_netcdf {

namespace {

void get_var_dims(int nx, int ny, int nz, const RestartMeta& meta,
                  int dim_time, int dim_bt, int dim_bt_stag,
                  int dim_sn, int dim_sn_stag, int dim_we, int dim_we_stag,
                  std::map<int, int>& other_levels, int ncid, std::vector<int>& dimids) {
  dimids.clear();
  dimids.push_back(dim_time);
  if (nz > 1) {
    if (nz == meta.nz) dimids.push_back(dim_bt);
    else if (nz == meta.nz + 1) dimids.push_back(dim_bt_stag);
    else {  // e.g. soil layers: one dimension per level count
      auto it = other_levels.find(nz);
      if (it == other_levels.end()) {
        int d = -1;
        NC_CHECK(nc_def_dim(ncid, ("levels_" + std::to_string(nz)).c_str(), nz, &d));
        it = other_levels.emplace(nz, d).first;
      }
      dimids.push_back(it->second);
    }
  }
  if (ny > meta.ny) dimids.push_back(dim_sn_stag);
  else dimids.push_back(dim_sn);

  if (nx > meta.nx) dimids.push_back(dim_we_stag);
  else dimids.push_back(dim_we);
}

}  // namespace

void write_restart(const std::string& path, const RestartMeta& meta,
                   const std::vector<VarView>& vars) {
  auto p = std::filesystem::path(path).parent_path();
  if (!p.empty()) std::filesystem::create_directories(p);

  ScopedNcFile ncid;
  NC_CHECK(nc_create(path.c_str(), NC_CLOBBER | NC_64BIT_OFFSET, ncid.ptr()));

  // Global attributes
  std::string title = "RESTART FILE FROM CPPWRF";
  NC_CHECK(nc_put_att_text(ncid, NC_GLOBAL, "TITLE", title.size(), title.data()));
  int flag_restart = 1;
  NC_CHECK(nc_put_att_int(ncid, NC_GLOBAL, "FLAG_RESTART", NC_INT, 1, &flag_restart));
  int step_i = int(meta.step);
  NC_CHECK(nc_put_att_int(ncid, NC_GLOBAL, "STEP", NC_INT, 1, &step_i));
  NC_CHECK(nc_put_att_double(ncid, NC_GLOBAL, "TIME", NC_DOUBLE, 1, &meta.time_sec));

  NC_CHECK(nc_put_att_int(ncid, NC_GLOBAL, "NX", NC_INT, 1, &meta.nx));
  NC_CHECK(nc_put_att_int(ncid, NC_GLOBAL, "NY", NC_INT, 1, &meta.ny));
  NC_CHECK(nc_put_att_int(ncid, NC_GLOBAL, "NZ", NC_INT, 1, &meta.nz));

  NC_CHECK(nc_put_att_double(ncid, NC_GLOBAL, "DX", NC_DOUBLE, 1, &meta.dx));
  NC_CHECK(nc_put_att_double(ncid, NC_GLOBAL, "DY", NC_DOUBLE, 1, &meta.dy));
  NC_CHECK(nc_put_att_double(ncid, NC_GLOBAL, "DT", NC_DOUBLE, 1, &meta.dt));

  if (!meta.case_name.empty()) {
    NC_CHECK(nc_put_att_text(ncid, NC_GLOBAL, "CASE", meta.case_name.size(), meta.case_name.data()));
  }
  if (!meta.date_str.empty()) {
    NC_CHECK(nc_put_att_text(ncid, NC_GLOBAL, "CURRENT_DATE", meta.date_str.size(), meta.date_str.data()));
  }
  NC_CHECK(nc_put_att_int(ncid, NC_GLOBAL, "CPPWRF_RESTART_VERSION", NC_INT, 1, &meta.version));
  if (!meta.commit.empty())
    NC_CHECK(nc_put_att_text(ncid, NC_GLOBAL, "CPPWRF_COMMIT", meta.commit.size(), meta.commit.data()));
  if (!meta.options.empty())
    NC_CHECK(nc_put_att_text(ncid, NC_GLOBAL, "CPPWRF_OPTIONS", meta.options.size(), meta.options.data()));

  // Dimensions
  int dim_time = -1, dim_bt = -1, dim_bt_stag = -1;
  int dim_sn = -1, dim_sn_stag = -1, dim_we = -1, dim_we_stag = -1;

  NC_CHECK(nc_def_dim(ncid, "Time", 1, &dim_time));
  NC_CHECK(nc_def_dim(ncid, "bottom_top", meta.nz, &dim_bt));
  NC_CHECK(nc_def_dim(ncid, "bottom_top_stag", meta.nz + 1, &dim_bt_stag));
  NC_CHECK(nc_def_dim(ncid, "south_north", meta.ny, &dim_sn));
  NC_CHECK(nc_def_dim(ncid, "south_north_stag", meta.ny + 1, &dim_sn_stag));
  NC_CHECK(nc_def_dim(ncid, "west_east", meta.nx, &dim_we));
  NC_CHECK(nc_def_dim(ncid, "west_east_stag", meta.nx + 1, &dim_we_stag));

  // Variable definitions
  std::vector<int> varids(vars.size(), -1);
  std::map<int, int> other_levels;
  for (size_t i = 0; i < vars.size(); ++i) {
    const auto& v = vars[i];
    std::vector<int> dimids;
    get_var_dims(v.nx, v.ny, v.nz, meta, dim_time, dim_bt, dim_bt_stag,
                 dim_sn, dim_sn_stag, dim_we, dim_we_stag, other_levels, ncid, dimids);
    nc_type xtype = (v.dtype == DType::F64) ? NC_DOUBLE : NC_FLOAT;
    NC_CHECK(nc_def_var(ncid, v.name.c_str(), xtype, int(dimids.size()), dimids.data(), &varids[i]));
    char stag_str[2] = {v.stagger ? v.stagger : '\0', '\0'};
    NC_CHECK(nc_put_att_text(ncid, varids[i], "stagger", 1, stag_str));
    int shape[3] = {v.nx, v.ny, v.nz};
    NC_CHECK(nc_put_att_int(ncid, varids[i], "shape", NC_INT, 3, shape));
  }

  NC_CHECK(nc_enddef(ncid));

  // Write data
  for (size_t i = 0; i < vars.size(); ++i) {
    const auto& v = vars[i];
    int varid = varids[i];
    const int nx = v.nx > 0 ? v.nx : 1;
    const int ny = v.ny > 0 ? v.ny : 1;
    const int nz = v.nz > 0 ? v.nz : 1;
    size_t count = size_t(nx) * ny * nz;

    const std::ptrdiff_t sj = (v.sj != 0 || v.sk != 0) ? v.sj : nx;
    const std::ptrdiff_t sk = v.sk != 0 ? v.sk : (std::ptrdiff_t)nx * ny;
    bool is_contiguous = (sj == nx && sk == (std::ptrdiff_t)nx * ny);

    if (v.dtype == DType::F64) {
      const double* src = static_cast<const double*>(v.data);
      if (is_contiguous) {
        NC_CHECK(nc_put_var_double(ncid, varid, src));
      } else {
        std::vector<double> buf(count);
        for (int k = 0; k < nz; ++k)
          for (int j = 0; j < ny; ++j)
            for (int ii = 0; ii < nx; ++ii)
              buf[(size_t(k) * ny + j) * nx + ii] = src[ii + j * sj + k * sk];
        NC_CHECK(nc_put_var_double(ncid, varid, buf.data()));
      }
    } else {
      const float* src = static_cast<const float*>(v.data);
      if (is_contiguous) {
        NC_CHECK(nc_put_var_float(ncid, varid, src));
      } else {
        std::vector<float> buf(count);
        for (int k = 0; k < nz; ++k)
          for (int j = 0; j < ny; ++j)
            for (int ii = 0; ii < nx; ++ii)
              buf[(size_t(k) * ny + j) * nx + ii] = src[ii + j * sj + k * sk];
        NC_CHECK(nc_put_var_float(ncid, varid, buf.data()));
      }
    }
  }

  const int id = ncid.release();
  NC_CHECK(nc_close(id));
}

namespace {

std::string text_att(int ncid, const char* name) {
  std::size_t len = 0;
  std::string v;
  if (nc_inq_attlen(ncid, NC_GLOBAL, name, &len) == NC_NOERR && len > 0) {
    v.resize(len);
    NC_CHECK(nc_get_att_text(ncid, NC_GLOBAL, name, v.data()));
  }
  return v;
}

void read_meta(int ncid, const std::string& path, RestartMeta& meta) {
  int version = 0;
  if (nc_get_att_int(ncid, NC_GLOBAL, "CPPWRF_RESTART_VERSION", &version) != NC_NOERR) version = 0;
  meta.version = version;
  meta.commit = text_att(ncid, "CPPWRF_COMMIT");
  meta.options = text_att(ncid, "CPPWRF_OPTIONS");
  int step_i = 0;
  if (nc_get_att_int(ncid, NC_GLOBAL, "STEP", &step_i) == NC_NOERR) {
    meta.step = step_i;
  }
  NC_CHECK(nc_get_att_double(ncid, NC_GLOBAL, "TIME", &meta.time_sec));
  NC_CHECK(nc_get_att_int(ncid, NC_GLOBAL, "NX", &meta.nx));
  NC_CHECK(nc_get_att_int(ncid, NC_GLOBAL, "NY", &meta.ny));
  NC_CHECK(nc_get_att_int(ncid, NC_GLOBAL, "NZ", &meta.nz));
  NC_CHECK(nc_get_att_double(ncid, NC_GLOBAL, "DX", &meta.dx));
  NC_CHECK(nc_get_att_double(ncid, NC_GLOBAL, "DY", &meta.dy));
  NC_CHECK(nc_get_att_double(ncid, NC_GLOBAL, "DT", &meta.dt));

  if (meta.nx <= 0 || meta.ny <= 0 || meta.nz <= 0) {
    throw std::runtime_error("read_restart: invalid domain dimensions in " + path + ": " +
                             std::to_string(meta.nx) + "x" + std::to_string(meta.ny) + "x" + std::to_string(meta.nz));
  }

  size_t att_len = 0;
  if (nc_inq_attlen(ncid, NC_GLOBAL, "CASE", &att_len) == NC_NOERR && att_len > 0) {
    meta.case_name.resize(att_len);
    nc_get_att_text(ncid, NC_GLOBAL, "CASE", meta.case_name.data());
  }
  if (nc_inq_attlen(ncid, NC_GLOBAL, "CURRENT_DATE", &att_len) == NC_NOERR && att_len > 0) {
    meta.date_str.resize(att_len);
    nc_get_att_text(ncid, NC_GLOBAL, "CURRENT_DATE", meta.date_str.data());
  }
}

}  // namespace

RestartMeta read_restart_meta(const std::string& path) {
  ScopedNcFile ncid;
  NC_CHECK(nc_open(path.c_str(), NC_NOWRITE, ncid.ptr()));
  RestartMeta meta;
  read_meta(ncid, path, meta);
  return meta;
}

void read_restart(const std::string& path, RestartMeta& meta,
                  std::vector<VarView>& vars) {
  ScopedNcFile ncid;
  NC_CHECK(nc_open(path.c_str(), NC_NOWRITE, ncid.ptr()));
  read_meta(ncid, path, meta);

  // Read each requested variable if present in the restart file
  for (auto& v : vars) {
    int varid = -1;
    int rc = nc_inq_varid(ncid, v.name.c_str(), &varid);
    if (rc == NC_ENOTVAR)  // every field the run carries must come back, or the restart is not exact
      throw std::runtime_error("read_restart: missing variable '" + v.name + "' in restart file '" + path + "'");
    NC_CHECK(rc);

    const int nx = v.nx > 0 ? v.nx : 1;
    const int ny = v.ny > 0 ? v.ny : 1;
    const int nz = v.nz > 0 ? v.nz : 1;
    size_t count = size_t(nx) * ny * nz;

    // Check variable dimension in file (R1 heap overflow prevention)
    int ndims = 0;
    NC_CHECK(nc_inq_varndims(ncid, varid, &ndims));
    std::vector<int> dimids(ndims);
    NC_CHECK(nc_inq_vardimid(ncid, varid, dimids.data()));
    size_t file_count = 1;
    for (int d = 0; d < ndims; ++d) {
      size_t dlen = 0;
      NC_CHECK(nc_inq_dimlen(ncid, dimids[d], &dlen));
      file_count *= dlen;
    }
    if (file_count != count) {
      throw std::runtime_error("read_restart: variable '" + v.name + "' dimension mismatch: file has " +
                               std::to_string(file_count) + " elements, buffer expects " + std::to_string(count));
    }

    const std::ptrdiff_t sj = (v.sj != 0 || v.sk != 0) ? v.sj : nx;
    const std::ptrdiff_t sk = v.sk != 0 ? v.sk : (std::ptrdiff_t)nx * ny;
    bool is_contiguous = (sj == nx && sk == (std::ptrdiff_t)nx * ny);

    if (v.dtype == DType::F64) {
      double* dst = static_cast<double*>(const_cast<void*>(v.data));
      if (is_contiguous) {
        NC_CHECK(nc_get_var_double(ncid, varid, dst));
      } else {
        std::vector<double> buf(count);
        NC_CHECK(nc_get_var_double(ncid, varid, buf.data()));
        for (int k = 0; k < nz; ++k)
          for (int j = 0; j < ny; ++j)
            for (int ii = 0; ii < nx; ++ii)
              dst[ii + j * sj + k * sk] = buf[(size_t(k) * ny + j) * nx + ii];
      }
    } else {
      float* dst = static_cast<float*>(const_cast<void*>(v.data));
      if (is_contiguous) {
        NC_CHECK(nc_get_var_float(ncid, varid, dst));
      } else {
        std::vector<float> buf(count);
        NC_CHECK(nc_get_var_float(ncid, varid, buf.data()));
        for (int k = 0; k < nz; ++k)
          for (int j = 0; j < ny; ++j)
            for (int ii = 0; ii < nx; ++ii)
              dst[ii + j * sj + k * sk] = buf[(size_t(k) * ny + j) * nx + ii];
      }
    }
  }
}

}  // namespace cppwrf::io_netcdf
