// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include "core/backend.hpp"
#include "core/constants.hpp"
#include "core/field.hpp"
#include "dyn/diffusion/diffusion_params.hpp"

namespace cppwrf::dyn::diffusion {

// Ported from WRF v4.8.0 dyn_em/module_diffusion_em.F: compute_diff_metrics (lines 6882-7130)
// Computes physical vertical grid distances and metric slopes:
//   z_at_w = (ph + phb) / g
//   rdzw   = 1 / (z_at_w(k+1) - z_at_w(k)) at mass points
//   rdz    = 2 / (z_at_w(k+1) - z_at_w(k-1)) at w levels (and 2/(z1 - z0) at k=0)
//   z      = 0.5 * (ph(k) + phb(k) + ph(k+1) + phb(k+1)) / g at mass points
//   zx     = rdx * (phb(i) - phb(i-1) + ph(i) - ph(i-1)) / g at u points
//   zy     = rdy * (phb(j) - phb(j-1) + ph(j) - ph(j-1)) / g at v points

struct KDiffMetricsZ {
  View3<const real> ph;
  BView3<const real> phb;
  View3<real> z, rdz, rdzw;
  int nz;
  static constexpr real Gr = real(cst::g);

  CPPWRF_HD void operator()(int i, int j) const {
    // 128 max levels fits in stack registers
    real zw[128];
    for (int k = 0; k <= nz; ++k) {
      zw[k] = (ph(i, j, k) + phb(i, j, k)) / Gr;
    }
    for (int k = 0; k < nz; ++k) {
      rdzw(i, j, k) = real(1.0) / (zw[k + 1] - zw[k]);
      z(i, j, k) = real(0.5) * (ph(i, j, k) + phb(i, j, k) + ph(i, j, k + 1) + phb(i, j, k + 1)) / Gr;
    }
    rdz(i, j, 0) = real(2.0) / (zw[1] - zw[0]);
    for (int k = 1; k < nz; ++k) {
      rdz(i, j, k) = real(2.0) / (zw[k + 1] - zw[k - 1]);
    }
  }
};

struct KDiffMetricsZX {
  View3<const real> ph;
  BView3<const real> phb;
  View3<real> zx;
  real rdx;
  int nx;
  // 0: not periodic; 1: periodic, the points across the boundary by their own indices; 2: by the halo (a
  // decomposed run with several patches along the direction: the halo holds the same values)
  int periodic_x;
  bool open_copy;  // specified / open / nested boundaries: set_physical_bc3d copies the last column
  int ktop_unset;   // periodic: top w level left 0 on the boundary faces (-1: none)
  static constexpr real Gr = real(cst::g);

  CPPWRF_HD void operator()(int i, int j, int k) const {
    if (k == ktop_unset && (i == 0 || i == nx)) {
      zx(i, j, k) = real(0);
    } else if (!periodic_x && (i == 0 || (i == nx && !open_copy))) {
      zx(i, j, k) = real(0);
    } else if (!periodic_x && i == nx) {  // set_physical_bc3d(zx, 'e'), specified: zx(ide) = zx(ide-1)
      const int ii = nx - 1;
      real v = rdx * (phb(ii, j, k) - phb(ii - 1, j, k)) / Gr;
      v += rdx * (ph(ii, j, k) - ph(ii - 1, j, k)) / Gr;
      zx(i, j, k) = v;
    } else {
      int i0 = (i == nx && periodic_x != 2) ? 0 : i;
      int im1 = (i == 0 && periodic_x != 2) ? nx - 1 : (i - 1);
      real v = rdx * (phb(i0, j, k) - phb(im1, j, k)) / Gr;
      v += rdx * (ph(i0, j, k) - ph(im1, j, k)) / Gr;
      zx(i, j, k) = v;
    }
  }
};

struct KDiffMetricsZY {
  View3<const real> ph;
  BView3<const real> phb;
  View3<real> zy;
  real rdy;
  int ny;
  int periodic_y;  // as KDiffMetricsZX
  bool open_copy;
  int ktop_unset;
  static constexpr real Gr = real(cst::g);

  CPPWRF_HD void operator()(int i, int j, int k) const {
    if (k == ktop_unset && (j == 0 || j == ny)) {
      zy(i, j, k) = real(0);
    } else if (!periodic_y && (j == 0 || (j == ny && !open_copy))) {
      zy(i, j, k) = real(0);
    } else if (!periodic_y && j == ny) {  // set_physical_bc3d(zy, 'f'), specified: zy(jde) = zy(jde-1)
      const int jj = ny - 1;
      real v = rdy * (phb(i, jj, k) - phb(i, jj - 1, k)) / Gr;
      v += rdy * (ph(i, jj, k) - ph(i, jj - 1, k)) / Gr;
      zy(i, j, k) = v;
    } else {
      int j0 = (j == ny && periodic_y != 2) ? 0 : j;
      int jm1 = (j == 0 && periodic_y != 2) ? ny - 1 : (j - 1);
      real v = rdy * (phb(i, j0, k) - phb(i, jm1, k)) / Gr;
      v += rdy * (ph(i, j0, k) - ph(i, jm1, k)) / Gr;
      zy(i, j, k) = v;
    }
  }
};

inline void compute_diff_metrics(const DiffusionParams& p,
                                 View3<const real> ph,
                                 BView3<const real> phb,
                                 View3<real> z,
                                 View3<real> rdz,
                                 View3<real> rdzw,
                                 View3<real> zx,
                                 View3<real> zy,
                                 real rdx, real rdy,
                                 int nx, int ny, int nz,
                                 bool physical_bc = false) {
  // physical_bc: also set_physical_bc3d(zx, 'e') / (zy, 'f'), which first_rk_step_part2 calls after
  // compute_diff_metrics (specified / open boundaries copy the last column / row). Periodic: WRF computes
  // zx from ids+1 and zy from jds+1 (module_diffusion_em.F:6988, 7004); the boundary faces come from the
  // periodic copy of set_physical_bc3d (module_first_rk_step_part2.F:478-490), whose k range ends at the
  // caller's k_end = kpe below the top w level (share/module_bc.F:721, 726), so there they stay 0
  const int ktop_x = physical_bc && p.periodic_x ? nz : -1, ktop_y = physical_bc && p.periodic_y ? nz : -1;
  // Column-wise vertical metrics
  column_for(Range2D{0, nx, 0, ny}, KDiffMetricsZ{ph, phb, z, rdz, rdzw, nz});
  // zx at U points: i = 0..nx, j = 0..ny-1, k = 0..nz
  parallel_for(Range3D{0, nx + 1, 0, ny, 0, nz + 1},
               KDiffMetricsZX{ph, phb, zx, rdx, nx, p.wrap_x(), physical_bc && (p.specified || p.open_xe), ktop_x});
  // zy at V points: i = 0..nx-1, j = 0..ny, k = 0..nz
  parallel_for(Range3D{0, nx, 0, ny + 1, 0, nz + 1},
               KDiffMetricsZY{ph, phb, zy, rdy, ny, p.wrap_y(), physical_bc && (p.specified || p.open_ye), ktop_y});
}

}  // namespace cppwrf::dyn::diffusion
