// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Interface between the dycore time step and the column physics suite of a real-data run
// (radiation, surface layer, land surface, PBL, cumulus). The suite lives in src/phys/driver/
// the dycore only calls it at WRF's points of the time step (solve_em):
//   RK stage 1, after rk_step_prep and init_zero_tendency (LargeStep::zero_tendf):
//     part1  = first_rk_step_part1: phy_prep, radiation_driver, surface_driver, pbl_driver,
//              cumulus_driver (updates the surface state, fills the uncoupled R*TEN fields; the MYNN
//              PBL writes qke_adv of WRF's scalar array, both time levels as rk_update_scalar's copy)
//   RK stage 1, before the stage-1 diffusion and the rest of rk_tendency:
//     part2  = first_rk_step_part2: calculate_phy_tend, update_phy_ten (adds into t.ru_tendf,
//              t.rv_tendf, t.t_tendf, t.q_tendf; the diffusion is added after it, as in WRF)
//   after the RK loop, before microphysics:
//     after_rk = phy_prep_part2 (decouples the persistent R*TEN fields with the new mut)
//   at the end of the step (after the microphysics, spec_bdy_final and set_w_surface):
//     after_all_rk_steps = module_after_all_rk_steps.F (the diagnostics driver)
#include "dyn/state.hpp"

namespace cppwrf::dyn {

class ColumnPhysics {
 public:
  virtual ~ColumnPhysics() = default;
  virtual void part1(State& s, const BaseState& b, Tendencies& t) = 0;
  virtual void part2(const State& s, const BaseState& b, Tendencies& t) = 0;
  virtual void after_rk(const State& s, const BaseState& b) = 0;
  virtual void after_all_rk_steps() {}
  // Advective forcing for cumulus schemes that need it (WRF RTHFTEN / RQVFTEN, set_tend in
  // rk_tendency and rk_scalar_tend: theta / qv advection tendency * msfty, every RK stage).
  // nullptr: not wanted.
  virtual Field3* th_forcing() { return nullptr; }
  virtual Field3* qv_forcing() { return nullptr; }
};

}  // namespace cppwrf::dyn
