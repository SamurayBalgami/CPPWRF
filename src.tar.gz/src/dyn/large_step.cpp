// SPDX-License-Identifier: GPL-3.0-or-later
#include "dyn/large_step.hpp"
#include "core/tiles.hpp"
#include "core/vm_dump.hpp"

#include <stdexcept>

#include "core/constants.hpp"
#include "core/halo.hpp"
#include "dyn/diffusion_driver.hpp"
#include "dyn/kernels_common.hpp"
#include "dyn/lateral_bc.hpp"

// Formulas follow TN ch. 3 (flux-form, perturbation equations 3.3-3.8 evaluated at t*) in
// the discrete form of WRF dyn_em (module_big_step_utilities_em.F, module_advect_em.F).
// C++ k = Fortran k - 1. Map factors (msf*), Coriolis (coriolis) and curvature terms follow WRF;
// idealized cases have m = 1, f = e = 0. Moisture via kern::MoistCoef (calc_cq).

namespace cppwrf::dyn {
namespace {

using V3 = View3<real>;
using C3 = View3<const real>;
using V2 = View2<real>;
using C2 = View2<const real>;
using B3 = BView3<const real>;
using B2 = BView2<const real>;
constexpr real Gr = real(cst::g);
constexpr real H = real(0.5);
constexpr real Q = real(0.25);
constexpr real RERADIUS = real(1. / 6370.0e03);  // WRF module_model_constants reradius

using kern::flux3;
using kern::flux5;

// FP64 builds: the tendency kernels' advection fluxes are computed once per face (KFace into fxs, fys, fzs, the
// same expressions) and read by both cells of the face; FP32 builds compute them per cell as before (nvcc
// contracts a*b + c there depending on the code around it, so the FP32 code stays as it is)
#if defined(CPPWRF_DOUBLE)
#define CPPWRF_FACES C3 fxs, fys, fzs; bool stored = false;
#define CPPWRF_FACE_STORED(F) \
  if (stored) return F(i, j, k);
#else
#define CPPWRF_FACES
#define CPPWRF_FACE_STORED(F)
#endif

// ---------------------------------------------------------------- rk_step_prep
struct KMu {  // calc_mu_uv: full column masses at stage
  C2 mu; B2 mub; V2 mut, muu, muv;
  int nx, ny, nyv; bool spx, spy;  // specified: boundary faces take the adjacent column's mass
  CPPWRF_HD void operator()(int i, int j, int) const {
    if (i < nx && j < ny) mut(i, j) = mu(i, j) + mub(i, j);
    if (j < ny) {
      // WRF calc_mu_uv: 0.5*(MU(i)+MU(i-1)+MUB(i)+MUB(i-1)); at a non-periodic edge the column is doubled
      if (spx && i == 0) muu(i, j) = H * (mu(0, j) + mu(0, j) + mub(0, j) + mub(0, j));
      else if (spx && i == nx) muu(i, j) = H * (mu(nx - 1, j) + mu(nx - 1, j) + mub(nx - 1, j) + mub(nx - 1, j));
      else muu(i, j) = H * (mu(i, j) + mu(i - 1, j) + mub(i, j) + mub(i - 1, j));
    }
    if (i < nx && j < nyv) {
      if (spy && j == 0) muv(i, j) = H * (mu(i, 0) + mu(i, 0) + mub(i, 0) + mub(i, 0));
      else if (spy && j == ny) muv(i, j) = H * (mu(i, ny - 1) + mu(i, ny - 1) + mub(i, ny - 1) + mub(i, ny - 1));
      else muv(i, j) = H * (mu(i, j) + mu(i, j - 1) + mub(i, j) + mub(i, j - 1));
    }
  }
};

struct KPrep3 {  // couple_momentum, calc_alt, calc_php
  C3 u, v, w, al, ph; C2 muu, muv, mut; B3 alb, phb; B2 msfuy, msfvx_inv, msfty; VCoef c;
  V3 ru, rv, rw, alt, php;
  int nx, ny, nyv, nz;
  CPPWRF_HD void operator()(int i, int j, int k) const {
    if (j < ny && k < nz) ru(i, j, k) = u(i, j, k) * (c.c1h(k) * muu(i, j) + c.c2h(k)) / msfuy(i, j);
    if (i < nx && j < nyv && k < nz) rv(i, j, k) = v(i, j, k) * (c.c1h(k) * muv(i, j) + c.c2h(k)) * msfvx_inv(i, j);
    if (i < nx && j < ny) rw(i, j, k) = w(i, j, k) * (c.c1f(k) * mut(i, j) + c.c2f(k)) / msfty(i, j);
    if (i < nx && j < ny && k < nz) {
      alt(i, j, k) = al(i, j, k) + alb(i, j, k);
      php(i, j, k) = H * (phb(i, j, k) + phb(i, j, k + 1) + ph(i, j, k) + ph(i, j, k + 1));
    }
  }
};

struct KWW {  // calc_ww_cp: mass-coupled eta velocity from the column-integrated divergence
  // WRF recomputes its own MUU/MUV here, summed as 0.5*(MUP(i)+MUB(i)+MUP(i-1)+MUB(i-1)) (a different
  // order from calc_mu_uv) and with the halo column at the domain edge
  C3 u, v; C2 mu; B2 mub; V3 ww; B2 msftx, msfuy, msfvx_inv; VCoef c; real rdx, rdy; int nz;
  CPPWRF_HD real mu_u(int i, int j) const { return H * (mu(i, j) + mub(i, j) + mu(i - 1, j) + mub(i - 1, j)); }
  CPPWRF_HD real mu_v(int i, int j) const { return H * (mu(i, j) + mub(i, j) + mu(i, j - 1) + mub(i, j - 1)); }
  CPPWRF_HD real divv(int i, int j, int k) const {
    const real mu1 = mu_u(i + 1, j), mu0 = mu_u(i, j), mv1 = mu_v(i, j + 1), mv0 = mu_v(i, j);
    return msftx(i, j) * c.dnw(k) *
           (rdx * ((c.c1h(k) * mu1 + c.c2h(k)) * u(i + 1, j, k) / msfuy(i + 1, j) -
                   (c.c1h(k) * mu0 + c.c2h(k)) * u(i, j, k) / msfuy(i, j)) +
            rdy * ((c.c1h(k) * mv1 + c.c2h(k)) * v(i, j + 1, k) * msfvx_inv(i, j + 1) -
                   (c.c1h(k) * mv0 + c.c2h(k)) * v(i, j, k) * msfvx_inv(i, j)));
  }
  CPPWRF_HD void operator()(int i, int j) const {
    real dmdt = 0;
    for (int k = 0; k < nz; ++k) dmdt += divv(i, j, k);
    real w = 0;
    ww(i, j, 0) = 0;
    for (int k = 1; k < nz; ++k) {
      w = w - c.dnw(k - 1) * c.c1h(k - 1) * dmdt - divv(i, j, k - 1);
      ww(i, j, k) = w;
    }
    ww(i, j, nz) = 0;
  }
};

// Map factors and Coriolis parameters of the base state, for the tendency kernels.
// cor / mapped false: f = e = 0 resp. uniform map factors, so the Coriolis terms and the
// map-factor-gradient part of curvature are exactly zero and are skipped (same result).
struct MapC {
  B2 msftx, msfty, msfux, msfuy, msfvx, msfvy, msfvx_inv, f, e, sina, cosa;
  bool cor, mapped;
  static MapC from(const BaseState& b, bool cor) {
    return MapC{b.msftx.view(), b.msfty.view(), b.msfux.view(), b.msfuy.view(), b.msfvx.view(), b.msfvy.view(),
                b.msfvx_inv.view(), b.f.view(), b.e.view(), b.sina.view(), b.cosa.view(), cor, b.mapped};
  }
  // curvature: vxgm at mass point (i,j,k) from the uncoupled u, v
  CPPWRF_HD real vxgm(C3 u, C3 v, real rdx, real rdy, int i, int j, int k) const {
    return H * (u(i, j, k) + u(i + 1, j, k)) * (msfvx(i, j + 1) - msfvx(i, j)) * rdy -
           H * (v(i, j, k) + v(i, j + 1, k)) * (msfuy(i + 1, j) - msfuy(i, j)) * rdx;
  }
};

struct KCq {  // calc_cq
  static constexpr int kMax = 8;
  C3 q[kMax]; int n;
  V3 cqu, cqv, cqw; int nx, ny, nyv, nz;
  CPPWRF_HD void operator()(int i, int j, int k) const {
    if (j < ny) {
      real t = 0;
      for (int s = 0; s < n; ++s) t = t + q[s](i, j, k) + q[s](i - 1, j, k);
      cqu(i, j, k) = real(1) / (real(1) + real(0.5) * t);
    }
    if (i < nx && j < nyv) {
      real t = 0;
      for (int s = 0; s < n; ++s) t = t + q[s](i, j, k) + q[s](i, j - 1, k);
      cqv(i, j, k) = real(1) / (real(1) + real(0.5) * t);
    }
    if (i < nx && j < ny && k >= 1) {
      real t = 0;
      for (int s = 0; s < n; ++s) t = t + q[s](i, j, k) + q[s](i, j, k - 1);
      cqw(i, j, k) = real(0.5) * t;
    }
  }
};

// ---------------------------------------------------------------- rk_tendency
// U: advect_u (5th horizontal, 3rd vertical) + horizontal_pressure_gradient (+ ru_tendf)
struct KTendU {
  C3 u, ru, rv, ww, p, ph, alt, al, php, tendf; C2 mu, muu; B3 pb; VCoef c; kern::MoistCoef mc;
  V3 out; real rdx, rdy; int nz; bool do_y, top_lid, use_tendf; real hup, vup;
  C3 v, rw; MapC m; kern::Spec sp;
  C2 mut;  // open boundaries: radiation phase speed cb times the column mass
  CPPWRF_HD real fx(int i, int j, int k) const {
    CPPWRF_FACE_STORED(fxs)
    const int o = kern::ord_mass(i, sp.nx, sp.x);
    if (o == 2) {  // next to the boundary: specified uses the upstream normal velocity at the boundary face
      if (i <= 1) {
        const real ub = (sp.sx() && u(i, j, k) < real(0)) ? u(i, j, k) : u(i - 1, j, k);
        return Q * (ru(i, j, k) + ru(i - 1, j, k)) * (u(i, j, k) + ub);
      }
      const real ub = (sp.sx() && u(i - 1, j, k) > real(0)) ? u(i - 1, j, k) : u(i, j, k);
      return Q * (ru(i, j, k) + ru(i - 1, j, k)) * (u(i - 1, j, k) + ub);
    }
    real vel = H * (ru(i, j, k) + ru(i - 1, j, k));
    if (o == 3) return vel * flux3(u(i - 2, j, k), u(i - 1, j, k), u(i, j, k), u(i + 1, j, k), vel, hup);
    return vel * flux5(u(i - 3, j, k), u(i - 2, j, k), u(i - 1, j, k), u(i, j, k), u(i + 1, j, k), u(i + 2, j, k), vel, hup);
  }
  CPPWRF_HD real fy(int i, int j, int k) const {
    CPPWRF_FACE_STORED(fys)
    const int o = kern::ord_face(j, sp.ny, sp.y);
    if (o == 2) return Q * (rv(i, j, k) + rv(i - 1, j, k)) * (u(i, j, k) + u(i, j - 1, k));
    real vel = H * (rv(i, j, k) + rv(i - 1, j, k));
    if (o == 3) return vel * flux3(u(i, j - 2, k), u(i, j - 1, k), u(i, j, k), u(i, j + 1, k), vel, hup);
    return vel * flux5(u(i, j - 3, k), u(i, j - 2, k), u(i, j - 1, k), u(i, j, k), u(i, j + 1, k), u(i, j + 2, k), vel, hup);
  }
  CPPWRF_HD real fz(int i, int j, int k) const {
    CPPWRF_FACE_STORED(fzs)
    if (k == 0 || k == nz) return 0;
    real vel = H * (ww(i - 1, j, k) + ww(i, j, k));
    if (k == 1 || k == nz - 1) return vel * (c.fnm(k) * u(i, j, k) + c.fnp(k) * u(i, j, k - 1));
    return vel * flux3(u(i, j, k - 2), u(i, j, k - 1), u(i, j, k), u(i, j, k + 1), -vel, vup);
  }
  CPPWRF_HD real pu(int i, int j, int k) const { return p(i - 1, j, k) + p(i, j, k); }
  CPPWRF_HD real dpn(int i, int j, int k) const {  // p' at w level k, u column (x2 averaged)
    if (k == 0) return H * (c.cf1 * pu(i, j, 0) + c.cf2 * pu(i, j, 1) + c.cf3 * pu(i, j, 2));
    if (k == nz) return top_lid ? H * (c.cfn * pu(i, j, nz - 1) + c.cfn1 * pu(i, j, nz - 2)) : real(0);
    return H * (c.fnm(k) * pu(i, j, k) + c.fnp(k) * pu(i, j, k - 1));
  }
  // advect_u open_ys / open_ye: v-flux terms of the outermost rows (i over WRF's i_start..i_end)
  CPPWRF_HD real open_y_term(int i, int j, int k) const {
    const int imin = 0, imax = sp.nx - 1;
    const int ip = i < imax ? i : imax, im = i - 1 > imin ? i - 1 : imin;
    const real mrdy = m.msfux(i, j) * rdy;
    if (j == 0) {
      const real vw = H * (rv(ip, 0, k) + rv(im, 0, k));
      const real vb = vw < real(0) ? vw : real(0);
      const real dvm = rv(ip, 1, k) - rv(ip, 0, k), dvp = rv(im, 1, k) - rv(im, 0, k);
      return mrdy * (vb * (u(i, 1, k) - u(i, 0, k)) + H * u(i, 0, k) * (dvm + dvp));
    }
    const int je = sp.ny;  // v face of the north boundary
    const real vw = H * (rv(ip, je, k) + rv(im, je, k));
    const real vb = vw > real(0) ? vw : real(0);
    const real dvm = rv(ip, je, k) - rv(ip, je - 1, k), dvp = rv(im, je, k) - rv(im, je - 1, k);
    return mrdy * (vb * (u(i, je - 1, k) - u(i, je - 2, k)) + H * u(i, je - 1, k) * (dvm + dvp));
  }
  CPPWRF_HD void operator()(int i, int j, int k) const {
    if (sp.ox && (i == 0 || i == sp.nx)) {
      // open x boundary face: no horizontal flux divergence, no pressure gradient, Coriolis or
      // curvature; the radiation condition with phase speed cb (module_advect_em advect_u) and,
      // unless open_ys/ye (WRF's i range of the vertical term), the vertical advection
      real t;
      if (i == 0) {
        real ub = ru(0, j, k) - real(cst::cb) * (c.c1h(k) * mut(0, j) + c.c2h(k));
        ub = ub < real(0) ? ub : real(0);
        t = real(0) - rdx * ub * (u(1, j, k) - u(0, j, k));
      } else {
        real ub = ru(i, j, k) + real(cst::cb) * (c.c1h(k) * mut(i - 1, j) + c.c2h(k));
        ub = ub > real(0) ? ub : real(0);
        t = real(0) - rdx * ub * (u(i, j, k) - u(i - 1, j, k));
      }
      if (!sp.oy) t -= c.rdnw(k) * (fz(i, j, k + 1) - fz(i, j, k));
      if (use_tendf) t += tendf(i, j, k) / m.msfuy(i, j);  // rk_addtend_dry
      out(i, j, k) = t;
      return;
    }
    // advect_u: horizontal terms times msfux (ADT eq. 44), vertical term without
    real t = -(m.msfux(i, j) * rdx) * (fx(i + 1, j, k) - fx(i, j, k));
    if (do_y) {
      // open_ys/ye: the y flux divergence skips the outermost rows, which take the open terms
      const bool orow = sp.oy && (j == 0 || j == sp.ny - 1);
      if (!orow) t -= (m.msfux(i, j) * rdy) * (fy(i, j + 1, k) - fy(i, j, k));
      else t -= open_y_term(i, j, k);
    }
    if (!(sp.oy && sp.x && (i == 0 || i == sp.nx))) t -= c.rdnw(k) * (fz(i, j, k + 1) - fz(i, j, k));
    // horizontal_pressure_gradient (non-hydrostatic)
    const real rm = m.msfux(i, j) / m.msfuy(i, j);
    real dpx = rm * H * rdx * (c.c1h(k) * muu(i, j) + c.c2h(k)) *
               ((ph(i, j, k + 1) - ph(i - 1, j, k + 1) + ph(i, j, k) - ph(i - 1, j, k)) +
                (alt(i, j, k) + alt(i - 1, j, k)) * (p(i, j, k) - p(i - 1, j, k)) +
                (al(i, j, k) + al(i - 1, j, k)) * (pb(i, j, k) - pb(i - 1, j, k)));
    dpx += rm * rdx * (php(i, j, k) - php(i - 1, j, k)) *
           (c.rdnw(k) * (dpn(i, j, k + 1) - dpn(i, j, k)) - H * (c.c1h(k) * mu(i - 1, j) + c.c1h(k) * mu(i, j)));
    t -= mc.cqu(i, j, k) * dpx;
    // coriolis
    const real rv4 = Q * (rv(i - 1, j + 1, k) + rv(i, j + 1, k) + rv(i - 1, j, k) + rv(i, j, k));
    const real rw4 = Q * (rw(i - 1, j, k + 1) + rw(i - 1, j, k) + rw(i, j, k + 1) + rw(i, j, k));
    if (m.cor)
      t = t + rm * H * (m.f(i, j) + m.f(i - 1, j)) * rv4 -
          H * (m.e(i, j) + m.e(i - 1, j)) * H * (m.cosa(i, j) + m.cosa(i - 1, j)) * rw4;
    // curvature (map_proj != 6)
    if (m.mapped)
      t = t + H * (m.vxgm(u, v, rdx, rdy, i, j, k) + m.vxgm(u, v, rdx, rdy, i - 1, j, k)) * rv4 -
          u(i, j, k) * RERADIUS * rw4;
    else
      t = t - u(i, j, k) * RERADIUS * rw4;
    if (use_tendf) t += tendf(i, j, k) / m.msfuy(i, j);  // rk_addtend_dry
    out(i, j, k) = t;
  }
  CPPWRF_FACES  // after the other members (aggregate initialisation)
};

// V: advect_v + horizontal_pressure_gradient (y part); 3D runs only
struct KTendV {
  C3 v, ru, rv, ww, p, ph, alt, al, php, tendf; C2 mu, muv; B3 pb; VCoef c; kern::MoistCoef mc;
  V3 out; real rdx, rdy; int nz; bool top_lid, use_tendf; real hup, vup;
  C3 u, rw; MapC m; kern::Spec sp;
  CPPWRF_HD real fx(int i, int j, int k) const {
    CPPWRF_FACE_STORED(fxs)
    const int o = kern::ord_face(i, sp.nx, sp.x);
    if (o == 2) return Q * (ru(i, j, k) + ru(i, j - 1, k)) * (v(i, j, k) + v(i - 1, j, k));
    real vel = H * (ru(i, j, k) + ru(i, j - 1, k));
    if (o == 3) return vel * flux3(v(i - 2, j, k), v(i - 1, j, k), v(i, j, k), v(i + 1, j, k), vel, hup);
    return vel * flux5(v(i - 3, j, k), v(i - 2, j, k), v(i - 1, j, k), v(i, j, k), v(i + 1, j, k), v(i + 2, j, k), vel, hup);
  }
  CPPWRF_HD real fy(int i, int j, int k) const {
    CPPWRF_FACE_STORED(fys)
    const int o = kern::ord_mass(j, sp.ny, sp.y);
    if (o == 2) {  // specified: upstream normal velocity at the boundary face
      if (j <= 1) {
        const real vb = (sp.sy() && v(i, j, k) < real(0)) ? v(i, j, k) : v(i, j - 1, k);
        return Q * (rv(i, j, k) + rv(i, j - 1, k)) * (v(i, j, k) + vb);
      }
      const real vb = (sp.sy() && v(i, j - 1, k) > real(0)) ? v(i, j - 1, k) : v(i, j, k);
      return Q * (rv(i, j, k) + rv(i, j - 1, k)) * (vb + v(i, j - 1, k));
    }
    real vel = H * (rv(i, j, k) + rv(i, j - 1, k));
    if (o == 3) return vel * flux3(v(i, j - 2, k), v(i, j - 1, k), v(i, j, k), v(i, j + 1, k), vel, hup);
    return vel * flux5(v(i, j - 3, k), v(i, j - 2, k), v(i, j - 1, k), v(i, j, k), v(i, j + 1, k), v(i, j + 2, k), vel, hup);
  }
  CPPWRF_HD real fz(int i, int j, int k) const {
    CPPWRF_FACE_STORED(fzs)
    if (k == 0 || k == nz) return 0;
    real vel = H * (ww(i, j - 1, k) + ww(i, j, k));
    if (k == 1 || k == nz - 1) return vel * (c.fnm(k) * v(i, j, k) + c.fnp(k) * v(i, j, k - 1));
    return vel * flux3(v(i, j, k - 2), v(i, j, k - 1), v(i, j, k), v(i, j, k + 1), -vel, vup);
  }
  CPPWRF_HD real pv(int i, int j, int k) const { return p(i, j - 1, k) + p(i, j, k); }
  CPPWRF_HD real dpn(int i, int j, int k) const {
    if (k == 0) return H * (c.cf1 * pv(i, j, 0) + c.cf2 * pv(i, j, 1) + c.cf3 * pv(i, j, 2));
    if (k == nz) return top_lid ? H * (c.cfn * pv(i, j, nz - 1) + c.cfn1 * pv(i, j, nz - 2)) : real(0);
    return H * (c.fnm(k) * pv(i, j, k) + c.fnp(k) * pv(i, j, k - 1));
  }
  // advect_v open_xs / open_xe: u-flux terms of the outermost columns
  CPPWRF_HD real open_x_term(int i, int j, int k) const {
    const int jmin = 0, jmax = sp.ny - 1;
    const int jp = j < jmax ? j : jmax, jm = j - 1 > jmin ? j - 1 : jmin;
    if (i == 0) {
      const real mrdx = m.msfvy(0, j) * rdx;
      const real uw = H * (ru(0, jp, k) + ru(0, jm, k));
      const real ub = uw < real(0) ? uw : real(0);
      const real dup = ru(1, jp, k) - ru(0, jp, k), dum = ru(1, jm, k) - ru(0, jm, k);
      return mrdx * (ub * (v(1, j, k) - v(0, j, k)) + H * v(0, j, k) * (dup + dum));
    }
    const int ie = sp.nx;  // u face of the east boundary
    const real mrdx = m.msfvy(ie - 1, j) * rdx;
    const real uw = H * (ru(ie, jp, k) + ru(ie, jm, k));
    const real ub = uw > real(0) ? uw : real(0);
    const real dup = ru(ie, jp, k) - ru(ie - 1, jp, k), dum = ru(ie, jm, k) - ru(ie - 1, jm, k);
    return mrdx * (ub * (v(ie - 1, j, k) - v(ie - 2, j, k)) + H * v(ie - 1, j, k) * (dup + dum));
  }
  C2 mut;  // open boundaries: radiation phase speed cb times the column mass
  CPPWRF_HD void operator()(int i, int j, int k) const {
    if (sp.oy && (j == 0 || j == sp.ny)) {  // open y boundary face: radiation only (advect_v)
      real t;
      if (j == 0) {
        real vb = rv(i, 0, k) - real(cst::cb) * (c.c1h(k) * mut(i, 0) + c.c2h(k));
        vb = vb < real(0) ? vb : real(0);
        t = real(0) - rdy * vb * (v(i, 1, k) - v(i, 0, k));
      } else {
        real vb = rv(i, j, k) + real(cst::cb) * (c.c1h(k) * mut(i, j - 1) + c.c2h(k));
        vb = vb > real(0) ? vb : real(0);
        t = real(0) - rdy * vb * (v(i, j, k) - v(i, j - 1, k));
      }
      if (use_tendf) t += tendf(i, j, k) * m.msfvx_inv(i, j);  // rk_addtend_dry
      out(i, j, k) = t;
      return;
    }
    // advect_v: horizontal terms times msfvy, vertical times msfvy/msfvx (ADT eq. 45)
    const real rm = m.msfvy(i, j) / m.msfvx(i, j);
    real t;
    if (sp.ox && (i == 0 || i == sp.nx - 1)) {  // open x: y flux, then the open term instead of the x flux
      t = -(m.msfvy(i, j) * rdy) * (fy(i, j + 1, k) - fy(i, j, k));
      t -= open_x_term(i, j, k);
    } else {
      t = -(m.msfvy(i, j) * rdx) * (fx(i + 1, j, k) - fx(i, j, k));
      t -= (m.msfvy(i, j) * rdy) * (fy(i, j + 1, k) - fy(i, j, k));
    }
    t -= rm * c.rdnw(k) * (fz(i, j, k + 1) - fz(i, j, k));
    real dpy = rm * H * rdy * (c.c1h(k) * muv(i, j) + c.c2h(k)) *
               ((ph(i, j, k + 1) - ph(i, j - 1, k + 1) + ph(i, j, k) - ph(i, j - 1, k)) +
                (alt(i, j, k) + alt(i, j - 1, k)) * (p(i, j, k) - p(i, j - 1, k)) +
                (al(i, j, k) + al(i, j - 1, k)) * (pb(i, j, k) - pb(i, j - 1, k)));
    dpy += rm * rdy * (php(i, j, k) - php(i, j - 1, k)) *
           (c.rdnw(k) * (dpn(i, j, k + 1) - dpn(i, j, k)) - H * (c.c1h(k) * mu(i, j - 1) + c.c1h(k) * mu(i, j)));
    t -= mc.cqv(i, j, k) * dpy;
    // coriolis
    const real ru4 = Q * (ru(i, j, k) + ru(i + 1, j, k) + ru(i, j - 1, k) + ru(i + 1, j - 1, k));
    const real rw4 = Q * (rw(i, j - 1, k + 1) + rw(i, j - 1, k) + rw(i, j, k + 1) + rw(i, j, k));
    if (m.cor)
      t = t - rm * H * (m.f(i, j) + m.f(i, j - 1)) * ru4 +
          rm * H * (m.e(i, j) + m.e(i, j - 1)) * H * (m.sina(i, j) + m.sina(i, j - 1)) * rw4;
    // curvature (map_proj != 6)
    if (m.mapped)
      t = t - H * (m.vxgm(u, v, rdx, rdy, i, j, k) + m.vxgm(u, v, rdx, rdy, i, j - 1, k)) * ru4 -
          rm * v(i, j, k) * RERADIUS * rw4;
    else
      t = t - rm * v(i, j, k) * RERADIUS * rw4;
    if (use_tendf) t += tendf(i, j, k) * m.msfvx_inv(i, j);  // rk_addtend_dry
    out(i, j, k) = t;
  }
  CPPWRF_FACES  // after the other members (aggregate initialisation)
};

// W (levels 1..nz): advect_w + pg_buoy_w (+ rw_tendf)
struct KTendW {
  C3 w, ru, rv, ww, p, tendf; C2 mu; B2 mub; VCoef c; kern::MoistCoef mc;
  V3 out; real rdx, rdy; int nz; bool do_y, use_tendf; real hup, vup;
  C3 u, v; MapC m; kern::Spec sp;
  C2 mut; real wd_dt, w_crit;  // w_damp (wd_dt = 0: off)
  CPPWRF_HD real rux(int i, int j, int k) const {  // ru interpolated to w level k
    if (k < nz) return c.fnm(k) * ru(i, j, k) + c.fnp(k) * ru(i, j, k - 1);
    return (real(2) - c.fnm(nz - 1)) * ru(i, j, nz - 1) - c.fnp(nz - 1) * ru(i, j, nz - 2);
  }
  CPPWRF_HD real rvy(int i, int j, int k) const {
    if (k < nz) return c.fnm(k) * rv(i, j, k) + c.fnp(k) * rv(i, j, k - 1);
    return (real(2) - c.fnm(nz - 1)) * rv(i, j, nz - 1) - c.fnp(nz - 1) * rv(i, j, nz - 2);
  }
  CPPWRF_HD real fx(int i, int j, int k) const {
    CPPWRF_FACE_STORED(fxs)
    real vel = rux(i, j, k);
    const int o = kern::ord_face(i, sp.nx, sp.x);
    if (o == 2) return H * vel * (w(i, j, k) + w(i - 1, j, k));
    if (o == 3) return vel * flux3(w(i - 2, j, k), w(i - 1, j, k), w(i, j, k), w(i + 1, j, k), vel, hup);
    return vel * flux5(w(i - 3, j, k), w(i - 2, j, k), w(i - 1, j, k), w(i, j, k), w(i + 1, j, k), w(i + 2, j, k), vel, hup);
  }
  CPPWRF_HD real fy(int i, int j, int k) const {
    CPPWRF_FACE_STORED(fys)
    real vel = rvy(i, j, k);
    const int o = kern::ord_face(j, sp.ny, sp.y);
    if (o == 2) return H * vel * (w(i, j, k) + w(i, j - 1, k));
    if (o == 3) return vel * flux3(w(i, j - 2, k), w(i, j - 1, k), w(i, j, k), w(i, j + 1, k), vel, hup);
    return vel * flux5(w(i, j - 3, k), w(i, j - 2, k), w(i, j - 1, k), w(i, j, k), w(i, j + 1, k), w(i, j + 2, k), vel, hup);
  }
  CPPWRF_HD real fz(int i, int j, int m) const {
#if defined(CPPWRF_DOUBLE)
    if (stored) return fzs(i, j, m);
#endif  // vertical flux at mass level m
    if (m == 0 || m == nz - 1) return real(0.25) * (ww(i, j, m + 1) + ww(i, j, m)) * (w(i, j, m + 1) + w(i, j, m));
    real vel = H * (ww(i, j, m + 1) + ww(i, j, m));
    return vel * flux3(w(i, j, m - 1), w(i, j, m), w(i, j, m + 1), w(i, j, m + 2), -vel, vup);
  }
  // advect_w open_xs/xe (open_ys/ye) terms of the outermost columns (rows); WRF's 2nd-order forms
  // of fzm/fzp-interpolated ru (rv), extrapolated at the lid
  CPPWRF_HD real open_x_term(int i, int j, int k) const {
    const int a = i == 0 ? 0 : sp.nx - 1, b = i == 0 ? 1 : sp.nx;  // faces: inner (b) / outer (a) side
    real uw, dru;
    if (k < nz) {
      uw = H * (c.fnm(k) * (ru(a, j, k) + ru(b, j, k)) + c.fnp(k) * (ru(a, j, k - 1) + ru(b, j, k - 1)));
      dru = c.fnm(k) * (ru(b, j, k) - ru(a, j, k)) + c.fnp(k) * (ru(b, j, k - 1) - ru(a, j, k - 1));
    } else {
      const real fm = real(2) - c.fnm(nz - 1), fp = c.fnp(nz - 1);
      uw = H * (fm * (ru(a, j, nz - 1) + ru(b, j, nz - 1)) - fp * (ru(a, j, nz - 2) + ru(b, j, nz - 2)));
      dru = fm * (ru(b, j, nz - 1) - ru(a, j, nz - 1)) - fp * (ru(b, j, nz - 2) - ru(a, j, nz - 2));
    }
    if (i == 0) {
      const real ub = uw < real(0) ? uw : real(0);
      return rdx * (ub * (w(1, j, k) - w(0, j, k)) + w(0, j, k) * dru);
    }
    const real ub = uw > real(0) ? uw : real(0);
    return rdx * (ub * (w(i, j, k) - w(i - 1, j, k)) + w(i, j, k) * dru);
  }
  CPPWRF_HD real open_y_term(int i, int j, int k) const {
    const int a = j == 0 ? 0 : sp.ny - 1, b = j == 0 ? 1 : sp.ny;
    real vw, drv;
    if (k < nz) {
      vw = H * (c.fnm(k) * (rv(i, a, k) + rv(i, b, k)) + c.fnp(k) * (rv(i, a, k - 1) + rv(i, b, k - 1)));
      drv = c.fnm(k) * (rv(i, b, k) - rv(i, a, k)) + c.fnp(k) * (rv(i, b, k - 1) - rv(i, a, k - 1));
    } else {
      const real fm = real(2) - c.fnm(nz - 1), fp = c.fnp(nz - 1);
      vw = H * (fm * (rv(i, a, nz - 1) + rv(i, b, nz - 1)) - fp * (rv(i, a, nz - 2) + rv(i, b, nz - 2)));
      drv = fm * (rv(i, b, nz - 1) - rv(i, a, nz - 1)) - fp * (rv(i, b, nz - 2) - rv(i, a, nz - 2));
    }
    if (j == 0) {
      const real vb = vw < real(0) ? vw : real(0);
      return rdy * (vb * (w(i, 1, k) - w(i, 0, k)) + w(i, 0, k) * drv);
    }
    const real vb = vw > real(0) ? vw : real(0);
    return rdy * (vb * (w(i, j, k) - w(i, j - 1, k)) + w(i, j, k) * drv);
  }
  CPPWRF_HD void operator()(int i, int j, int k) const {
    // advect_w: horizontal terms times msftx (ADT eq. 46 / my)
    real t;
    const bool ocol = sp.ox && (i == 0 || i == sp.nx - 1), orow = sp.oy && (j == 0 || j == sp.ny - 1);
    if (ocol || orow) {  // WRF order: y flux, x flux, open x terms, open y terms
      t = real(0);
      if (do_y && !orow) t = t - (m.msftx(i, j) * rdy) * (fy(i, j + 1, k) - fy(i, j, k));
      if (!ocol) t = t - (m.msftx(i, j) * rdx) * (fx(i + 1, j, k) - fx(i, j, k));
      if (ocol) t = t - open_x_term(i, j, k);
      if (orow) t = t - open_y_term(i, j, k);
    } else {
      t = -(m.msftx(i, j) * rdx) * (fx(i + 1, j, k) - fx(i, j, k));
      if (do_y) t -= (m.msftx(i, j) * rdy) * (fy(i, j + 1, k) - fy(i, j, k));
    }
    const real rmsft = real(1) / m.msfty(i, j);
    if (k < nz) {
      t -= c.rdn(k) * (fz(i, j, k) - fz(i, j, k - 1));
      // pg_buoy_w: cq1 = 1/(1+cqw), cq2 = cqw cq1 (moisture loading of the base state)
      const real cqw = mc.cqw(i, j, k), cq1 = real(1) / (real(1) + cqw), cq2 = cqw * cq1;
      t += rmsft * Gr * (cq1 * c.rdn(k) * (p(i, j, k) - p(i, j, k - 1)) - c.c1f(k) * mu(i, j) -
                         cq2 * (c.c1f(k) * mub(i, j) + c.c2f(k)));
      if (wd_dt != real(0)) {  // w_damp (w_beta = 1, w_alpha = 0.3): WRF uses rdnw of the layer above
        const real muf = c.c1f(k) * mut(i, j) + c.c2f(k);
        real cfl = ww(i, j, k) / muf * c.rdnw(k) * wd_dt;
        cfl = cfl < real(0) ? -cfl : cfl;
        if (cfl > real(1)) t = t - (w(i, j, k) < real(0) ? real(-1) : real(1)) * real(0.3) * (cfl - w_crit) * muf;
      }
      // coriolis, curvature (levels 2..kde-1 in WRF)
      const real ruw = H * (c.fnm(k) * (ru(i, j, k) + ru(i + 1, j, k)) + c.fnp(k) * (ru(i, j, k - 1) + ru(i + 1, j, k - 1)));
      const real rvw = H * (c.fnm(k) * (rv(i, j, k) + rv(i, j + 1, k)) + c.fnp(k) * (rv(i, j, k - 1) + rv(i, j + 1, k - 1)));
      const real rmt = m.msftx(i, j) / m.msfty(i, j);
      if (m.cor) t = t + m.e(i, j) * (m.cosa(i, j) * ruw - rmt * m.sina(i, j) * rvw);
      const real uw = H * (c.fnm(k) * (u(i, j, k) + u(i + 1, j, k)) + c.fnp(k) * (u(i, j, k - 1) + u(i + 1, j, k - 1)));
      const real vw = H * (c.fnm(k) * (v(i, j, k) + v(i, j + 1, k)) + c.fnp(k) * (v(i, j, k - 1) + v(i, j + 1, k - 1)));
      t = t + RERADIUS * (ruw * uw + rmt * rvw * vw);
    } else {
      t += real(2) * c.rdn(nz - 1) * fz(i, j, nz - 1);
      const real cqw = mc.cqw(i, j, nz - 1), cq1 = real(1) / (real(1) + cqw), cq2 = cqw * cq1;
      t += rmsft * Gr * (cq1 * real(2) * c.rdnw(nz - 1) * (-p(i, j, nz - 1)) - c.c1f(nz) * mu(i, j) -
                         cq2 * (c.c1f(nz) * mub(i, j) + c.c2f(nz)));
    }
    if (use_tendf) t += tendf(i, j, k) / m.msfty(i, j);  // rk_addtend_dry
    out(i, j, k) = t;
  }
  CPPWRF_FACES  // after the other members (aggregate initialisation)
};

// Theta: advect_scalar (+ t_tendf)
struct KTendT {
  C3 t, ru, rv, ww, tendf; VCoef c;
  V3 out; real rdx, rdy; int nz; bool do_y, use_tendf; real hup, vup;
  C3 hd; C2 mut; bool use_hd;  // rk_addtend_dry: + (c1h*mut + c2h) * h_diabatic
  B2 msftx, msfty; kern::Spec sp;
  V3 thf; bool want_thf;  // set_tend(RTHFTEN, t_tend, msfty): advection only; spec zone 0 (not advected)
  CPPWRF_HD real fx(int i, int j, int k) const {
    CPPWRF_FACE_STORED(fxs)
    real vel = ru(i, j, k);
    const int o = kern::ord_face(i, sp.nx, sp.x);
    if (o == 2) return H * vel * (t(i, j, k) + t(i - 1, j, k));
    if (o == 3) return vel * flux3(t(i - 2, j, k), t(i - 1, j, k), t(i, j, k), t(i + 1, j, k), vel, hup);
    return vel * flux5(t(i - 3, j, k), t(i - 2, j, k), t(i - 1, j, k), t(i, j, k), t(i + 1, j, k), t(i + 2, j, k), vel, hup);
  }
  CPPWRF_HD real fy(int i, int j, int k) const {
    CPPWRF_FACE_STORED(fys)
    real vel = rv(i, j, k);
    const int o = kern::ord_face(j, sp.ny, sp.y);
    if (o == 2) return H * vel * (t(i, j, k) + t(i, j - 1, k));
    if (o == 3) return vel * flux3(t(i, j - 2, k), t(i, j - 1, k), t(i, j, k), t(i, j + 1, k), vel, hup);
    return vel * flux5(t(i, j - 3, k), t(i, j - 2, k), t(i, j - 1, k), t(i, j, k), t(i, j + 1, k), t(i, j + 2, k), vel, hup);
  }
  CPPWRF_HD real fz(int i, int j, int k) const {
    CPPWRF_FACE_STORED(fzs)
    if (k == 0 || k == nz) return 0;
    real vel = ww(i, j, k);
    if (k == 1 || k == nz - 1) return vel * (c.fnm(k) * t(i, j, k) + c.fnp(k) * t(i, j, k - 1));
    return vel * flux3(t(i, j, k - 2), t(i, j, k - 1), t(i, j, k), t(i, j, k + 1), -vel, vup);
  }
  CPPWRF_HD void operator()(int i, int j, int k) const {
    // advect_scalar: horizontal terms times msftx (ADT eq. 48 / my)
    real r;
    const bool ocol = sp.ox && (i == 0 || i == sp.nx - 1), orow = sp.oy && (j == 0 || j == sp.ny - 1);
    if (ocol || orow) {  // open boundary: WRF order y flux, x flux, open x terms, open y terms, vertical
      r = real(0);
      if (do_y && !orow) r = r - (msftx(i, j) * rdy) * (fy(i, j + 1, k) - fy(i, j, k));
      if (!ocol) r = r - (msftx(i, j) * rdx) * (fx(i + 1, j, k) - fx(i, j, k));
      if (ocol) r = r - kern::open_x_scalar(t, t, ru, rdx, i, j, k, sp.nx);
      if (orow) r = r - kern::open_y_scalar(t, t, rv, rdy, i, j, k, sp.ny);
    } else {
      r = -(msftx(i, j) * rdx) * (fx(i + 1, j, k) - fx(i, j, k));
      if (do_y) r -= (msftx(i, j) * rdy) * (fy(i, j + 1, k) - fy(i, j, k));
    }
    r -= c.rdnw(k) * (fz(i, j, k + 1) - fz(i, j, k));
    if (want_thf) {
      // WRF advect_scalar on a specified boundary: the x flux divergence is skipped in the outer
      // columns, the y one in the outer rows (degrade_xs/xe, ys/ye); the vertical term is everywhere
      const bool scol = sp.sx() && (i == 0 || i == sp.nx - 1), srow = sp.sy() && (j == 0 || j == sp.ny - 1);
      if (!scol && !srow) {
        thf(i, j, k) = r * msfty(i, j);
      } else {
        real q = real(0);
        if (!scol) q = -(msftx(i, j) * rdx) * (fx(i + 1, j, k) - fx(i, j, k));
        if (do_y && !srow) q -= (msftx(i, j) * rdy) * (fy(i, j + 1, k) - fy(i, j, k));
        q -= c.rdnw(k) * (fz(i, j, k + 1) - fz(i, j, k));
        thf(i, j, k) = q * msfty(i, j);
      }
    }
    if (use_tendf) r += tendf(i, j, k) / msfty(i, j);  // rk_addtend_dry
    if (use_hd) r += (c.c1h(k) * mut(i, j) + c.c2h(k)) * hd(i, j, k) / msfty(i, j);  // "divide by my to couple heating"
    out(i, j, k) = r;
  }
  CPPWRF_FACES  // after the other members (aggregate initialisation)
};

// Geopotential (levels 1..nz): rhs_ph with phi_adv_z = 1 and the h_sca_adv_order 5/6 branch
// (6th-order centred horizontal gradient of ph and phb, separately, as WRF), plus g*w/msfty.
// Order of accumulation as WRF: vertical advection, g*w, y term, x term.
struct KTendPh {
  C3 u, v, w, ww, ph; C2 mut, muu, muv; B3 phb; VCoef c;
  V3 out; real rdx, rdy; int nz; bool do_y;
  B2 msfty, msfux, msfvy; kern::Spec sp; C3 tendf; bool use_tendf;
  B2 msftx;
  CPPWRF_HD real wdwn(int i, int j, int m) const {
    return H * (ww(i, j, m + 1) + ww(i, j, m)) * c.rdnw(m) *
           (ph(i, j, m + 1) - ph(i, j, m) + phb(i, j, m + 1) - phb(i, j, m));
  }
  template <int DI, int DJ> CPPWRF_HD real grad6(int i, int j, int k) const {
    return real(45) * (ph(i + DI, j + DJ, k) - ph(i - DI, j - DJ, k)) -
           real(9) * (ph(i + 2 * DI, j + 2 * DJ, k) - ph(i - 2 * DI, j - 2 * DJ, k)) +
           (ph(i + 3 * DI, j + 3 * DJ, k) - ph(i - 3 * DI, j - 3 * DJ, k)) +
           real(45) * (phb(i + DI, j + DJ, k) - phb(i - DI, j - DJ, k)) -
           real(9) * (phb(i + 2 * DI, j + 2 * DJ, k) - phb(i - 2 * DI, j - 2 * DJ, k)) +
           (phb(i + 3 * DI, j + 3 * DJ, k) - phb(i - 3 * DI, j - 3 * DJ, k));
  }
  template <int DI, int DJ> CPPWRF_HD real grad4(int i, int j, int k) const {
    return real(8) * (ph(i + DI, j + DJ, k) - ph(i - DI, j - DJ, k)) -
           (ph(i + 2 * DI, j + 2 * DJ, k) - ph(i - 2 * DI, j - 2 * DJ, k)) +
           real(8) * (phb(i + DI, j + DJ, k) - phb(i - DI, j - DJ, k)) -
           (phb(i + 2 * DI, j + 2 * DJ, k) - phb(i - 2 * DI, j - 2 * DJ, k));
  }
  template <int DI, int DJ> CPPWRF_HD real dfwd(int i, int j, int k) const {  // one-sided, 2nd order form
    return phb(i + DI, j + DJ, k) - phb(i, j, k) + ph(i + DI, j + DJ, k) - ph(i, j, k);
  }
  // WRF rhs_ph near specified boundaries: row 1 2nd order, row 2 4th order (y only: the x 4th-order
  // column is applied for open_xs, not for specified, so with specified x it gets no x term), 6th
  // from row 3; rows 0 and n-1 get no horizontal term (spec_bdy sets their tendency).
  CPPWRF_HD int horder(int i, int n, bool on, bool is_x) const {
    if (!on) return 6;
    if (i <= 0 || i >= n - 1) return 0;
    if (i == 1 || i == n - 2) return 2;
    if (i == 2 || i == n - 3) return (is_x && !sp.ox) ? 0 : 4;  // open x: 4th order (open_xs/xe only)
    return 6;
  }
  CPPWRF_HD void operator()(int i, int j, int k) const {
    real t = 0;
    if (k < nz) t = t - (c.fnm(k) * wdwn(i, j, k) + c.fnp(k) * wdwn(i, j, k - 1));
    t = t + (c.c1f(k) * mut(i, j) + c.c2f(k)) * Gr * w(i, j, k) / msfty(i, j);
    const real r60 = real(1) / real(60), r12 = real(1) / real(12);
    if (do_y) {
      const real mvp = c.c1f(k) * muv(i, j + 1) + c.c2f(k), mvm = c.c1f(k) * muv(i, j) + c.c2f(k);
      // v at the w level (interior: sum of the two adjacent levels; top: extrapolated, factor 2)
      const real vp = k < nz ? v(i, j + 1, k) + v(i, j + 1, k - 1) : c.cfn * v(i, j + 1, nz - 1) + c.cfn1 * v(i, j + 1, nz - 2);
      const real vm = k < nz ? v(i, j, k) + v(i, j, k - 1) : c.cfn * v(i, j, nz - 1) + c.cfn1 * v(i, j, nz - 2);
      const real cy = (k < nz ? real(0.25) : H) * rdy / msfty(i, j);
      const int o = horder(j, sp.ny, sp.y, false);
      if (o == 6)
        t = t - cy * ((mvp * vp * msfvy(i, j + 1) + mvm * vm * msfvy(i, j)) * r60 * grad6<0, 1>(i, j, k));
      else if (o == 4)
        t = t - cy * ((mvp * vp * msfvy(i, j + 1) + mvm * vm * msfvy(i, j)) * r12 * grad4<0, 1>(i, j, k));
      else if (o == 2)
        t = t - cy * (mvp * vp * msfvy(i, j + 1) * dfwd<0, 1>(i, j, k) + mvm * vm * msfvy(i, j) * dfwd<0, 1>(i, j - 1, k));
    }
    const real mup = c.c1f(k) * muu(i + 1, j) + c.c2f(k), mum = c.c1f(k) * muu(i, j) + c.c2f(k);
    const real up = k < nz ? u(i + 1, j, k) + u(i + 1, j, k - 1) : c.cfn * u(i + 1, j, nz - 1) + c.cfn1 * u(i + 1, j, nz - 2);
    const real um = k < nz ? u(i, j, k) + u(i, j, k - 1) : c.cfn * u(i, j, nz - 1) + c.cfn1 * u(i, j, nz - 2);
    const real cx = (k < nz ? real(0.25) : H) * rdx / msfty(i, j);
    const int o = horder(i, sp.nx, sp.x, true);
    if (o == 6)
      t = t - cx * ((mup * up * msfux(i + 1, j) + mum * um * msfux(i, j)) * r60 * grad6<1, 0>(i, j, k));
    else if (o == 2)
      t = t - cx * (mup * up * msfux(i + 1, j) * dfwd<1, 0>(i, j, k) + mum * um * msfux(i, j) * dfwd<1, 0>(i - 1, j, k));
    else if (o == 4)
      t = t - cx * ((mup * up * msfux(i + 1, j) + mum * um * msfux(i, j)) * r12 * grad4<1, 0>(i, j, k));
    // open boundaries (after the advection, south/north then west/east): inflow advection of ph by
    // the normal wind interpolated to the w level (top: kz = kde-1, except WRF's west lid level,
    // whose kz = kde reads fnm/fnp(kde) = 0 and adds nothing)
    if (sp.oy && (j == 0 || j == sp.ny - 1)) {
      const int kz = k < nz - 1 ? k : nz - 1;
      const int a = j == 0 ? 0 : sp.ny - 1, b = j == 0 ? 1 : sp.ny;  // v faces: outer side a, inner b
      const real vb = H * (c.fnm(kz) * (v(i, b, kz) + v(i, a, kz)) + c.fnp(kz) * (v(i, b, kz - 1) + v(i, a, kz - 1)));
      const real muf = c.c1f(k) * mut(i, j) + c.c2f(k);
      if (j == 0) {
        const real vl = vb < real(0) ? vb : real(0);
        t = t - rdy * muf * (vl * (ph(i, 1, k) - ph(i, 0, k)));
      } else {
        const real vr = vb > real(0) ? vb : real(0);
        t = t - rdy * muf * (vr * (ph(i, j, k) - ph(i, j - 1, k)));
      }
    }
    if (sp.ox && (i == 0 || i == sp.nx - 1) && !(i == 0 && k == nz)) {
      const int kz = k < nz ? k : nz - 1;
      const int a = i == 0 ? 0 : sp.nx - 1, b = i == 0 ? 1 : sp.nx;  // u faces
      const real ub = H * (c.fnm(kz) * (u(b, j, kz) + u(a, j, kz)) + c.fnp(kz) * (u(b, j, kz - 1) + u(a, j, kz - 1)));
      const real muf = c.c1f(k) * mut(i, j) + c.c2f(k);
      if (i == 0) {
        const real ul = ub < real(0) ? ub : real(0);
        t = t - (msftx(i, j) / msfty(i, j)) * rdx * muf * (ul * (ph(1, j, k) - ph(0, j, k)));
      } else {
        const real ur = ub > real(0) ? ub : real(0);
        t = t - (msftx(i, j) / msfty(i, j)) * rdx * muf * (ur * (ph(i, j, k) - ph(i - 1, j, k)));
      }
    }
    if (use_tendf) t = t + tendf(i, j, k) / msfty(i, j);  // rk_addtend_dry: ph_tend += ph_tendf/msfty
    out(i, j, k) = t;
  }
};

// w_damp's Courant numbers (module_big_step_utilities_em.F:2621-2668), w levels 2..kde-1 of the mass columns:
// vert_cfl = abs(ww/(c1f*mut+c2f)*rdnw*dt), horiz_cfl = max(abs(u*rdx*msfux*dt), abs(v*rdy*msfvy*dt))
struct FVertCfl {
  C3 ww; C2 mut; VCoef c; real dt;
  CPPWRF_HD double operator()(int i, int j, int k) const {
    const real x = ww(i, j, k) / (c.c1f(k) * mut(i, j) + c.c2f(k)) * c.rdnw(k) * dt;
    return double(x < real(0) ? -x : x);
  }
};
struct FHorizCfl {
  C3 u, v; B2 msfux, msfvy; real rdx, rdy, dt;
  CPPWRF_HD double operator()(int i, int j, int k) const {
    real a = u(i, j, k) * rdx * msfux(i, j) * dt, b = v(i, j, k) * rdy * msfvy(i, j) * dt;
    a = a < real(0) ? -a : a;
    b = b < real(0) ? -b : b;
    return double(b > a ? b : a);
  }
};

}  // namespace

VCoef VCoef::from(const BaseState& b) {
  return VCoef{b.dnw.view(), b.rdnw.view(), b.dn.view(), b.rdn.view(), b.fnm.view(), b.fnp.view(),
               b.c1h.view(), b.c2h.view(), b.c1f.view(), b.c2f.view(),
               real(b.cf1), real(b.cf2), real(b.cf3), real(b.cfn), real(b.cfn1)};
}

void LargeStep::prep(State& s, const BaseState& b) const {
  const Grid& g = g_;
  const int nyv = g.nys(Stagger::V);
  // mu_2: WRF does not refresh its halo before rk_step_prep (calc_ww_cp reads it); the halo column
  // follows small_step_finish there, and the boundary copy only after small_step_prep
  if (!g.specified()) fill_halos({s.u_2, s.v_2, s.w_2, s.t_2, s.ph_2, s.p, s.al, s.mu_2}, g);
  else {
    fill_halos({&s.u_2, &s.v_2, &s.w_2, &s.t_2, &s.ph_2, &s.p, &s.al}, g);
    tile::exchange(s.mu_2);  // tiles: the neighbours' points (a run without tiles reads them as they are)
  }
  VCoef c = VCoef::from(b);
  parallel_for(Range3D{0, g.nx + 1, 0, nyv, 0, 1},
               KMu{s.mu_2.cview(), b.mub.view(), s.mut.view(), s.muu.view(), s.muv.view(), g.nx, g.ny, nyv,
                   g.flat_x(), g.flat_y() && !g.two_d()});
  fill_halo(s.mut, g);
  parallel_for(Range3D{0, g.nx + 1, 0, nyv, 0, g.nz + 1},
               KPrep3{s.u_2.cview(), s.v_2.cview(), s.w_2.cview(), s.al.cview(), s.ph_2.cview(), s.muu.cview(),
                      s.muv.cview(), s.mut.cview(), b.alb.view(), b.phb.view(), b.msfuy.view(), b.msfvx_inv.view(),
                      b.msfty.view(), c, s.ru.view(), s.rv.view(),
                      s.rw.view(), s.alt.view(), s.php.view(), g.nx, g.ny, nyv, g.nz});
  // rk_phys_bc_dry_1 after ru / rv: set_physical_bc2d(muu, 'u') / (muv, 'v') are odd in their staggered
  // direction on symmetric sides, and the 'u' loop also flips the sign of muu on the walls
  fill_halos({s.ru, s.rv, s.rw, s.alt, s.php, HaloField(s.muu, Parity::OddFace, Parity::Even),
              HaloField(s.muv, Parity::Even, Parity::Odd)}, g);
  column_for(g.columns(), KWW{s.u_2.cview(), s.v_2.cview(), s.mu_2.cview(), b.mub.view(), s.ww.view(), b.msftx.view(),
                              b.msfuy.view(), b.msfvx_inv.view(), c, real(b.rdx), real(b.rdy), g.nz});
  fill_halo(s.ww, g);
  if (s.n_moist > 0) {  // calc_cq: per species, sum of the two neighbours (WRF summation order)
    if (s.n_moist > KCq::kMax) throw std::runtime_error("calc_cq: too many moist species");
    KCq k{};
    k.n = s.n_moist;
    for (int q = 0; q < s.n_moist; ++q) k.q[q] = s.q_2[q].cview();
    k.cqu = s.cqu.view(); k.cqv = s.cqv.view(); k.cqw = s.cqw.view();
    k.nx = g.nx; k.ny = g.ny; k.nyv = nyv; k.nz = g.nz;
    parallel_for(Range3D{0, g.nx + 1, 0, nyv, 0, g.nz}, k);
  }
}

namespace {
#if defined(CPPWRF_DOUBLE)
// one face flux of a tendency kernel K (D = 0: fx, 1: fy, 2: fz) per point of r
template <class K, int D>
struct KFace {
  K t; V3 out;
  CPPWRF_HD void operator()(int i, int j, int k) const {
    if constexpr (D == 0) out(i, j, k) = t.fx(i, j, k);
    else if constexpr (D == 1) out(i, j, k) = t.fy(i, j, k);
    else out(i, j, k) = t.fz(i, j, k);
  }
};
#endif
}  // namespace

// three arrays over i in [-halo, nx + 1 + halo), j in [-halo, ny + 1 + halo) (of the worker's patch), k in
// [0, nz + 2): every face of every staggering the tendency kernels read
struct LargeStep::FaceScratch {
  Buffer b[3];
  View3<real> v[3];
  explicit FaceScratch(const Grid& g) {
    // a decomposed run: the worker's patch in place of the domain, under the domain's indices
    const tile::PatchBox ob = tile::own_box(g);
    const int h = Grid::halo, sj = (ob.i1 - ob.i0) + 1 + 2 * h, sk = sj * ((ob.j1 - ob.j0) + 1 + 2 * h);
    for (int a = 0; a < 3; ++a) {
      b[a] = Buffer(std::size_t(sk) * std::size_t(g.nz + 2));
      v[a] = View3<real>{b[a].get() + (h - ob.i0) + std::ptrdiff_t(h - ob.j0) * sj, sj, sk};
    }
  }
};

LargeStep::LargeStep(const Grid& g, const LargeStepParams& p) : g_(g), p_(p) {
#if defined(CPPWRF_DOUBLE)
  faces_ = std::make_shared<FaceScratch>(g);
#endif
}

namespace {
#if defined(CPPWRF_DOUBLE)
// rk_tendency kernel k over r with its face fluxes computed first: fx over the x faces of r's cells
// (i0 .. i1), fy over the y faces (j0 .. j1), fz over zr
template <class K>
void tend_with_faces(const LargeStep::FaceScratch& f, const Range3D& r, const Range3D& zr, bool do_y, K k) {
  {
    const Range3D xf = tile::faces_of(r, 0), yf = tile::faces_of(r, 1);
    const tile::Whole faces;  // a tile: the faces of its cells
    parallel_for(xf, KFace<K, 0>{k, f.v[0]});
    if (do_y) parallel_for(yf, KFace<K, 1>{k, f.v[1]});
  }
  parallel_for(zr, KFace<K, 2>{k, f.v[2]});
  k.fxs = C3{f.v[0].p, f.v[0].sj, f.v[0].sk};
  k.fys = C3{f.v[1].p, f.v[1].sj, f.v[1].sk};
  k.fzs = C3{f.v[2].p, f.v[2].sj, f.v[2].sk};
  k.stored = true;
  parallel_for(r, k);
}
#endif
}  // namespace

kern::MoistCoef moist_coef(const State& s) {
  return s.n_moist > 0 ? kern::MoistCoef{s.cqu.cview(), s.cqv.cview(), s.cqw.cview(), true} : kern::MoistCoef{};
}

void LargeStep::tendencies(const State& s, Tendencies& t, const BaseState& b, int rk_step) const {
  const Grid& g = g_;
  const VCoef c = VCoef::from(b);
  const real rdx = real(b.rdx), rdy = real(b.rdy);
  const bool do_y = !g.two_d();
  const int nz = g.nz;
  // open boundaries: the boundary faces are advanced too (radiation condition)
  const Range3D ur{g.open_x() ? 0 : g.u_i0(), g.open_x() ? g.nx + 1 : g.u_i1(), 0, g.ny, 0, nz};
  const Range3D vr{0, g.nx, g.open_y() ? 0 : g.v_j0(), g.open_y() ? g.ny + 1 : g.v_j1(), 0, nz};
  const Range3D wr{0, g.nx, 0, g.ny, 1, nz + 1};
  const Range3D mr = g.mass_cells();
  // even orders (6 / 4) = the same fluxes without the upwind dissipation term (WRF flux6/flux4)
  const real hup = p_.h_adv_order == 5 ? real(1) : real(0), vup = p_.v_adv_order == 3 ? real(1) : real(0);
  const MapC m = MapC::from(b, b.mapped || b.coriolis);
  const kern::Spec sp = kern::Spec::of(g);
  // init_zero_tendency at stage 1 (with column physics the RK driver did it before part1)
  if (rk_step == 1 && !cp_) zero_tendf(t);
  if (bc_) {  // WRF zero_tend: mu_tend every stage
    V2 mt = t.mu_tend.view();
    parallel_for(Range3D{0, g.nx, 0, g.ny, 0, 1}, [=] CPPWRF_HD(int i, int j, int) { mt(i, j) = 0; });
  }

  // first_rk_step_part2: calculate_phy_tend + update_phy_ten; WRF adds the diffusion after it
  // (diff_opt = 1 in rk_tendency, diff_opt = 2 later in part2)
  if (cp_ && rk_step == 1) cp_->part2(s, b, t);
  if (dd_ && rk_step == 1) dd_->dynamics(s, b, t);  // diff_opt 1 / sixth order (rk_tendency, rk_step 1)
  if (rk_step == 1) vmdump::dump("vm_prerelax", 0, {&t.t_tendf});
  if (bc_ && rk_step == 1) bc_->relax_dry(s, t, b);  // relax_bdy_dry -> *_save -> *_tendf (rk_addtend_dry)
  if (rk_step == 1) vmdump::dump("vm_addtend_in", 0, {&t.t_tendf, &s.h_diabatic});
  const bool tendf = bc_ != nullptr || cp_ != nullptr || dd_ != nullptr;
  Field3* thf_field = cp_ ? cp_->th_forcing() : nullptr;
  const bool thf_on = thf_field != nullptr;
  const V3 thf = thf_on ? thf_field->view() : V3{};
  // the kernel over r; FP64 builds: its face fluxes first (x and y faces of r's cells, the vertical ones over zr)
  auto launch_tend = [&](const Range3D& r, [[maybe_unused]] const Range3D& zr, [[maybe_unused]] bool fy, auto k) {
#if defined(CPPWRF_DOUBLE)
    tend_with_faces(*faces_, r, zr, fy, k);
#else
    parallel_for(r, k);
#endif
  };
  launch_tend(ur, Range3D{ur.i0, ur.i1, ur.j0, ur.j1, ur.k0, ur.k1 + 1}, do_y, KTendU{s.u_2.cview(), s.ru.cview(), s.rv.cview(), s.ww.cview(), s.p.cview(), s.ph_2.cview(),
                          s.alt.cview(), s.al.cview(), s.php.cview(), t.ru_tendf.cview(), s.mu_2.cview(),
                          s.muu.cview(), b.pb.view(), c, moist_coef(s), t.ru_tend.view(), rdx, rdy, nz, do_y, p_.top_lid, tendf, hup, vup,
                          s.v_2.cview(), s.rw.cview(), m, sp, s.mut.cview()});
  if (do_y)
    launch_tend(vr, Range3D{vr.i0, vr.i1, vr.j0, vr.j1, vr.k0, vr.k1 + 1}, true, KTendV{s.v_2.cview(), s.ru.cview(), s.rv.cview(), s.ww.cview(), s.p.cview(), s.ph_2.cview(),
                            s.alt.cview(), s.al.cview(), s.php.cview(), t.rv_tendf.cview(), s.mu_2.cview(),
                            s.muv.cview(), b.pb.view(), c, moist_coef(s), t.rv_tend.view(), rdx, rdy, nz, p_.top_lid, tendf, hup, vup,
                            s.u_2.cview(), s.rw.cview(), m, sp, s.mut.cview()});
  launch_tend(wr, Range3D{wr.i0, wr.i1, wr.j0, wr.j1, wr.k0 - 1, wr.k1 - 1}, do_y, KTendW{s.w_2.cview(), s.ru.cview(), s.rv.cview(), s.ww.cview(), s.p.cview(), t.rw_tendf.cview(),
                          s.mu_2.cview(), b.mub.view(), c, moist_coef(s), t.rw_tend.view(), rdx, rdy, nz, do_y, tendf, hup, vup,
                          s.u_2.cview(), s.v_2.cview(), m, sp, s.mut.cview(),
                          p_.w_damping == 1 ? real(g_.dt) : real(0), p_.w_crit_cfl});
  launch_tend(mr, Range3D{mr.i0, mr.i1, mr.j0, mr.j1, mr.k0, mr.k1 + 1}, do_y, KTendT{s.t_2.cview(), s.ru.cview(), s.rv.cview(), s.ww.cview(), t.t_tendf.cview(), c,
                          t.t_tend.view(), rdx, rdy, nz, do_y, tendf, hup, vup, s.h_diabatic.cview(), s.mut.cview(),
                          s.n_moist > 0, b.msftx.view(), b.msfty.view(), sp, thf, thf_on});
  parallel_for(wr, KTendPh{s.u_2.cview(), s.v_2.cview(), s.w_2.cview(), s.ww.cview(), s.ph_2.cview(), s.mut.cview(),
                           s.muu.cview(), s.muv.cview(), b.phb.view(), c, t.ph_tend.view(), rdx, rdy, nz, do_y,
                           b.msfty.view(), b.msfux.view(), b.msfvy.view(), sp, t.ph_tendf.cview(), bc_ != nullptr,
                           b.msftx.view()});
  if (bc_) bc_->spec_dry(t);  // spec_bdy_dry: spec-zone tendencies from the boundary file
  // mu_tend stays 0 (dry, no physics); allocated zero.
}

// The domain maxima of w_damp's vertical and horizontal Courant numbers (WRF keeps them for the adaptive time
// step). The maximum does not depend on the order of the points: Reducer's per-level maxima, then the levels.
void LargeStep::cfl_max(const State& s, const BaseState& b, double dt, real& vert, real& horiz) const {
  const Grid& g = g_;
  if (g.nz < 2) { vert = horiz = 0; return; }
  if (!red_) red_ = std::make_unique<Reducer>(g.nz + 1);
  const Range3D r{0, g.nx, 0, g.ny, 1, g.nz};
  const real rdt = real(dt);
  // WRF's running maxima start at 0 and take a value when it is larger (a NaN never)
  const double v = red_->max(r, FVertCfl{s.ww.cview(), s.mut.cview(), VCoef::from(b), rdt});
  const double h = red_->max(r, FHorizCfl{s.u_2.cview(), s.v_2.cview(), b.msfux.view(), b.msfvy.view(), real(b.rdx),
                                          real(b.rdy), rdt});
  vert = v > 0.0 ? real(v) : real(0);
  horiz = h > 0.0 ? real(h) : real(0);
}

namespace {
struct KZero {
  static constexpr bool kNoMulAdd = true;
  V3 v;
  CPPWRF_HD void operator()(int i, int j, int k) const { v(i, j, k) = 0; }
};
}  // namespace

// WRF init_zero_tendency (first_rk_step_part1): the held stage-1 tendencies, scalars included (one launch).
void LargeStep::zero_tendf(Tendencies& t) const {
  LaunchBatch<KZero, 16> zero;
  for (Field3* f : {&t.ph_tendf, &t.ru_tendf, &t.rv_tendf, &t.rw_tendf, &t.t_tendf})
    zero.add(g_.cells(f->stagger()), KZero{f->view()});
  for (Field3& q : t.q_tendf) zero.add(g_.cells(q.stagger()), KZero{q.view()});
  zero.run();
}

}  // namespace cppwrf::dyn
