// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// WRF rrtmg_lw rtrnmc (McICA radiative transfer), split into independent pieces so that a GPU can
// run every band and every level of a column in parallel with the same arithmetic as WRF:
//   rrtmg_lw_secdiff        per column: diffusivity angles (16 bands) from pwvcm
//   rrtmg_lw_icldlyr        per layer : cloudy layer flag (any McICA subcolumn cloudy)
//   rrtmg_lw_band           per band  : rtrnmc's g-point loop of one band (sweeps, band sums per level)
//   rrtmg_lw_accum          per level : the band sums in band order
//   rrtmg_lw_heating        per column: heating rates from the net fluxes
// Composed in order for one column they reproduce rtrnmc bit for bit.
#include "core/backend.hpp"
#include "phys/ra_rrtmg_common/strided.hpp"
#include "phys/ra_rrtmg_lw/rrtmg_lw_tables.hpp"
#include <algorithm>
#include <cmath>

namespace cppwrf::phys {

constexpr int RRTMG_LW_SWEEP_MAX = 128;  // layers of one column (stack arrays of rrtmg_lw_sweep)

CPPWRF_HD inline void rrtmg_lw_secdiff(double pwvcm, SD secdiff) {
  const double a0[16] = {1.66, 1.55, 1.58, 1.66, 1.54, 1.454, 1.89, 1.33,
                         1.668, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66, 1.66};
  const double a1[16] = {0.00, 0.25, 0.22, 0.00, 0.13, 0.446, -0.10, 0.40,
                         -0.006, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00};
  const double a2[16] = {0.00, -12.0, -11.7, 0.00, -0.72, -0.243, 0.19, -0.062,
                         0.414, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00};
  for (int ibnd = 0; ibnd < 16; ++ibnd) {
    if (ibnd == 0 || ibnd == 3 || ibnd >= 9) {
      secdiff[ibnd] = 1.66;
    } else {
      double s = a0[ibnd] + a1[ibnd] * libm::exp(a2[ibnd] * pwvcm);
      if (s > 1.80) s = 1.80;
      if (s < 1.50) s = 1.50;
      secdiff[ibnd] = s;
    }
  }
}

// icldlyr for layers [lay0, lay1)
CPPWRF_FORCEINLINE void rrtmg_lw_icldlyr(CSD2 cldfmc, SI icldlyr, int lay0, int lay1) {
  for (int lay = lay0; lay < lay1; ++lay) {
    int c = 0;
    for (int ig = 0; ig < 140; ++ig)
      if (cldfmc[ig][lay] == 1.0) c = 1;
    icldlyr[lay] = c;
  }
}

// One g-point igc (of band iband) of rtrnmc: its down and up sweeps. The radiances the sweeps add to the band sums
// go to `out` per level, in the order of the sweeps:
//   out.down(l, radld, radclrd, iclddn)  the bottom of layer l (rtrnmc's lev - 1), iclddn after layer l
//   out.up(lev, radlu, radclru, iclddn)  level lev = 0..nlayers, iclddn at the end of the down sweep
// CLEAR_COL: a column without cloudy layers (rtrnmc's iclddn stays 0; radclrd = radld, radclru = radlu).
// A2 (CSD2 or SD2): the g-point's arrays; each element of fracs, taut is read once, at its layer of the down sweep,
// cldfmc's at its layer of each sweep, so `out` may overwrite them after (the GPU batch's in-place store).
template <int MAX_LAY, bool CLEAR_COL, class A2, class Out>
CPPWRF_FORCEINLINE void rrtmg_lw_gpoint(int nlayers, int iband, int igc, CSD secdiff, double reflect, double pbnd,
                                        A2 cldfmc, A2 taucmc, CSD2 planklay, CSD2 planklev, A2 fracs, A2 taut,
                                        CSI icldlyr, const RrtmgLwTables& CPPWRF_RESTRICT tables, Out& out) {
  constexpr double rec_6 = 0.166667;
  constexpr double bpade = 1.0 / 0.278;
  constexpr double tblint = 10000.0;
  const double sd = secdiff[iband];

  if constexpr (CLEAR_COL) {
    double atrans[MAX_LAY], bbugas[MAX_LAY];
    {
      double radld = 0.0;
      double plfrac0 = 0.0;
      for (int lev = nlayers; lev >= 1; --lev) {
        int lay = lev - 1;
        double plfrac = fracs[lay][igc];
        double blay = planklay[lay][iband];
        double dplankup = planklev[lev][iband] - blay;
        double dplankdn = planklev[lev - 1][iband] - blay;
        double odepth = sd * taut[lay][igc];
        if (odepth < 0.0) odepth = 0.0;
        double bbd = 0.0;
        if (odepth <= 0.06) {
          atrans[lay] = odepth - 0.5 * odepth * odepth;
          double odepth_rec = rec_6 * odepth;
          bbd = plfrac * (blay + dplankdn * odepth_rec);
          bbugas[lay] = plfrac * (blay + dplankup * odepth_rec);
        } else {
          double tblind = odepth / (bpade + odepth);
          int itr = static_cast<int>(tblint * tblind + 0.5);
          double transc = tables.exp_tbl[itr];
          atrans[lay] = 1.0 - transc;
          double tausfac = tables.tfn_tbl[itr];
          bbd = plfrac * (blay + tausfac * dplankdn);
          bbugas[lay] = plfrac * (blay + tausfac * dplankup);
        }
        radld = radld + (bbd - radld) * atrans[lay];
        if (lay == 0) plfrac0 = plfrac;
        out.down(lev - 1, radld, radld, 0);
      }

      double rad0 = plfrac0 * pbnd;  // fracs[0][igc] * pbnd
      double radlu = rad0 + reflect * radld;
      out.up(0, radlu, radlu, 0);

      for (int lev = 1; lev <= nlayers; ++lev) {
        int lay = lev - 1;
        radlu = radlu + (bbugas[lay] - radlu) * atrans[lay];
        out.up(lev, radlu, radlu, 0);
      }
    }
  } else {
    double atrans[MAX_LAY], bbugas[MAX_LAY], bbutot_atot[MAX_LAY], efcl[MAX_LAY];
    {
      double radld = 0.0;
      double radclrd = 0.0;
      double plfrac0 = 0.0;
      int iclddn = 0;

      for (int lev = nlayers; lev >= 1; --lev) {
        int lay = lev - 1;
        double plfrac = fracs[lay][igc];
        double blay = planklay[lay][iband];
        double dplankup = planklev[lev][iband] - blay;
        double dplankdn = planklev[lev - 1][iband] - blay;
        double odepth = sd * taut[lay][igc];
        if (odepth < 0.0) odepth = 0.0;

        double bbd = 0.0;

        if (icldlyr[lay] == 1) {
          iclddn = 1;
          double odcld = 0.0;
          double efcl_lay = 0.0;
          const double cf = cldfmc[igc][lay];
          if (cf == 1.0) {
            odcld = secdiff[tables.ngb[igc] - 1] * taucmc[igc][lay];
            double transcld = libm::exp(-odcld);
            double abscld = 1.0 - transcld;
            efcl_lay = abscld * cf;
          }
          efcl[lay] = efcl_lay;
          double odtot = odepth + odcld;
          double atot_lay, bbutot_lay;
          if (odtot < 0.06) {
            atrans[lay] = odepth - 0.5 * odepth * odepth;
            double odepth_rec = rec_6 * odepth;
            double gassrc = plfrac * (blay + dplankdn * odepth_rec) * atrans[lay];

            atot_lay = odtot - 0.5 * odtot * odtot;
            double odtot_rec = rec_6 * odtot;
            double bbdtot = plfrac * (blay + dplankdn * odtot_rec);
            bbd = plfrac * (blay + dplankdn * odepth_rec);

            radld = radld - radld * (atrans[lay] + efcl_lay * (1.0 - atrans[lay])) +
                    gassrc + cf * (bbdtot * atot_lay - gassrc);

            bbugas[lay] = plfrac * (blay + dplankup * odepth_rec);
            bbutot_lay = plfrac * (blay + dplankup * odtot_rec);
          } else if (odepth <= 0.06) {
            atrans[lay] = odepth - 0.5 * odepth * odepth;
            double odepth_rec = rec_6 * odepth;
            double gassrc = plfrac * (blay + dplankdn * odepth_rec) * atrans[lay];

            double tblind = odtot / (bpade + odtot);
            int ittot = static_cast<int>(tblint * tblind + 0.5);
            double tfactot = tables.tfn_tbl[ittot];
            double bbdtot = plfrac * (blay + tfactot * dplankdn);
            bbd = plfrac * (blay + dplankdn * odepth_rec);
            atot_lay = 1.0 - tables.exp_tbl[ittot];

            radld = radld - radld * (atrans[lay] + efcl_lay * (1.0 - atrans[lay])) +
                    gassrc + cf * (bbdtot * atot_lay - gassrc);

            bbugas[lay] = plfrac * (blay + dplankup * odepth_rec);
            bbutot_lay = plfrac * (blay + tfactot * dplankup);
          } else {
            double tblind = odepth / (bpade + odepth);
            int itgas = static_cast<int>(tblint * tblind + 0.5);
            odepth = tables.tau_tbl[itgas];
            atrans[lay] = 1.0 - tables.exp_tbl[itgas];
            double tfacgas = tables.tfn_tbl[itgas];
            double gassrc = atrans[lay] * plfrac * (blay + tfacgas * dplankdn);

            odtot = odepth + odcld;
            tblind = odtot / (bpade + odtot);
            int ittot = static_cast<int>(tblint * tblind + 0.5);
            double tfactot = tables.tfn_tbl[ittot];
            double bbdtot = plfrac * (blay + tfactot * dplankdn);
            bbd = plfrac * (blay + tfacgas * dplankdn);
            atot_lay = 1.0 - tables.exp_tbl[ittot];

            radld = radld - radld * (atrans[lay] + efcl_lay * (1.0 - atrans[lay])) +
                    gassrc + cf * (bbdtot * atot_lay - gassrc);

            bbugas[lay] = plfrac * (blay + tfacgas * dplankup);
            bbutot_lay = plfrac * (blay + tfactot * dplankup);
          }
          bbutot_atot[lay] = bbutot_lay * atot_lay;
        } else {
          if (odepth <= 0.06) {
            atrans[lay] = odepth - 0.5 * odepth * odepth;
            double odepth_rec = rec_6 * odepth;
            bbd = plfrac * (blay + dplankdn * odepth_rec);
            bbugas[lay] = plfrac * (blay + dplankup * odepth_rec);
          } else {
            double tblind = odepth / (bpade + odepth);
            int itr = static_cast<int>(tblint * tblind + 0.5);
            double transc = tables.exp_tbl[itr];
            atrans[lay] = 1.0 - transc;
            double tausfac = tables.tfn_tbl[itr];
            bbd = plfrac * (blay + tausfac * dplankdn);
            bbugas[lay] = plfrac * (blay + tausfac * dplankup);
          }
          radld = radld + (bbd - radld) * atrans[lay];
        }

        if (iclddn == 1) radclrd = radclrd + (bbd - radclrd) * atrans[lay];
        else radclrd = radld;
        if (lay == 0) plfrac0 = plfrac;
        out.down(lev - 1, radld, radclrd, iclddn);
      }

      double rad0 = plfrac0 * pbnd;  // fracs[0][igc] * pbnd
      double radlu = rad0 + reflect * radld;
      double radclru = rad0 + reflect * radclrd;
      out.up(0, radlu, radclru, iclddn);

      for (int lev = 1; lev <= nlayers; ++lev) {
        int lay = lev - 1;
        if (icldlyr[lay] == 1) {
          double gassrc = bbugas[lay] * atrans[lay];
          radlu = radlu - radlu * (atrans[lay] + efcl[lay] * (1.0 - atrans[lay])) +
                  gassrc + cldfmc[igc][lay] * (bbutot_atot[lay] - gassrc);
        } else {
          radlu = radlu + (bbugas[lay] - radlu) * atrans[lay];
        }

        if (iclddn == 1) radclru = radclru + (bbugas[lay] - radclru) * atrans[lay];
        else radclru = radlu;
        out.up(lev, radlu, radclru, iclddn);
      }
    }
  }
}

// rtrnmc's band sums of one column (urad, drad, clrurad, clrdrad of one band): what each g-point's sweeps add,
// and below the first cloud (iclddn = 0) clrdrad = drad, clrurad = urad (level 0: clrurad adds radclru)
struct LwBandAcc {
  SD urad, drad, clrurad, clrdrad;
  CPPWRF_FORCEINLINE void down(int l, double radld, double radclrd, int iclddn) const {
    drad[l] += radld;
    if (iclddn == 1) clrdrad[l] += radclrd;
    else clrdrad[l] = drad[l];
  }
  CPPWRF_FORCEINLINE void up(int lev, double radlu, double radclru, int iclddn) const {
    urad[lev] += radlu;
    if (lev == 0 || iclddn == 1) clrurad[lev] += radclru;
    else clrurad[lev] = urad[lev];
  }
};
// the clear column's sums: the clear-sky sums are copied at the end (rtrnmc's clrdrad = drad, clrurad = urad)
struct LwBandAccClear {
  SD urad, drad;
  CPPWRF_FORCEINLINE void down(int l, double radld, double, int) const { drad[l] += radld; }
  CPPWRF_FORCEINLINE void up(int lev, double radlu, double, int) const { urad[lev] += radlu; }
};

template <int MAX_LAY, bool CLEAR_COL>
CPPWRF_FORCEINLINE void rrtmg_lw_band_impl(int nlayers, int iband, CSD secdiff, CSD semiss, CSD2 cldfmc, CSD2 taucmc,
                                           CSD2 planklay, CSD2 planklev, CSD plankbnd, CSD2 fracs, CSD2 taut,
                                           CSI icldlyr, SD2 bu, SD2 bd, SD2 bcu, SD2 bcd,
                                           const RrtmgLwTables& CPPWRF_RESTRICT tables) {
  const SD urad = bu[iband], drad = bd[iband], clrurad = bcu[iband], clrdrad = bcd[iband];
  for (int lev = 0; lev <= nlayers; ++lev) {
    urad[lev] = 0.0; drad[lev] = 0.0;
    if constexpr (!CLEAR_COL) {
      clrurad[lev] = 0.0; clrdrad[lev] = 0.0;
    }
  }
  const double reflect = 1.0 - semiss[iband];
  const double pbnd = plankbnd[iband];
  const int igc0 = iband == 0 ? 0 : tables.ngs[iband - 1];
  const int igc1 = tables.ngs[iband];

  if constexpr (CLEAR_COL) {
    LwBandAccClear acc{urad, drad};
    for (int igc = igc0; igc < igc1; ++igc)
      rrtmg_lw_gpoint<MAX_LAY, true, CSD2>(nlayers, iband, igc, secdiff, reflect, pbnd, cldfmc, taucmc, planklay, planklev,
                                     fracs, taut, icldlyr, tables, acc);
    for (int lev = 0; lev <= nlayers; ++lev) {
      clrdrad[lev] = drad[lev];
      clrurad[lev] = urad[lev];
    }
  } else {
    LwBandAcc acc{urad, drad, clrurad, clrdrad};
    for (int igc = igc0; igc < igc1; ++igc)
      rrtmg_lw_gpoint<MAX_LAY, false, CSD2>(nlayers, iband, igc, secdiff, reflect, pbnd, cldfmc, taucmc, planklay,
                                      planklev, fracs, taut, icldlyr, tables, acc);
  }
}

// One band of rtrnmc's band loop (iband 0..15): its g-points in order, down and up sweeps, the
// band sums urad/drad/clrurad/clrdrad of every level (bu/bd/bcu/bcd [16][nlayers + 1]) with WRF's
// clear-sky assignments (clrdrad = drad, clrurad = urad below the first cloud).
template <int MAX_LAY = RRTMG_LW_SWEEP_MAX>
CPPWRF_FORCEINLINE void rrtmg_lw_band(int nlayers, int iband, CSD secdiff, CSD semiss, CSD2 cldfmc, CSD2 taucmc,
                                      CSD2 planklay, CSD2 planklev, CSD plankbnd, CSD2 fracs, CSD2 taut, CSI icldlyr,
                                      SD2 bu, SD2 bd, SD2 bcu, SD2 bcd, const RrtmgLwTables& CPPWRF_RESTRICT tables,
                                      bool clear_col = false) {
#if defined(__CUDA_ARCH__)
  const bool fast_clear = __all_sync(__activemask(), clear_col);
#else
  const bool fast_clear = clear_col;
#endif
  if (fast_clear)
    rrtmg_lw_band_impl<MAX_LAY, true>(nlayers, iband, secdiff, semiss, cldfmc, taucmc, planklay, planklev, plankbnd,
                                      fracs, taut, icldlyr, bu, bd, bcu, bcd, tables);
  else
    rrtmg_lw_band_impl<MAX_LAY, false>(nlayers, iband, secdiff, semiss, cldfmc, taucmc, planklay, planklev, plankbnd,
                                       fracs, taut, icldlyr, bu, bd, bcu, bcd, tables);
}

// Level lev (0..nlayers): rtrnmc's band sums in band order, scaled by fluxfac; fnet / fnetc.
CPPWRF_FORCEINLINE void rrtmg_lw_accum(int lev, CSD2 bu, CSD2 bd, CSD2 bcu, CSD2 bcd,
                                       const RrtmgLwTables& CPPWRF_RESTRICT tables, double& totuflux, double& totdflux,
                                       double& totuclfl, double& totdclfl, double& fnet, double& fnetc) {
  constexpr double pi = 3.14159265358979323846;
  constexpr double fluxfac = pi * 2.0e4;
  constexpr double wtdiff = 0.5;
  double tu = 0.0, td = 0.0, tuc = 0.0, tdc = 0.0;
  for (int iband = 0; iband < 16; ++iband) {
    const double dw = tables.delwave[iband];
    double uflux = bu[iband][lev] * wtdiff;
    double dflux = bd[iband][lev] * wtdiff;
    tu += uflux * dw;
    td += dflux * dw;
    double uclfl = bcu[iband][lev] * wtdiff;
    double dclfl = bcd[iband][lev] * wtdiff;
    tuc += uclfl * dw;
    tdc += dclfl * dw;
  }
  tu *= fluxfac;
  td *= fluxfac;
  fnet = tu - td;
  tuc *= fluxfac;
  tdc *= fluxfac;
  fnetc = tuc - tdc;
  totuflux = tu; totdflux = td; totuclfl = tuc; totdclfl = tdc;
}

CPPWRF_FORCEINLINE void rrtmg_lw_heating(int nlayers, CSD pz, CSD fnet, CSD fnetc, SD htr, SD htrc, double heatfac) {
  for (int lev = 1; lev <= nlayers; ++lev) {
    int l = lev - 1;
    htr[l] = heatfac * (fnet[l] - fnet[lev]) / (pz[l] - pz[lev]);
    htrc[l] = heatfac * (fnetc[l] - fnetc[lev]) / (pz[l] - pz[lev]);
  }
  htr[nlayers] = 0.0;
  htrc[nlayers] = 0.0;
}

}  // namespace cppwrf::phys
