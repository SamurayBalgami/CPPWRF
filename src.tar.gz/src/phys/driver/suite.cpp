// SPDX-License-Identifier: GPL-3.0-or-later
#include "phys/driver/suite.hpp"

#include "core/vm_dump.hpp"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <stdexcept>

#include "phys/bl_acm/acm.hpp"
#include "phys/bl_gwdo/gwdo.hpp"
#include "phys/bl_myj/myjpbl.hpp"
#include "phys/bl_mynn/mynnedmf.hpp"
#include "phys/bl_ysu/ysu.hpp"
#include "phys/cu_gfl/gfl.hpp"
#include "phys/cu_ntiedtke/ntiedtke.hpp"
#include "phys/cu_tiedtke/tiedtke.hpp"
#include "phys/driver/noah_ice.hpp"
#include "phys/driver/suite_internal.hpp"
#include "phys/driver/wrf_constants.hpp"
#include "phys/lsm_noah/noah.hpp"
#include "phys/lsm_slab/slab.hpp"

namespace cppwrf::phys::driver {

// ------------------------------------------------------------------ IntField2
IntField2::IntField2(const Grid& g, std::string name)
    : name_(std::move(name)), L_(Layout::make(g, Stagger::M, 2)),
      buf_(static_cast<int*>(dev_alloc(L_.total * sizeof(int)))) {
  if (tile::track) tile::track->add(buf_, L_, int(sizeof(int)), name_);
}
IntField2::~IntField2() {
  if (buf_ && tile::track) tile::track->remove(buf_);
  dev_free(buf_);
}
IntField2::IntField2(IntField2&& o) noexcept : name_(std::move(o.name_)), L_(o.L_), buf_(o.buf_) { o.buf_ = nullptr; }
IntField2& IntField2::operator=(IntField2&& o) noexcept {
  std::swap(name_, o.name_);
  std::swap(L_, o.L_);
  std::swap(buf_, o.buf_);
  return *this;
}
void IntField2::upload(const std::vector<int>& h) { copy_to_dev(buf_, h.data(), L_.total * sizeof(int)); }
void IntField2::download(std::vector<int>& h) const {
  h.resize(L_.total);
  copy_to_host(h.data(), buf_, L_.total * sizeof(int));
}

using namespace suite_detail;

namespace {

struct KAccum2 {  // ac = ac + x*dt
  V2 ac;
  C2 x;
  real dt;
  CPPWRF_HD void operator()(int i, int j) const { ac(i, j) = ac(i, j) + x(i, j) * dt; }
  CPPWRF_HD void operator()(int i, int j, int) const { (*this)(i, j); }  // as a batched 3-D launch (one level)
};

// phys/module_diag_misc.F diagnostic_output_calc: the buckets (lines 295-428) and the precipitation over
// prec_acc_dt (432-462); rainnc / rainncv / snowncv without p: no microphysics field (WRF: 0)
struct KDiagOutputCalc {
  V2 rainc, rainnc;
  I2 i_rainc, i_rainnc;
  V2 ac[16];
  I2 i_ac[16];
  C2 raincv, rainncv, snowncv, t2;
  V2 prec_acc_c, prec_acc_nc, snow_acc_nc;
  real bucket_mm, bucket_j;
  bool bucket, bucket_j_on, xtime0, prec_acc, prec_reset;
  CPPWRF_HD void operator()(int i, int j) const {
    if (bucket) {  // bucket_mm > 0 .AND. MOD(NINT(curr_secs2),3600) == 0
      if (xtime0) {
        i_rainnc(i, j) = 0;
        i_rainc(i, j) = 0;
      }
      if (rainnc.p && rainnc(i, j) > bucket_mm) {
        rainnc(i, j) = rainnc(i, j) - bucket_mm;
        i_rainnc(i, j) = i_rainnc(i, j) + 1;
      }
      if (rainc(i, j) > bucket_mm) {
        rainc(i, j) = rainc(i, j) - bucket_mm;
        i_rainc(i, j) = i_rainc(i, j) + 1;
      }
      if (bucket_j_on) {  // bucket_J > 0 (inside the bucket_mm IF)
        if (xtime0)
          for (int n = 0; n < 16; ++n) i_ac[n](i, j) = 0;
        for (int n = 0; n < 16; ++n)
          if (ac[n](i, j) > bucket_j) {
            ac[n](i, j) = ac[n](i, j) - bucket_j;
            i_ac[n](i, j) = i_ac[n](i, j) + 1;
          }
      }
    }
    if (prec_acc) {  // prec_acc_dt > 0
      if (prec_reset) {  // mod(curr_secs2, 60.*prec_acc_dt) == 0.
        prec_acc_c(i, j) = real(0.);
        prec_acc_nc(i, j) = real(0.);
        snow_acc_nc(i, j) = real(0.);
      }
      const real rncv = rainncv.p ? rainncv(i, j) : real(0.), sncv = snowncv.p ? snowncv(i, j) : real(0.);
      prec_acc_c(i, j) = prec_acc_c(i, j) + raincv(i, j);
      prec_acc_nc(i, j) = prec_acc_nc(i, j) + rncv;
      prec_acc_c(i, j) = c_max(prec_acc_c(i, j), real(0.0));
      prec_acc_nc(i, j) = c_max(prec_acc_nc(i, j), real(0.0));
      snow_acc_nc(i, j) = snow_acc_nc(i, j) + sncv;
      if (t2(i, j) < real(273.15)) {  // convective precipitation into the snow bucket
        snow_acc_nc(i, j) = snow_acc_nc(i, j) + raincv(i, j);
        snow_acc_nc(i, j) = c_max(snow_acc_nc(i, j), real(0.0));
      }
    }
  }
};

// phys/module_diag_cl.F clwrf_output_calc: reinit (the step starts an interval) sets the statistics from this step's
// values; otherwise varstatistics / varstatisticsWIND / varstatisticsMAX add them, and the step that ends the interval
// (finish) turns the sums into means and standard deviations. tt = xtime + dt/60. (the end of the step), nsteps =
// REAL(grid%nsteps) after its update; rainncv without p: no microphysics field (WRF: 0)
struct KClwrfOutputCalc {
  C2 t2, q2, u10, v10, skintemp, raincv, rainncv;
  V2 t2min, t2max, tt2min, tt2max, t2mean, t2std, q2min, q2max, tq2min, tq2max, q2mean, q2std, skintempmin,
      skintempmax, tskintempmin, tskintempmax, skintempmean, skintempstd, u10max, v10max, spduv10max, tspduv10max,
      u10mean, v10mean, spduv10mean, u10std, v10std, spduv10std, raincvmax, rainncvmax, traincvmax, trainncvmax,
      raincvmean, rainncvmean, raincvstd, rainncvstd;
  real dt, tt, nsteps;
  bool reinit, finish;
  // varstatistics: strict < / > for the extremes and their times, then mean = mean + var, std = std + var*var
  CPPWRF_HD static void stats(real var, real tt, real& vmin, real& vmax, real& tmin, real& tmax, real& mean,
                              real& std) {
    if (var < vmin) {
      vmin = var;
      tmin = tt;
    }
    if (var > vmax) {
      vmax = var;
      tmax = tt;
    }
    mean = mean + var;
    std = std + var * var;
  }
  CPPWRF_HD static void stats_max(real var, real tt, real& vmax, real& tmax, real& mean, real& std) {
    if (var > vmax) {
      vmax = var;
      tmax = tt;
    }
    mean = mean + var;
    std = std + var * var;
  }
  CPPWRF_HD void operator()(int i, int j) const {
    const real t273 = real(273.);
    const real rcv = raincv(i, j), rncv = rainncv.p ? rainncv(i, j) : real(0.);
    if (reinit) {  // MOD(NINT(curr_secs2/dt),NINT(clwrfH*60./dt)) == 0; U10MAX / V10MAX keep their values
      t2min(i, j) = t2(i, j) - t273;
      t2max(i, j) = t2(i, j) - t273;
      t2mean(i, j) = t2(i, j) - t273;
      t2std(i, j) = (t2(i, j) - t273) * (t2(i, j) - t273);
      q2min(i, j) = q2(i, j);
      q2max(i, j) = q2(i, j);
      q2mean(i, j) = q2(i, j);
      q2std(i, j) = q2(i, j) * q2(i, j);
      spduv10max(i, j) = std::sqrt(u10(i, j) * u10(i, j) + v10(i, j) * v10(i, j));
      u10mean(i, j) = u10(i, j);
      v10mean(i, j) = v10(i, j);
      spduv10mean(i, j) = std::sqrt(u10(i, j) * u10(i, j) + v10(i, j) * v10(i, j));
      u10std(i, j) = u10(i, j) * u10(i, j);
      v10std(i, j) = v10(i, j) * v10(i, j);
      spduv10std(i, j) = u10(i, j) * u10(i, j) + v10(i, j) * v10(i, j);
      raincvmax(i, j) = rcv / dt;
      rainncvmax(i, j) = rncv / dt;
      raincvmean(i, j) = rcv / dt;
      rainncvmean(i, j) = rncv / dt;
      raincvstd(i, j) = (rcv / dt) * (rcv / dt);
      rainncvstd(i, j) = (rncv / dt) * (rncv / dt);
      skintempmin(i, j) = skintemp(i, j) - t273;
      skintempmax(i, j) = skintemp(i, j) - t273;
      skintempmean(i, j) = skintemp(i, j) - t273;
      skintempstd(i, j) = (skintemp(i, j) - t273) * (skintemp(i, j) - t273);
      tt2min(i, j) = tt;
      tt2max(i, j) = tt;
      tq2min(i, j) = tt;
      tq2max(i, j) = tt;
      tspduv10max(i, j) = tt;
      traincvmax(i, j) = tt;
      trainncvmax(i, j) = tt;
      tskintempmin(i, j) = tt;
      tskintempmax(i, j) = tt;
      return;
    }
    stats(t2(i, j) - t273, tt, t2min(i, j), t2max(i, j), tt2min(i, j), tt2max(i, j), t2mean(i, j), t2std(i, j));
    stats(q2(i, j), tt, q2min(i, j), q2max(i, j), tq2min(i, j), tq2max(i, j), q2mean(i, j), q2std(i, j));
    {  // varstatisticsWIND
      const real varuv = std::sqrt(u10(i, j) * u10(i, j) + v10(i, j) * v10(i, j));
      if (varuv > spduv10max(i, j)) {
        u10max(i, j) = u10(i, j);
        v10max(i, j) = v10(i, j);
        spduv10max(i, j) = varuv;
        tspduv10max(i, j) = tt;
      }
      spduv10mean(i, j) = spduv10mean(i, j) + varuv;
      spduv10std(i, j) = spduv10std(i, j) + varuv * varuv;
      u10mean(i, j) = u10mean(i, j) + u10(i, j);
      v10mean(i, j) = v10mean(i, j) + v10(i, j);
      u10std(i, j) = u10std(i, j) + u10(i, j) * u10(i, j);
      v10std(i, j) = v10std(i, j) + v10(i, j) * v10(i, j);
    }
    stats_max(rcv / dt, tt, raincvmax(i, j), traincvmax(i, j), raincvmean(i, j), raincvstd(i, j));
    stats_max(rncv / dt, tt, rainncvmax(i, j), trainncvmax(i, j), rainncvmean(i, j), rainncvstd(i, j));
    stats(skintemp(i, j) - t273, tt, skintempmin(i, j), skintempmax(i, j), tskintempmin(i, j), tskintempmax(i, j),
          skintempmean(i, j), skintempstd(i, j));
    if (!finish) return;  // MOD(NINT((curr_secs2+dt)/dt),NINT(clwrfH*60./dt)) == 0; x**2. = x*x
    const real z = real(0.);
    t2mean(i, j) = t2mean(i, j) / nsteps;
    t2std(i, j) = std::sqrt(c_max(t2std(i, j) / nsteps - t2mean(i, j) * t2mean(i, j), z));
    t2mean(i, j) = t2mean(i, j) + t273;
    t2min(i, j) = t2min(i, j) + t273;
    t2max(i, j) = t2max(i, j) + t273;
    q2mean(i, j) = q2mean(i, j) / nsteps;
    q2std(i, j) = q2std(i, j) / nsteps - q2mean(i, j) * q2mean(i, j);
    q2std(i, j) = c_max(q2std(i, j), z);
    q2std(i, j) = std::sqrt(q2std(i, j));
    u10mean(i, j) = u10mean(i, j) / nsteps;
    v10mean(i, j) = v10mean(i, j) / nsteps;
    spduv10mean(i, j) = spduv10mean(i, j) / nsteps;
    u10std(i, j) = std::sqrt(c_max(u10std(i, j) / nsteps - u10mean(i, j) * u10mean(i, j), z));
    v10std(i, j) = std::sqrt(c_max(v10std(i, j) / nsteps - v10mean(i, j) * v10mean(i, j), z));
    spduv10std(i, j) = std::sqrt(c_max(spduv10std(i, j) / nsteps - spduv10mean(i, j) * spduv10mean(i, j), z));
    raincvmean(i, j) = raincvmean(i, j) / nsteps;
    rainncvmean(i, j) = rainncvmean(i, j) / nsteps;
    raincvstd(i, j) = std::sqrt(c_max(raincvstd(i, j) / nsteps - raincvmean(i, j) * raincvmean(i, j), z));
    rainncvstd(i, j) = std::sqrt(c_max(rainncvstd(i, j) / nsteps - rainncvmean(i, j) * rainncvmean(i, j), z));
    skintempmean(i, j) = skintempmean(i, j) / nsteps;
    skintempstd(i, j) = skintempstd(i, j) / nsteps - skintempmean(i, j) * skintempmean(i, j);
    skintempstd(i, j) = c_max(skintempstd(i, j), z);
    skintempstd(i, j) = std::sqrt(skintempstd(i, j));
    skintempmean(i, j) = skintempmean(i, j) + t273;
    skintempmin(i, j) = skintempmin(i, j) + t273;
    skintempmax(i, j) = skintempmax(i, j) + t273;
  }
};

}  // namespace

// ------------------------------------------------------------------ PhysicsSuite
PhysicsSuite::PhysicsSuite(const Grid& g, const SuiteOptions& o)
    : tsk(g, Stagger::M, "tsk"), xland(g, Stagger::M, "xland"), xice(g, Stagger::M, "xice"),
      lakemask(g, Stagger::M, "lakemask"), water_depth(g, Stagger::M, "water_depth"), mavail(g, Stagger::M, "mavail"),
      tmn(g, Stagger::M, "tmn"), vegfra(g, Stagger::M, "vegfra"), shdmin(g, Stagger::M, "shdmin"),
      shdmax(g, Stagger::M, "shdmax"), snoalb(g, Stagger::M, "snoalb"), albbck(g, Stagger::M, "albbck"),
      albedo(g, Stagger::M, "albedo"), emiss(g, Stagger::M, "emiss"), embck(g, Stagger::M, "embck"),
      znt(g, Stagger::M, "znt"), z0(g, Stagger::M, "z0"), ust(g, Stagger::M, "ust"), ustm(g, Stagger::M, "ustm"),
      mol(g, Stagger::M, "mol"), rmol(g, Stagger::M, "rmol"), pblh(g, Stagger::M, "pblh"), hfx(g, Stagger::M, "hfx"),
      qfx(g, Stagger::M, "qfx"), lh(g, Stagger::M, "lh"), grdflx(g, Stagger::M, "grdflx"), qsfc(g, Stagger::M, "qsfc"),
      flhc(g, Stagger::M, "flhc"), flqc(g, Stagger::M, "flqc"), wspd(g, Stagger::M, "wspd"), br(g, Stagger::M, "br"),
      fm(g, Stagger::M, "fm"), fh(g, Stagger::M, "fh"), zol(g, Stagger::M, "zol"), regime(g, Stagger::M, "regime"),
      u10(g, Stagger::M, "u10"), v10(g, Stagger::M, "v10"), t2(g, Stagger::M, "t2"), th2(g, Stagger::M, "th2"),
      q2(g, Stagger::M, "q2"), psfc(g, Stagger::M, "psfc"), ch(g, Stagger::M, "ch"), snow(g, Stagger::M, "snow"),
      snowh(g, Stagger::M, "snowh"), snowc(g, Stagger::M, "snowc"), canwat(g, Stagger::M, "canwat"),
      lai(g, Stagger::M, "lai"), snotime(g, Stagger::M, "snotime"), qz0(g, Stagger::M, "qz0"),
      rainbl(g, Stagger::M, "rainbl"), raincv(g, Stagger::M, "raincv"), raincv_a(g, Stagger::M, "raincv_a"),
      raincv_b(g, Stagger::M, "raincv_b"), rainncv(g, Stagger::M, "rainncv"),
      rainshv(g, Stagger::M, "rainshv"), rainc(g, Stagger::M, "rainc"), rainsh(g, Stagger::M, "rainsh"),
      pratec(g, Stagger::M, "pratec"), pratesh(g, Stagger::M, "pratesh"), nca(g, Stagger::M, "nca"),
      htop(g, Stagger::M, "htop"), hbot(g, Stagger::M, "hbot"), cutop(g, Stagger::M, "cutop"),
      cubot(g, Stagger::M, "cubot"), cuppt(g, Stagger::M, "cuppt"), sr(g, Stagger::M, "sr"), glw(g, Stagger::M, "glw"),
      swdown(g, Stagger::M, "swdown"), gsw(g, Stagger::M, "gsw"), smstav(g, Stagger::M, "smstav"),
      smstot(g, Stagger::M, "smstot"), sfcrunoff(g, Stagger::M, "sfcrunoff"), udrunoff(g, Stagger::M, "udrunoff"),
      acsnom(g, Stagger::M, "acsnom"), acsnow(g, Stagger::M, "acsnow"), snopcx(g, Stagger::M, "snopcx"),
      potevp(g, Stagger::M, "potevp"), noahres(g, Stagger::M, "noahres"), sfcevp(g, Stagger::M, "sfcevp"),
      sfcexc(g, Stagger::M, "sfcexc"), achfx(g, Stagger::M, "achfx"), aclhf(g, Stagger::M, "aclhf"),
      acgrdflx(g, Stagger::M, "acgrdflx"), dx2d(g, Stagger::M, "dx2d"), var2d(g, Stagger::M, "var2d"), uoce(g, Stagger::M, "uoce"),
      voce(g, Stagger::M, "voce"), ctopo(g, Stagger::M, "ctopo"), ctopo2(g, Stagger::M, "ctopo2"),
      ck(g, Stagger::M, "ck"), cka(g, Stagger::M, "cka"), cd(g, Stagger::M, "cd"), cda(g, Stagger::M, "cda"),
      wstar(g, Stagger::M, "wstar"), delta(g, Stagger::M, "delta"), hol(g, Stagger::M, "hol"),
      thz0(g, Stagger::M, "thz0"), uz0(g, Stagger::M, "uz0"), vz0(g, Stagger::M, "vz0"),
      akhs(g, Stagger::M, "akhs"), akms(g, Stagger::M, "akms"), ct(g, Stagger::M, "ct"),
      tshltr(g, Stagger::M, "tshltr"), th10(g, Stagger::M, "th10"), qshltr(g, Stagger::M, "qshltr"),
      q10(g, Stagger::M, "q10"), pshltr(g, Stagger::M, "pshltr"), u10e(g, Stagger::M, "u10e"),
      v10e(g, Stagger::M, "v10e"), mixht(g, Stagger::M, "mixht"),
      ivgtyp(g, "ivgtyp"), isltyp(g, "isltyp"), kpbl(g, "kpbl"), lowlyr(g, "lowlyr"), td_icum(g, "td_icum"), td_row_icum(g, "td_row_icum"), oc12d(g, Stagger::M, "oc12d"), oa1(g, Stagger::M, "oa1"), oa2(g, Stagger::M, "oa2"), oa3(g, Stagger::M, "oa3"), oa4(g, Stagger::M, "oa4"), ol1(g, Stagger::M, "ol1"), ol2(g, Stagger::M, "ol2"), ol3(g, Stagger::M, "ol3"), ol4(g, Stagger::M, "ol4"), elvmax(g, Stagger::M, "elvmax"), dusfcg(g, Stagger::M, "dusfcg"), dvsfcg(g, Stagger::M, "dvsfcg"), dtaux3d(g, Stagger::M, "dtaux3d"), dtauy3d(g, Stagger::M, "dtauy3d"), pt(g), prep(g),
      psim(g, Stagger::M, "psim"), psih(g, Stagger::M, "psih"), gz1oz0(g, Stagger::M, "gz1oz0"),
      chklowq(g, Stagger::M, "chklowq"), qgh(g, Stagger::M, "qgh"), chs(g, Stagger::M, "chs"),
      chs2(g, Stagger::M, "chs2"), cqs2(g, Stagger::M, "cqs2"), cpm(g, Stagger::M, "cpm"),
      u_phytmp(g, Stagger::M, "u_phytmp"), v_phytmp(g, Stagger::M, "v_phytmp"), t1_lag_(g, Stagger::M, "t1_lag"), coszen(g, Stagger::M, "coszen"), rthratenlw(g, Stagger::M, "rthratenlw"), rthratensw(g, Stagger::M, "rthratensw"), rthratenlwc(g, Stagger::M, "rthratenlwc"), rthratenswc(g, Stagger::M, "rthratenswc"), o3rad(g, Stagger::M, "o3rad"), lwcf(g, Stagger::M, "lwcf"), swcf(g, Stagger::M, "swcf"), hrang(g, Stagger::M, "hrang"), uratx(g, Stagger::M, "uratx"), vratx(g, Stagger::M, "vratx"), tratx(g, Stagger::M, "tratx"), ra(g, Stagger::M, "ra"), rs(g, Stagger::M, "rs"), shall(g, Stagger::M, "shall"), lwupt(g, Stagger::M, "lwupt"), lwuptc(g, Stagger::M, "lwuptc"), lwdnt(g, Stagger::M, "lwdnt"), lwdntc(g, Stagger::M, "lwdntc"), lwupb(g, Stagger::M, "lwupb"), lwupbc(g, Stagger::M, "lwupbc"), lwdnb(g, Stagger::M, "lwdnb"), lwdnbc(g, Stagger::M, "lwdnbc"), olr(g, Stagger::M, "olr"), swupt(g, Stagger::M, "swupt"), swuptc(g, Stagger::M, "swuptc"), swdnt(g, Stagger::M, "swdnt"), swdntc(g, Stagger::M, "swdntc"), swupb(g, Stagger::M, "swupb"), swupbc(g, Stagger::M, "swupbc"), swdnb(g, Stagger::M, "swdnb"), swdnbc(g, Stagger::M, "swdnbc"), swvisdir(g, Stagger::M, "swvisdir"), swvisdif(g, Stagger::M, "swvisdif"), swnirdir(g, Stagger::M, "swnirdir"), swnirdif(g, Stagger::M, "swnirdif"), swddir(g, Stagger::M, "swddir"), swddni(g, Stagger::M, "swddni"), swddif(g, Stagger::M, "swddif"), swddirc(g, Stagger::M, "swddirc"), swddnic(g, Stagger::M, "swddnic"), diffuse_frac(g, Stagger::M, "diffuse_frac"), aclwupt(g, Stagger::M, "aclwupt"), aclwuptc(g, Stagger::M, "aclwuptc"), aclwdnt(g, Stagger::M, "aclwdnt"), aclwdntc(g, Stagger::M, "aclwdntc"), aclwupb(g, Stagger::M, "aclwupb"), aclwupbc(g, Stagger::M, "aclwupbc"), aclwdnb(g, Stagger::M, "aclwdnb"), aclwdnbc(g, Stagger::M, "aclwdnbc"), acswupt(g, Stagger::M, "acswupt"), acswuptc(g, Stagger::M, "acswuptc"), acswdnt(g, Stagger::M, "acswdnt"), acswdntc(g, Stagger::M, "acswdntc"), acswupb(g, Stagger::M, "acswupb"), acswupbc(g, Stagger::M, "acswupbc"), acswdnb(g, Stagger::M, "acswdnb"), acswdnbc(g, Stagger::M, "acswdnbc"), g_(g), gs_(g), o_(o) {
  dt_clock_ = wrf_time::from_seconds(g.dt);
  if ((o.sf_sfclay_physics != 1 && o.sf_sfclay_physics != 2 && o.sf_sfclay_physics != 5 && o.sf_sfclay_physics != 7) ||
      (o.sf_surface_physics != 1 && o.sf_surface_physics != 2 && o.sf_surface_physics != 4) ||
      (o.bl_pbl_physics != 0 && o.bl_pbl_physics != 1 && o.bl_pbl_physics != 2 && o.bl_pbl_physics != 5 &&
       o.bl_pbl_physics != 7))
    throw std::runtime_error("PhysicsSuite: only sf_sfclay_physics=1|2|5|7, sf_surface_physics=1|2|4, "
                             "bl_pbl_physics=0|1|2|5|7 (the PX land surface, sf_surface_physics=7, is not ported)");
  // module_physics_init: MYNNPBLSCHEME needs mynnsfc, sfclay or myjsfc (isfc 5, 1 or 2: all of the above).
  // The sea-ice wrappers of sfclayrev / MYJSFC are verified with YSU / MYJ only (no MYNN reference with sea ice)
  if (o.bl_pbl_physics == 5 && o.fractional_seaice == 1)
    throw std::runtime_error("PhysicsSuite: bl_pbl_physics=5 (MYNN) with fractional_seaice=1 is not supported");
  if (o.bl_pbl_physics == 5) {  // bl_mynn_* values with a port (WRF's SELECT CASE / IF branches)
    const mynnedmf::Options& m = o.mynn;
    const bool ok = (m.cloudpdf >= -2 && m.cloudpdf <= 2) && (m.mixlength >= 0 && m.mixlength <= 2) &&
                    (m.edmf == 0 || m.edmf == 1) && (m.edmf_mom == 0 || m.edmf_mom == 1) &&
                    (m.edmf_tke == 0 || m.edmf_tke == 1) && (m.cloudmix == 0 || m.cloudmix == 1) &&
                    (m.mixqt == 0 || m.mixqt == 1) && (m.ess == 0 || m.ess == 1) &&
                    (m.closure == real(2.5) || m.closure == real(2.6) || m.closure == real(3.0)) &&
                    (o.bl_mynn_mixscalars == 0 || o.bl_mynn_mixscalars == 1) &&
                    (o.bl_mynn_output == 0 || o.bl_mynn_output == 1) && (o.tke_budget == 0 || o.tke_budget == 1);
    if (!ok)
      throw std::runtime_error("PhysicsSuite: MYNN options with a port: bl_mynn_cloudpdf -2..2, bl_mynn_mixlength 0..2, "
                               "bl_mynn_edmf 0|1, bl_mynn_edmf_mom|edmf_tke|cloudmix|mixqt|ess|mixscalars|output 0|1, "
                               "tke_budget 0|1, bl_mynn_closure 2.5|2.6|3.0");
  }
  // ra_init (module_physics_init.F:2577-2582): bucket_J needs the AC* arrays of CAM or RRTMG LW and SW
  if (o.bucket_j > 0 && !(o.rad.ra_lw_physics == 4 && o.rad.ra_sw_physics == 4))
    throw std::runtime_error("PhysicsSuite: bucket_j > 0 needs RRTMG radiation (WRF: 'Need CAM or RRTMG radiation "
                             "for bucket_J option')");
  // grav_settling 0, 1, 2 (Registry); sf_fogdes stops for land-use data other than USGS and
  // MODIFIED_IGBP_MODIS_NOAH; the deposition runs in the surface and PBL drivers
  if (o.grav_settling < 0 || o.grav_settling > 2)
    throw std::runtime_error("PhysicsSuite: grav_settling must be 0, 1 or 2");
  if (o.grav_settling > 0) {
    std::string lu = o.mminlu;
    while (!lu.empty() && (lu.back() == ' ' || lu.back() == '\0')) lu.pop_back();
    if (lu != "USGS" && lu != "MODIFIED_IGBP_MODIS_NOAH")
      throw std::runtime_error("PhysicsSuite: grav_settling needs USGS or MODIFIED_IGBP_MODIS_NOAH land use (as "
                               "WRF's sf_fogdes), not " + lu);
    if (o.bl_pbl_physics == 0 || o.sf_sfclay_physics == 0)
      throw std::runtime_error("PhysicsSuite: grav_settling needs a PBL scheme and a surface layer");
  }
  // module_physics_init.F pbl_select: YSU stops unless isfc = 1 (sfclay), MYJ unless isfc = 2 (myjsfc)
  if (o.bl_pbl_physics == 1 && o.sf_sfclay_physics != 1)
    throw std::runtime_error("PhysicsSuite: bl_pbl_physics=1 (YSU) needs sf_sfclay_physics=1, as WRF");
  if (o.bl_pbl_physics == 2 && o.sf_sfclay_physics != 2)
    throw std::runtime_error("PhysicsSuite: bl_pbl_physics=2 (MYJ) needs sf_sfclay_physics=2, as WRF");
  // ACMPBLSCHEME: 'use sfclay or pxsfc scheme for this pbl option' (isfc 1 or 7)
  if (o.bl_pbl_physics == 7 && o.sf_sfclay_physics != 1 && o.sf_sfclay_physics != 7)
    throw std::runtime_error("PhysicsSuite: bl_pbl_physics=7 (ACM2) needs sf_sfclay_physics=1 or 7, as WRF");
  // the Pleim-Xiu surface layer is ported with the ACM2 PBL and the Noah LSM (the proven combination; WRF also runs it
  // under MYNN's or no PBL scheme, and its sea-ice wrapper PXSFCLAY_SEAICE_WRAPPER is not ported)
  if (o.sf_sfclay_physics == 7 && (o.bl_pbl_physics != 7 || o.sf_surface_physics != 2 || o.fractional_seaice != 0 ||
                                   o.isfflx == 0))
    throw std::runtime_error("PhysicsSuite: sf_sfclay_physics=7 (Pleim-Xiu) is supported with bl_pbl_physics=7, "
                             "sf_surface_physics=2, fractional_seaice=0 and isfflx=1 only");
  // isfflx 0 skips the LSMs, the only writers of CHKLOWQ (uninitialised in WRF), which MYJPBL reads
  if (o.bl_pbl_physics == 2 && o.isfflx == 0)
    throw std::runtime_error("PhysicsSuite: bl_pbl_physics=2 (MYJ) with isfflx=0 is not supported (WRF reads an "
                             "uninitialised CHKLOWQ)");
  // isftcflx / iz0tlnd: sfclayrev's forms (MYJSFC ignores them as WRF's); iz0tlnd > 2 leaves czil undefined in WRF
  if (o.isftcflx < 0 || o.isftcflx > 2 || o.iz0tlnd < 0 || o.iz0tlnd > 2)
    throw std::runtime_error("PhysicsSuite: isftcflx and iz0tlnd must be 0, 1 or 2");
  // the MYNN surface layer reads sf_mynn_sfcflux_land / _water (isftcflx / iz0tlnd do not reach it in WRF 4.8);
  // their GFS forms (4 / 5) are not ported
  if (o.sf_sfclay_physics == 5 && (o.sf_mynn_sfcflux_land < 0 || o.sf_mynn_sfcflux_land > 3 ||
                                   o.sf_mynn_sfcflux_water < 0 || o.sf_mynn_sfcflux_water > 4))
    throw std::runtime_error("PhysicsSuite: sf_mynn_sfcflux_land 0..3 and sf_mynn_sfcflux_water 0..4 are ported");
  if (o.sf_sfclay_physics == 5 && o.fractional_seaice == 1)
    throw std::runtime_error("PhysicsSuite: sf_sfclay_physics=5 with fractional_seaice=1 (MYNN_SEAICE_WRAPPER) is not ported");
  if (o.cu_physics != 0 && o.cu_physics != 1 && o.cu_physics != 3 && o.cu_physics != 6 && o.cu_physics != 16)
    throw std::runtime_error("PhysicsSuite: only cu_physics=0, 1 (Kain-Fritsch), 3 (Grell-Freitas-Li), 6 (Tiedtke) or 16 (New Tiedtke)");
  if (o.cu_physics == 3 && g.nz > cu_gfl::kMaxLevels)
    throw std::runtime_error("PhysicsSuite: nz exceeds the Grell-Freitas-Li column limit");
  // ishallow: WRF's GF runs the shallow plume for ishallow == 1 only, any other value is off.
  // clos_choice above 16 reads past xf_ens (undefined in WRF too); a negative one is the full ensemble.
  if (o.cu_physics == 3 && o.gf_ichoice > 16)
    throw std::runtime_error("PhysicsSuite: clos_choice must be at most 16");
  if (o.cu_physics == 6 && g.nz > cu_tiedtke::kMaxLevels)
    throw std::runtime_error("PhysicsSuite: nz exceeds the Tiedtke column limit");
  if (o.cu_physics == 16 && g.nz > cu_ntiedtke::kMaxLevels)
    throw std::runtime_error("PhysicsSuite: nz exceeds the New Tiedtke column limit");
  if (o.opt_thcnd != 1 && o.opt_thcnd != 2)
    throw std::runtime_error("PhysicsSuite: opt_thcnd must be 1 or 2");
  if (o.cu_physics == 1 && o.kfeta_trigger != 1 && o.kfeta_trigger != 3)
    throw std::runtime_error("PhysicsSuite: kfeta_trigger=2 is not supported");
  if (o.fractional_seaice != 0 && o.fractional_seaice != 1)
    throw std::runtime_error("PhysicsSuite: fractional_seaice must be 0 or 1");
  if (o.sst_update != 0 && o.sst_update != 1) throw std::runtime_error("PhysicsSuite: sst_update must be 0 or 1");
  if (o.fractional_seaice == 1 || o.sst_update == 1) {
    sst = Field2(g, Stagger::M, "sst");
    tsk_save = Field2(g, Stagger::M, "tsk_save");
  }
  if (o.fractional_seaice == 1) sea_ = std::make_unique<SeaIceFields>(g);
  if (o.sst_update == 1) xicem = Field2(g, Stagger::M, "xicem");
  // sst_skin / tmn_update: surface_driver every step (module_surface_driver.F:1855-1895). Ported with the Noah LSM
  // (the reference runs); check_a_mundo stops tmn_update = 1 with lagday = 1
  if (o.sst_skin != 0 && o.sst_skin != 1) throw std::runtime_error("PhysicsSuite: sst_skin must be 0 or 1");
  if (o.tmn_update != 0 && o.tmn_update != 1) throw std::runtime_error("PhysicsSuite: tmn_update must be 0 or 1");
  if ((o.sst_skin == 1 || o.tmn_update == 1) && o.sf_surface_physics != 2)
    throw std::runtime_error("PhysicsSuite: sst_skin = 1 and tmn_update = 1 are supported with the Noah LSM "
                             "(sf_surface_physics = 2) only");
  if (o.tmn_update == 1 && o.lagday == 1) throw std::runtime_error("--- ERROR: Using tmn_update=1 requires lagday=150 ");
  if (o.tmn_update == 1 && o.lagday < 1) throw std::runtime_error("PhysicsSuite: lagday must be at least 1");
  if (o.sst_skin == 1) {
    if (!sst.layout().total) sst = Field2(g, Stagger::M, "sst");
    sstsk = Field2(g, Stagger::M, "sstsk");
    dtw = Field2(g, Stagger::M, "dtw");
  }
  if (o.tmn_update == 1) {
    tyr = Field2(g, Stagger::M, "tyr");
    tyra = Field2(g, Stagger::M, "tyra");
    tdly = Field2(g, Stagger::M, "tdly");
    Grid gl = g;
    gl.nz = o.lagday;
    tlag = Field3(gl, Stagger::M, "tlag");
  }
  // grid nudging: package psufddagd (grid_fdda == 1); fddagdinit's checks (module_fdda_psufddagd.F)
  if (o.fdda.grid_fdda != 0 && o.fdda.grid_fdda != 1)
    throw std::runtime_error("PhysicsSuite: grid_fdda = " + std::to_string(o.fdda.grid_fdda) +
                             " is not supported (0 or 1; spectral nudging, grid_fdda = 2, is not ported)");
  if (o.fdda.grid_fdda == 1) {
    if (o.fdda.guv < 0) throw std::runtime_error("In grid FDDA, Guv must be positive.");
    if (o.fdda.gt < 0) throw std::runtime_error("In grid FDDA, Gt must be positive.");
    if (o.fdda.gq < 0) throw std::runtime_error("In grid FDDA, Gq must be positive.");
    if (o.fdda.interval_m <= 0) throw std::runtime_error("In grid FDDA, gfdda_interval_m must be > 0");
    for (auto [f, name] : std::initializer_list<std::pair<Field3*, const char*>>{
             {&u_ndg_old, "u_ndg_old"}, {&v_ndg_old, "v_ndg_old"}, {&t_ndg_old, "t_ndg_old"}, {&q_ndg_old, "q_ndg_old"},
             {&ph_ndg_old, "ph_ndg_old"}, {&u_ndg_new, "u_ndg_new"}, {&v_ndg_new, "v_ndg_new"},
             {&t_ndg_new, "t_ndg_new"}, {&q_ndg_new, "q_ndg_new"}, {&ph_ndg_new, "ph_ndg_new"}, {&hfx_fdda, "hfx_fdda"}})
      *f = Field3(g, Stagger::M, name);
    mu_ndg_old = Field2(g, Stagger::M, "mu_ndg_old");
    mu_ndg_new = Field2(g, Stagger::M, "mu_ndg_new");
    pt.rundgdten = Field3(g, Stagger::U, "rundgdten");
    pt.rvndgdten = Field3(g, Stagger::V, "rvndgdten");
    pt.rthndgdten = Field3(g, Stagger::M, "rthndgdten");
    pt.rqvndgdten = Field3(g, Stagger::M, "rqvndgdten");
  }
  if (o.seaice_thickness_opt != 0 || o.seaice_snowdepth_opt != 0)
    throw std::runtime_error("PhysicsSuite: seaice_thickness_opt/seaice_snowdepth_opt 1 need ICEDEPTH/SNOWSI input");
  if (o.seaice_albedo_opt != 0)
    throw std::runtime_error("PhysicsSuite: seaice_albedo_opt 1 and 2 are not supported (2 needs ALBSI input)");
  if (o.num_soil_layers > noah::kMaxSoilLevels) throw std::runtime_error("PhysicsSuite: too many soil layers");
  // check_a_mundo sets num_soil_layers = 4 for Noah (SFLX scales ET(1:4) only)
  if (o.sf_surface_physics == 2 && o.num_soil_layers != 4)
    throw std::runtime_error("PhysicsSuite: Noah requires num_soil_layers=4");
  if (o.sf_surface_physics == 1) {  // check_a_mundo: 5 layers; no fractional sea ice with the slab (fatal in WRF)
    if (o.num_soil_layers != slab::kSoilLayers)
      throw std::runtime_error("PhysicsSuite: the slab LSM requires num_soil_layers=5");
    if (o.fractional_seaice == 1)
      throw std::runtime_error("PhysicsSuite: fractional_seaice=1 does not work with the slab LSM, as in WRF");
    if (o.sst_update == 1)  // the water points' TSLB(1) = SST of the sst_update branch: no reference run
      throw std::runtime_error("PhysicsSuite: sst_update=1 with the slab LSM (sf_surface_physics=1) is not supported");
    thc = Field2(g, Stagger::M, "thc");
    capg = Field2(g, Stagger::M, "capg");
  }
  if (o.sf_surface_physics == 4) {
    if (o.num_soil_layers != 4) throw std::runtime_error("PhysicsSuite: Noah-MP requires num_soil_layers=4");
    if (o.mminlu == "NLCD40") throw std::runtime_error("PhysicsSuite: Noah-MP does not support NLCD40 landuse");
    noahmp::validate_noahmp_options(o.noahmp);
  }
  if (o.bl_pbl_physics == 1 && g.nz > ysu::kMaxLevels)
    throw std::runtime_error("PhysicsSuite: nz exceeds the YSU column limit");
  if (o.bl_pbl_physics == 5 && g.nz > mynnedmf::kMaxLevels)
    throw std::runtime_error("PhysicsSuite: nz exceeds the MYNN-EDMF column limit");
  if (o.bl_pbl_physics == 7 && g.nz > acm::kMaxLevels)
    throw std::runtime_error("PhysicsSuite: nz exceeds the ACM2 column limit");
  if (o.bl_pbl_physics == 2 && g.nz > myjpbl::kMaxLevels)
    throw std::runtime_error("PhysicsSuite: nz exceeds the MYJ column limit");
  if (o.sf_sfclay_physics == 2 && g.nz > sf_myjsfc::kMaxLevels)
    throw std::runtime_error("PhysicsSuite: nz exceeds the MYJSFC column limit");
  if (o.gwd_opt != 0 && o.gwd_opt != 1)
    throw std::runtime_error("PhysicsSuite: only gwd_opt=0 or 1 (GWDO)");
  if (o.gwd_opt == 1 && g.nz > bl_gwdo::kMaxLevels)
    throw std::runtime_error("PhysicsSuite: nz exceeds the GWDO column limit");
  if (o.cu_physics == 1 && g.nz > cu_kf::kMaxLevels)
    throw std::runtime_error("PhysicsSuite: nz exceeds the KF column limit");
  gs_.nz = o.num_soil_layers;
  auto mk3 = [&](Field3& f, const Grid& gg, const char* n) { f = Field3(gg, Stagger::M, n); };
  mk3(tslb, gs_, "tslb"); mk3(smois, gs_, "smois"); mk3(sh2o, gs_, "sh2o"); mk3(smcrel, gs_, "smcrel");
  mk3(exch_h, g, "exch_h"); mk3(exch_m, g, "exch_m");
  mk3(tke_pbl, g, "tke_pbl"); mk3(el_pbl, g, "el_pbl");
  mk3(w0avg, g, "w0avg"); mk3(cldfra_dp, g, "cldfra_dp"); mk3(cldfra_sh, g, "cldfra_sh");
  mk3(qc_cu, g, "qc_cu"); mk3(qi_cu, g, "qi_cu"); mk3(cldfra, g, "cldfra");
  mk3(gd_cloud, g, "gd_cloud"); mk3(gd_cloud2, g, "gd_cloud2");
  mk3(gd_cloud_a, g, "gd_cloud_a"); mk3(gd_cloud2_a, g, "gd_cloud2_a");
  mk3(gd_cldfr, g, "gd_cldfr");
  mk3(zero3_, g, "zero3");
  dzs.assign(o.num_soil_layers, 0.0);
  zs.assign(o.num_soil_layers, 0.0);
  if (o.sf_surface_physics == 2) {
    mk3(n_stc, gs_, "n_stc"); mk3(n_smc, gs_, "n_smc"); mk3(n_swc, gs_, "n_swc"); mk3(n_et, gs_, "n_et");
    mk3(n_smav, gs_, "n_smav");
    for (Field2* f : {&n_lwdn, &n_soldn, &n_solnet, &n_sfcprs, &n_prcp, &n_sfctmp, &n_th2, &n_q2, &n_q2sat, &n_dqsdt2,
                      &n_ffrozp, &n_shdfac, &n_shmin, &n_shmax, &n_albbrd, &n_snoalb1, &n_tbot, &n_z0brd, &n_emissi,
                      &n_embrd, &n_cmc, &n_t1, &n_snowhk, &n_sneqv, &n_chk, &n_cm, &n_albedok, &n_z0k, &n_xlai,
                      &n_snotime1, &n_ribb, &n_eta, &n_sheat, &n_eta_kin, &n_fdown, &n_ec, &n_edir, &n_ett, &n_esnow,
                      &n_drip, &n_dew, &n_beta, &n_etp, &n_ssoil, &n_flx1, &n_flx2, &n_flx3, &n_snomlt, &n_sncovr,
                      &n_runoff1, &n_runoff2, &n_runoff3, &n_rc, &n_pc, &n_rsmin, &n_soilw, &n_soilm, &n_q1})
      *f = Field2(g, Stagger::M, "noah_scratch");
    n_vegtyp = IntField2(g, "n_vegtyp"); n_soiltyp = IntField2(g, "n_soiltyp"); n_slopetyp = IntField2(g, "n_slopetyp");
    n_ice = IntField2(g, "n_ice"); n_active = IntField2(g, "n_active");
    n_rclast = IntField2(g, "n_rclast");
    if (!noah::read_noah_tables(o.table_dir, o.mminlu, o.mminsl, noah_tables_))
      throw std::runtime_error("PhysicsSuite: cannot read the Noah tables from " + o.table_dir);
  } else if (o.sf_surface_physics == 4) {
    auto mk2 = [&](Field2& f, const char* n) { f = Field2(g, Stagger::M, n); };
    mk2(xlat_sfc, "xlat_sfc"); mk2(xlong_sfc, "xlong_sfc");
    mk2(tvxy, "tvxy"); mk2(tgxy, "tgxy"); mk2(canicexy, "canicexy"); mk2(canliqxy, "canliqxy");
    mk2(eahxy, "eahxy"); mk2(tahxy, "tahxy"); mk2(cmxy, "cmxy"); mk2(chxy, "chxy");
    mk2(fwetxy, "fwetxy"); mk2(sneqvoxy, "sneqvoxy"); mk2(alboldxy, "alboldxy");
    mk2(qsnowxy, "qsnowxy"); mk2(qrainxy, "qrainxy"); mk2(wslakexy, "wslakexy");
    mk2(zwtxy, "zwtxy"); mk2(waxy, "waxy"); mk2(wtxy, "wtxy");
    mk2(lfmassxy, "lfmassxy"); mk2(rtmassxy, "rtmassxy"); mk2(stmassxy, "stmassxy");
    mk2(woodxy, "woodxy"); mk2(stblcpxy, "stblcpxy"); mk2(fastcpxy, "fastcpxy");
    mk2(xsaixy, "xsaixy"); mk2(taussxy, "taussxy"); mk2(smcwtdxy, "smcwtdxy");
    mk2(deeprechxy, "deeprechxy"); mk2(rechxy, "rechxy"); mk2(grainxy, "grainxy");
    mk2(gddxy, "gddxy"); mk2(qtdrain, "qtdrain");
    mk2(t2mvxy, "t2mvxy"); mk2(t2mbxy, "t2mbxy"); mk2(q2mvxy, "q2mvxy"); mk2(q2mbxy, "q2mbxy");
    mk2(tradxy, "tradxy"); mk2(neexy, "neexy"); mk2(gppxy, "gppxy"); mk2(nppxy, "nppxy");
    mk2(fvegxy, "fvegxy"); mk2(runsfxy, "runsfxy"); mk2(runsbxy, "runsbxy");
    mk2(ecanxy, "ecanxy"); mk2(edirxy, "edirxy"); mk2(etranxy, "etranxy");
    mk2(fsaxy, "fsaxy"); mk2(firaxy, "firaxy"); mk2(aparxy, "aparxy"); mk2(psnxy, "psnxy");
    mk2(savxy, "savxy"); mk2(sagxy, "sagxy"); mk2(rssunxy, "rssunxy"); mk2(rsshaxy, "rsshaxy");
    mk2(bgapxy, "bgapxy"); mk2(wgapxy, "wgapxy"); mk2(tgvxy, "tgvxy"); mk2(tgbxy, "tgbxy");
    mk2(chvxy, "chvxy"); mk2(chbxy, "chbxy"); mk2(shgxy, "shgxy"); mk2(shcxy, "shcxy");
    mk2(shbxy, "shbxy"); mk2(evgxy, "evgxy"); mk2(evbxy, "evbxy"); mk2(ghvxy, "ghvxy");
    mk2(ghbxy, "ghbxy"); mk2(irgxy, "irgxy"); mk2(ircxy, "ircxy"); mk2(irbxy, "irbxy");
    mk2(trxy, "trxy"); mk2(evcxy, "evcxy"); mk2(chleafxy, "chleafxy"); mk2(chucxy, "chucxy");
    mk2(chv2xy, "chv2xy"); mk2(chb2xy, "chb2xy"); mk2(chstarxy, "chstarxy");
    mk2(acc_ssoilxy, "acc_ssoil"); mk2(acc_qinsurxy, "acc_qinsur"); mk2(acc_qsevaxy, "acc_qseva");
    mk2(eflxbxy, "eflxbxy");
    mk2(acc_dwaterxy, "acc_dwaterxy"); mk2(acc_prcpxy, "acc_prcpxy"); mk2(acc_ecanxy, "acc_ecanxy");
    mk2(acc_etranxy, "acc_etranxy"); mk2(acc_edirxy, "acc_edirxy"); mk2(acc_glaflwxy, "acc_glaflwxy");
    isnowxy = IntField2(g, "isnowxy"); cropcat = IntField2(g, "cropcat"); pgsxy = IntField2(g, "pgsxy");
    isnowxy.upload(std::vector<int>(isnowxy.layout().total, 0));
    cropcat.upload(std::vector<int>(cropcat.layout().total, 0));
    pgsxy.upload(std::vector<int>(pgsxy.layout().total, 0));
    noahmp_ranland = IntField2(g, "noahmp_ranland");
    noahmp_ranland.upload(std::vector<int>(noahmp_ranland.layout().total, 0));
    Grid gsno = g; gsno.nz = noahmp::kMaxSnowLayers;
    Grid gsnso = g; gsnso.nz = noahmp::kMaxSnowLayers + o.num_soil_layers;
    Grid gband = g; gband.nz = noahmp::kNumRadBands;
    mk3(tsnoxy, gsno, "tsnoxy"); mk3(snicexy, gsno, "snicexy"); mk3(snliqxy, gsno, "snliqxy");
    mk3(zsnsoxy, gsnso, "zsnsoxy");
    mk3(albsoildirxy, gband, "albsoildirxy"); mk3(albsoildifxy, gband, "albsoildifxy");
    mk3(smoiseq, gs_, "smoiseq"); mk3(acc_etranixy, gs_, "acc_etrani");
    if (!noahmp::read_noahmp_tables(o.table_dir, o.mminlu, noahmp_tables_))
      throw std::runtime_error("PhysicsSuite: cannot read NoahmpTable.TBL from " + o.table_dir);
    d_noahmp_tables_ = static_cast<noahmp::NoahmpTables*>(dev_alloc(sizeof(noahmp_tables_)));
    copy_to_dev(d_noahmp_tables_, &noahmp_tables_, sizeof(noahmp_tables_));
  }
  if (o.sf_sfclay_physics == 1) {
    sfclayrev::SFClayRevTables<real> h{};
    sfclayrev::init_sfclayrev_tables(h);
    d_sfclay_tables_ = static_cast<sfclayrev::SFClayRevTables<real>*>(dev_alloc(sizeof(h)));
    copy_to_dev(d_sfclay_tables_, &h, sizeof(h));
  }
  if (o.sf_sfclay_physics == 2) {
    lowlyr.upload(std::vector<int>(lowlyr.layout().total, 1));  // myjsfcinit: LOWLYR = 1
    ust.fill_host([](int, int, int) { return 0.1; });           // myjsfcinit: USTAR = 0.1
  }
  if (o.sf_sfclay_physics == 5) {  // mynnsfc_init -> psi_init
    mynnsfc::PsiTables* h = new mynnsfc::PsiTables;
    mynnsfc::psi_init(*h);
    d_mynn_psi_ = static_cast<mynnsfc::PsiTables*>(dev_alloc(sizeof(*h)));
    copy_to_dev(d_mynn_psi_, h, sizeof(*h));
    delete h;
    cqs = Field2(g, Stagger::M, "cqs");
  }
  if (o.bl_pbl_physics == 5) {
    mk3(qke, g, "qke"); mk3(tsq, g, "tsq"); mk3(qsq, g, "qsq"); mk3(cov, g, "cov"); mk3(sh3d, g, "sh3d");
    mk3(sm3d, g, "sm3d"); mk3(qc_bl, g, "qc_bl"); mk3(qi_bl, g, "qi_bl"); mk3(cldfra_bl, g, "cldfra_bl");
    maxwidth = Field2(g, Stagger::M, "maxwidth"); maxmf = Field2(g, Stagger::M, "maxmf");
    ztop_plume = Field2(g, Stagger::M, "ztop_plume"); excess_h = Field2(g, Stagger::M, "excess_h");
    excess_q = Field2(g, Stagger::M, "excess_q");
    if (o.bl_mynn_output > 0) {
      mk3(edmf_a, g, "edmf_a"); mk3(edmf_w, g, "edmf_w"); mk3(edmf_thl, g, "edmf_thl"); mk3(edmf_qt, g, "edmf_qt");
      mk3(edmf_ent, g, "edmf_ent"); mk3(edmf_qc, g, "edmf_qc");
    }
    // mynnedmf's column arrays and DMP_mf's plume arrays in the GPU's work buffer (pbl_driver: run_mynn_gpu, 48 or
    // kMaxLevels levels)
    column_work_reserve(g.columns(),
                        g.nz <= 48 ? mynnedmf::kWorkBytes<48> : mynnedmf::kWorkBytes<mynnedmf::kMaxLevels>);
    if (o.tke_budget == 1) {
      mk3(qshear, g, "qshear"); mk3(qbuoy, g, "qbuoy"); mk3(qdiss, g, "qdiss"); mk3(qwt, g, "qwt");
      mk3(dqke, g, "dqke");
    }
  }
  if (o.grav_settling > 0) {
    vdfg = Field2(g, Stagger::M, "vdfg");
    dfgdp = Field2(g, Stagger::M, "dfgdp");
  }
  if (o.bl_pbl_physics == 2) {
    lowlyr.upload(std::vector<int>(lowlyr.layout().total, 1));
    tke_pbl.fill_host([](int, int, int) { return 0.2; });       // myjpblinit: TKE_MYJ = EPSQ2 = 0.2
  }
  if (o.cu_physics == 1) {
    using namespace wrfc;
    cu_kf::KFTables<real> h_kf{};
    cu_kf::init_kf_tables(h_kf, svp1, svp2, svp3, svpt0);
    d_kf_tables_ = static_cast<cu_kf::KFTables<real>*>(dev_alloc(sizeof(h_kf)));
    copy_to_dev(d_kf_tables_, &h_kf, sizeof(h_kf));
    nca.fill_host([](int, int, int) { return -100.0; });  // kf_eta_init default for non-restart
  }
  // bldt = 0: every step; otherwise WRF stepbl = nint(bldt*60/dt), at least 1
  stepbl = o.bldt == 0 ? 1 : int(std::lround(o.bldt * 60. / g.dt));
  if (stepbl < 1) stepbl = 1;
  // cu_init (module_physics_init.F:4025-4026): STEPCU = max(nint(CUDT*60./DT), 1)
  stepcu = int(std::lround(o.cudt * 60. / g.dt));
  if (stepcu < 1) stepcu = 1;
  // fg_init (module_physics_init.F:4953-4954): STEPFG = max(nint(FGDT*60./DT), 1)
  stepfg = int(std::lround(real(o.fdda.fgdt) * real(60.) / real(g.dt)));
  if (stepfg < 1) stepfg = 1;
  // Registry packages prec_acc (prec_acc_opt == 1), bucketropt (bucketr_opt == 1), bucketfopt (bucketf_opt == 1)
  if (o.prec_acc_opt) {
    prec_acc_c = Field2(g, Stagger::M, "prec_acc_c");
    prec_acc_nc = Field2(g, Stagger::M, "prec_acc_nc");
    snow_acc_nc = Field2(g, Stagger::M, "snow_acc_nc");
  }
  if (o.bucket_mm > 0) {
    i_rainc = IntField2(g, "i_rainc");
    i_rainnc = IntField2(g, "i_rainnc");
  }
  if (o.bucket_j > 0) {
    const std::array<Field2*, 16> ac = acrad();
    for (std::size_t k = 0; k < ac.size(); ++k) i_acrad[k] = IntField2(g, "i_" + ac[k]->name());
  }
  if (o.output_diagnostics == 1) {  // Registry package maxmin_output (output_diagnostics == 1)
    static const char* const names[] = {
        "t2min", "t2max", "tt2min", "tt2max", "t2mean", "t2std", "q2min", "q2max", "tq2min", "tq2max", "q2mean",
        "q2std", "skintempmin", "skintempmax", "tskintempmin", "tskintempmax", "skintempmean", "skintempstd",
        "u10max", "v10max", "spduv10max", "tspduv10max", "u10mean", "v10mean", "spduv10mean", "u10std", "v10std",
        "spduv10std", "raincvmax", "rainncvmax", "traincvmax", "trainncvmax", "raincvmean", "rainncvmean",
        "raincvstd", "rainncvstd"};
    clwrf_ = {&t2min, &t2max, &tt2min, &tt2max, &t2mean, &t2std, &q2min, &q2max, &tq2min, &tq2max, &q2mean, &q2std,
              &skintempmin, &skintempmax, &tskintempmin, &tskintempmax, &skintempmean, &skintempstd, &u10max,
              &v10max, &spduv10max, &tspduv10max, &u10mean, &v10mean, &spduv10mean, &u10std, &v10std, &spduv10std,
              &raincvmax, &rainncvmax, &traincvmax, &trainncvmax, &raincvmean, &rainncvmean, &raincvstd,
              &rainncvstd};
    for (std::size_t k = 0; k < clwrf_.size(); ++k) *clwrf_[k] = Field2(g, Stagger::M, names[k]);
  }
}

std::array<Field2*, 16> PhysicsSuite::acrad() {
  return {&acswupt, &acswuptc, &acswdnt, &acswdntc, &acswupb, &acswupbc, &acswdnb, &acswdnbc,
          &aclwupt, &aclwuptc, &aclwdnt, &aclwdntc, &aclwupb, &aclwupbc, &aclwdnb, &aclwdnbc};
}

IntField2* PhysicsSuite::bucket_int(const std::string& name) {
  if (o_.bucket_mm > 0 && name == "i_rainc") return &i_rainc;
  if (o_.bucket_mm > 0 && name == "i_rainnc") return &i_rainnc;
  if (o_.bucket_j > 0)
    for (IntField2& f : i_acrad)
      if (f.name() == name) return &f;
  return nullptr;
}

void PhysicsSuite::init_radiation(const std::vector<double>& xlat, const std::vector<double>& xlong) {
  if (!radiation_on()) return;
  rad_ = std::make_unique<RadiationDriver>(g_, o_.rad, xlat, xlong);
}

namespace {
// phy_init (module_physics_init.F:1287-1301): the tmn_update state from TMN
struct KTmnUpdateInit {
  C2 tmn;
  V2 tyr, tyra, tdly;
  V3 tlag;
  int lagday;
  CPPWRF_HD void operator()(int i, int j) const {
    tyr(i, j) = tmn(i, j);
    tyra(i, j) = real(0.0);
    tdly(i, j) = real(0.0);
    for (int n = 0; n < lagday; ++n) tlag(i, j, n) = tmn(i, j);
  }
};
}  // namespace

void PhysicsSuite::init_tmn_update() {
  if (o_.tmn_update != 1) return;
  nyear = 1;
  nday = real(0.);
  column_for(g_.columns(), KTmnUpdateInit{tmn.cview(), tyr.view(), tyra.view(), tdly.view(), tlag.view(), o_.lagday});
}

void PhysicsSuite::init_noahmp(bool fndsnowh) {
  if (o_.sf_surface_physics != 4) return;
  noahmp::NoahmpInitKernel k{};
  k.ivgtyp = ivgtyp.cview();
  k.isltyp = isltyp.cview();
  k.tsk = tsk.cview();
  k.xice = xice.cview();
  k.tmn = tmn.view();
  k.snow = snow.view();
  k.snowh = snowh.view();
  k.canwat = canwat.view();
  k.tslb = tslb.view();
  k.smois = smois.view();
  k.sh2o = sh2o.view();
  k.isnowxy = isnowxy.view();
  k.tvxy = tvxy.view();
  k.tgxy = tgxy.view();
  k.canicexy = canicexy.view();
  k.canliqxy = canliqxy.view();
  k.eahxy = eahxy.view();
  k.tahxy = tahxy.view();
  k.cmxy = cmxy.view();
  k.chxy = chxy.view();
  k.fwetxy = fwetxy.view();
  k.sneqvoxy = sneqvoxy.view();
  k.alboldxy = alboldxy.view();
  k.qsnowxy = qsnowxy.view();
  k.qrainxy = qrainxy.view();
  k.wslakexy = wslakexy.view();
  k.zwtxy = zwtxy.view();
  k.waxy = waxy.view();
  k.wtxy = wtxy.view();
  k.lfmassxy = lfmassxy.view();
  k.rtmassxy = rtmassxy.view();
  k.stmassxy = stmassxy.view();
  k.woodxy = woodxy.view();
  k.stblcpxy = stblcpxy.view();
  k.fastcpxy = fastcpxy.view();
  k.xsaixy = xsaixy.view();
  k.lai = lai.view();
  k.grainxy = grainxy.view();
  k.gddxy = gddxy.view();
  k.cropcat = cropcat.view();
  k.t2mvxy = t2mvxy.view();
  k.t2mbxy = t2mbxy.view();
  k.chstarxy = chstarxy.view();
  k.qtdrain = qtdrain.view();
  k.tsnoxy = tsnoxy.view();
  k.snicexy = snicexy.view();
  k.snliqxy = snliqxy.view();
  k.zsnsoxy = zsnsoxy.view();
  k.albsoildirxy = albsoildirxy.view();
  k.albsoildifxy = albsoildifxy.view();
  k.tables = d_noahmp_tables_;
  k.nsoil = o_.num_soil_layers;
  k.nsnow = noahmp::kMaxSnowLayers;
  for (int ns = 0; ns < o_.num_soil_layers; ++ns) k.dzs[ns] = real(dzs[ns]);
  k.fndsnowh = fndsnowh;
  k.restart = false;
  k.iopt_runsub = o_.noahmp.opt_runsub;
  k.iopt_crop = o_.noahmp.opt_crop;
  k.sf_urban_physics = o_.noahmp.sf_urban_physics;
  noahmp::run_noahmp_init(k, g_.columns());
}

PhysicsSuite::~PhysicsSuite() {
  if (d_noahmp_tables_) dev_free(d_noahmp_tables_);
  if (d_sfclay_tables_) dev_free(d_sfclay_tables_);
  if (d_kf_tables_) dev_free(d_kf_tables_);
  if (d_mynn_psi_) dev_free(d_mynn_psi_);
}

PhysicsSuite::SeaIceFields::SeaIceFields(const Grid& g) {
  for (Field2* f : {&tsk_local, &tsk_sea, &xland_sea, &mavail_sea, &znt_sea, &z0base_sea, &br_sea, &chs_sea, &chs2_sea,
                    &cqs2_sea, &cpm_sea, &flhc_sea, &flqc_sea, &gz1oz0_sea, &hfx_sea, &qfx_sea, &lh_sea, &mol_sea,
                    &psim_sea, &psih_sea, &fm_sea, &fh_sea, &qgh_sea, &qsfc_sea, &regime_sea, &rmol_sea, &ust_sea,
                    &ustm_sea, &wspd_sea, &zol_sea, &u10_sea, &v10_sea, &th2_sea, &t2_sea, &q2_sea, &ck_sea, &cka_sea,
                    &cd_sea, &cda_sea, &qz0_sea, &thz0_sea, &uz0_sea, &vz0_sea, &pblh_sea, &akhs_sea, &akms_sea,
                    &ct_sea, &tshltr_sea, &th10_sea, &qshltr_sea, &q10_sea, &pshltr_sea, &u10e_sea, &v10e_sea,
                    &regime_hold})
    *f = Field2(g, Stagger::M, "seaice_scratch");
}

std::vector<std::pair<std::string, Field2*>> PhysicsSuite::carried2() {
  std::vector<std::pair<std::string, Field2*>> v;
  for (Field2* f : {&tsk, &xland, &xice, &lakemask, &water_depth, &mavail, &tmn, &vegfra, &shdmin, &shdmax, &snoalb,
                    &albbck, &albedo, &emiss, &embck, &znt, &z0, &ust, &ustm, &mol, &rmol, &pblh, &hfx, &qfx, &lh,
                    &grdflx, &qsfc, &flhc, &flqc, &wspd, &br, &fm, &fh, &zol, &regime, &u10, &v10, &t2, &th2, &q2,
                    &psfc, &ch, &snow, &snowh, &snowc, &canwat, &lai, &snotime, &qz0, &rainbl, &raincv, &raincv_a,
                    &raincv_b, &rainncv,
                    &rainshv, &sr, &glw, &swdown, &gsw, &smstav, &smstot, &sfcrunoff, &udrunoff, &acsnom, &acsnow,
                    &snopcx, &potevp, &noahres, &sfcevp, &sfcexc, &achfx, &aclhf, &acgrdflx, &dx2d, &uoce, &voce,
                    &ctopo, &ctopo2, &ck, &cka, &cd, &cda, &wstar, &delta, &hol, &rainc, &rainsh, &pratec, &pratesh, &nca, &htop, &hbot,
                    &cutop, &cubot, &cuppt, &coszen})
    v.emplace_back("sfc_" + f->name(), f);
  if (o_.sf_sfclay_physics == 2 || o_.bl_pbl_physics == 2) {
    for (Field2* f : {&thz0, &uz0, &vz0, &akhs, &akms, &ct, &tshltr, &th10, &qshltr, &q10, &pshltr, &u10e, &v10e, &mixht})
      v.emplace_back("sfc_" + f->name(), f);
  }
  if (o_.sf_sfclay_physics == 5) v.emplace_back("sfc_cqs", &cqs);
  if (o_.bl_pbl_physics == 5)
    for (Field2* f : {&maxwidth, &maxmf, &ztop_plume, &excess_h, &excess_q}) v.emplace_back("sfc_" + f->name(), f);
  if (o_.fractional_seaice == 1 || o_.sst_update == 1) {
    v.emplace_back("sfc_sst", &sst);
    v.emplace_back("sfc_tsk_save", &tsk_save);
  }
  if (o_.sst_update == 1) v.emplace_back("sfc_xicem", &xicem);
  if (o_.sst_skin == 1) {
    if (o_.fractional_seaice != 1 && o_.sst_update != 1) v.emplace_back("sfc_sst", &sst);
    v.emplace_back("sfc_sstsk", &sstsk);
    v.emplace_back("sfc_dtw", &dtw);
  }
  if (o_.tmn_update == 1)
    for (Field2* f : {&tyr, &tyra, &tdly}) v.emplace_back("sfc_" + f->name(), f);
  if (o_.sf_surface_physics == 1) {  // THC and CAPG are restart fields (phy_init does not run landuse_init then)
    v.emplace_back("sfc_thc", &thc);
    v.emplace_back("sfc_capg", &capg);
  }
  if (rad_)  // radiation diagnostics and their accumulations
    for (Field2* f : {&lwcf, &swcf, &lwupt, &lwuptc, &lwdnt, &lwdntc, &lwupb, &lwupbc, &lwdnb, &lwdnbc, &olr, &swupt, &swuptc, &swdnt, &swdntc, &swupb, &swupbc, &swdnb, &swdnbc, &swvisdir, &swvisdif, &swnirdir, &swnirdif, &swddir, &swddni, &swddif, &swddirc, &swddnic, &diffuse_frac, &aclwupt, &aclwuptc, &aclwdnt, &aclwdntc, &aclwupb, &aclwupbc, &aclwdnb, &aclwdnbc, &acswupt, &acswuptc, &acswdnt, &acswdntc, &acswupb, &acswupbc, &acswdnb, &acswdnbc})
      v.emplace_back("sfc_" + f->name(), f);
  if (o_.prec_acc_opt)
    for (Field2* f : {&prec_acc_c, &prec_acc_nc, &snow_acc_nc}) v.emplace_back("sfc_" + f->name(), f);
  for (Field2* f : clwrf_) v.emplace_back("sfc_" + f->name(), f);  // output_diagnostics (Registry rh3)
  if (o_.fdda.grid_fdda == 1)  // fdda2d members (Registry i{10}r)
    for (Field2* f : {&mu_ndg_old, &mu_ndg_new}) v.emplace_back("sfc_" + f->name(), f);
  if (o_.sf_surface_physics == 4) {
    for (Field2* f : {&xlat_sfc, &xlong_sfc, &tvxy, &tgxy, &canicexy, &canliqxy, &eahxy, &tahxy, &cmxy, &chxy,
                      &fwetxy, &sneqvoxy, &alboldxy, &qsnowxy, &qrainxy, &wslakexy, &zwtxy, &waxy, &wtxy, &lfmassxy,
                      &rtmassxy, &stmassxy, &woodxy, &stblcpxy, &fastcpxy, &xsaixy, &taussxy, &smcwtdxy, &deeprechxy,
                      &rechxy, &grainxy, &gddxy, &qtdrain, &t2mvxy, &t2mbxy, &q2mvxy, &q2mbxy, &tradxy, &neexy,
                      &gppxy, &nppxy, &fvegxy, &runsfxy, &runsbxy, &ecanxy, &edirxy, &etranxy, &fsaxy, &firaxy,
                      &aparxy, &psnxy, &savxy, &sagxy, &rssunxy, &rsshaxy, &bgapxy, &wgapxy, &tgvxy, &tgbxy, &chvxy,
                      &chbxy, &shgxy, &shcxy, &shbxy, &evgxy, &evbxy, &ghvxy, &ghbxy, &irgxy, &ircxy, &irbxy, &trxy,
                      &evcxy, &chleafxy, &chucxy, &chv2xy, &chb2xy, &chstarxy, &rs, &acc_ssoilxy, &acc_qinsurxy,
                      &acc_qsevaxy, &eflxbxy, &acc_dwaterxy, &acc_prcpxy, &acc_ecanxy, &acc_etranxy, &acc_edirxy, &acc_glaflwxy})
      v.emplace_back("sfc_" + f->name(), f);
  }
  return v;
}

std::vector<std::pair<std::string, Field3*>> PhysicsSuite::carried3() {
  std::vector<std::pair<std::string, Field3*>> v;
  for (Field3* f : {&tslb, &smois, &sh2o, &smcrel, &exch_h, &exch_m, &pt.rthraten, &pt.rublten, &pt.rvblten,
                    &pt.rthblten, &pt.rqvblten, &pt.rqcblten, &pt.rqiblten, &t1_lag_, &w0avg, &cldfra_dp, &cldfra_sh,
                    &qc_cu, &qi_cu, &gd_cloud, &gd_cloud2, &gd_cloud_a, &gd_cloud2_a, &gd_cldfr,
                    &pt.rucuten, &pt.rvcuten, &pt.rthcuten, &pt.rqvcuten, &pt.rqccuten, &pt.rqrcuten,
                    &pt.rqicuten, &pt.rqscuten})
    v.emplace_back("sfc_" + f->name(), f);
  if (o_.tmn_update == 1) v.emplace_back("sfc_tlag", &tlag);
  if (o_.sf_sfclay_physics == 2 || o_.bl_pbl_physics == 2) {
    v.emplace_back("sfc_tke_pbl", &tke_pbl);
    v.emplace_back("sfc_el_pbl", &el_pbl);
  }
  if (o_.bl_pbl_physics == 5) {
    for (Field3* f : {&qke, &tsq, &qsq, &cov, &sh3d, &sm3d, &qc_bl, &qi_bl, &cldfra_bl})
      v.emplace_back("sfc_" + f->name(), f);
    if (o_.sf_sfclay_physics != 2) v.emplace_back("sfc_el_pbl", &el_pbl);  // with MYJSFC: carried above
    if (o_.bl_mynn_output > 0)
      for (Field3* f : {&edmf_a, &edmf_w, &edmf_thl, &edmf_qt, &edmf_ent, &edmf_qc})
        v.emplace_back("sfc_" + f->name(), f);
    if (o_.tke_budget == 1)
      for (Field3* f : {&qshear, &qbuoy, &qdiss, &qwt, &dqke}) v.emplace_back("sfc_" + f->name(), f);
  }
  if (o_.sf_surface_physics == 4) {
    for (Field3* f : {&tsnoxy, &snicexy, &snliqxy, &zsnsoxy, &albsoildirxy, &albsoildifxy, &smoiseq, &acc_etranixy})
      v.emplace_back("sfc_" + f->name(), f);
  }
  if (rad_) {
    v.emplace_back("sfc_cldfra", &cldfra);
    v.emplace_back("sfc_rthratenlw", &rthratenlw);
    v.emplace_back("sfc_rthratensw", &rthratensw);
    v.emplace_back("sfc_rthratenlwc", &rthratenlwc);
    v.emplace_back("sfc_rthratenswc", &rthratenswc);
  }
  if (o_.cu_physics == 16 || o_.cu_physics == 3) {
    v.emplace_back("sfc_rthften", &pt.rthften);
    v.emplace_back("sfc_rqvften", &pt.rqvften);
  }
  if (o_.cu_physics == 6) v.emplace_back("sfc_rqvften", &pt.rqvften);  // read by the next step's cu_tiedtke
  if (o_.fdda.grid_fdda == 1)  // package psufddagd: the analyses (i{10}r), the tendencies (r) and HFX_FDDA (rh)
    for (Field3* f : {&u_ndg_old, &v_ndg_old, &t_ndg_old, &q_ndg_old, &ph_ndg_old, &u_ndg_new, &v_ndg_new, &t_ndg_new,
                      &q_ndg_new, &ph_ndg_new, &hfx_fdda, &pt.rundgdten, &pt.rvndgdten, &pt.rthndgdten, &pt.rqvndgdten})
      v.emplace_back("sfc_" + f->name(), f);
  for (Field3* f : {re_cloud_, re_ice_, re_snow_})
    if (f) v.emplace_back("sfc_" + f->name(), f);
  return v;
}

std::vector<std::pair<std::string, IntField2*>> PhysicsSuite::carried_int() {
  std::vector<std::pair<std::string, IntField2*>> v = {{"sfc_ivgtyp", &ivgtyp}, {"sfc_isltyp", &isltyp}, {"sfc_kpbl", &kpbl}};
  if (o_.sf_sfclay_physics == 2 || o_.bl_pbl_physics == 2) v.emplace_back("sfc_lowlyr", &lowlyr);
  if (o_.sf_surface_physics == 4) {
    v.emplace_back("sfc_isnowxy", &isnowxy);
    v.emplace_back("sfc_cropcat", &cropcat);
    v.emplace_back("sfc_pgsxy", &pgsxy);
  }
  if (o_.bucket_mm > 0) {
    v.emplace_back("sfc_i_rainc", &i_rainc);
    v.emplace_back("sfc_i_rainnc", &i_rainnc);
  }
  if (o_.bucket_j > 0)
    for (IntField2& f : i_acrad) v.emplace_back("sfc_" + f.name(), &f);
  return v;
}

void PhysicsSuite::set_dt(double dt) {
  g_.dt = dt;
  gs_.dt = dt;
}

void PhysicsSuite::part1(dyn::State& s, const dyn::BaseState& b, dyn::Tendencies&) {
  ++itimestep;  // solve_em: grid%itimestep = grid%itimestep + 1
  if (rainncv_mp_) rainncv.copy_from(*rainncv_mp_);  // the microphysics' grid%rainncv and grid%sr
  if (sr_mp_) sr.copy_from(*sr_mp_);
  run_phy_prep(s, b, prep, PhyPrepParams{o_.use_theta_m});
  if (rad_) {  // radiation_driver: xtime (minutes) and julian of the step start
    // WRF's clock (grid%xtime = minutesSinceSimulationStart, grid%julian = currentDayOfYearReal)
    const double xtime = clock_xtime();
    const double julian = wrf_julian(o_.rad.julyr, o_.rad.julday, o_.rad.gmt, clock_since_start());
    // YR: first_rk_step_part1's WRFU_TimeGet(currentTime, YY=yr), a new year after 31 December
    const int yr = wrf_year(o_.rad.julyr, o_.rad.julday, o_.rad.gmt, clock_since_start());
    auto q = [&](int n) -> const Field3* { return n >= 0 ? &s.q_2[n] : nullptr; };
    RadiationInputs ri{&prep.t_phy, &prep.p_hyd, &prep.p_hyd_w, &prep.pi_phy, &prep.rho, &prep.dz8w,
                       &prep.t8w, &s.q_2[s.P_QV], q(s.P_QC), q(s.P_QI), q(s.P_QS), re_cloud_, re_ice_,
                       re_snow_, &tsk, &albedo, &emiss, &xland, &xice, &snow};
    ri.qr = q(s.P_QR);  // Dudhia SW
    ri.qg = q(s.P_QG);
    ri.ht = &b.ht;
    // check_a_mundo: icloud_bl = 1 needs the MYNN PBL (reset to 0 otherwise)
    if (o_.icloud_bl == 1 && o_.bl_pbl_physics == 5) {
      ri.cldfra_bl = &cldfra_bl;
      ri.qc_bl = &qc_bl;
      ri.qi_bl = &qi_bl;
    }
    if (o_.rad.icloud_cu != 0) {  // cu_rad_feedback
      ri.qc_cu = &qc_cu;
      ri.qi_cu = &qi_cu;
      ri.cldfra_dp = &cldfra_dp;
      ri.cldfra_sh = &cldfra_sh;
    }
    RadiationOutputs ro{&pt.rthraten, &glw, &gsw, &swdown, &coszen, &cldfra, &rthratenlw, &rthratensw,
                        &rthratenlwc, &rthratenswc, &o3rad, &lwcf, &swcf, &hrang,
                        {&lwupt, &lwuptc, &lwdnt, &lwdntc, &lwupb, &lwupbc, &lwdnb, &lwdnbc, &olr}, {&swupt, &swuptc, &swdnt, &swdntc, &swupb, &swupbc, &swdnb, &swdnbc},
                        {&swvisdir, &swvisdif, &swnirdir, &swnirdif, &swddir, &swddni, &swddif, &swddirc, &swddnic, &diffuse_frac}};
    rad_->run(itimestep, xtime, julian, yr, ri, ro, adapt_step_flag, wrf_time::real_time<real>(elapsed), &radtacttime);
    vmdump::dump("vm_rad", 1, {&rthratenlw, &rthratensw, &cldfra}, {&glw, &gsw, &swdown, &coszen, &lwupb, &swupb, &olr});
  }
  if (rad_) {  // radiation_driver: accumulated fluxes, every step (DTaccum = DT)
    const real dt = real(g_.dt);
    const Range3D cols{0, g_.nx, 0, g_.ny, 0, 1};
    LaunchBatch<KAccum2, 16> acc;  // 16 independent sums, one launch
    for (auto [ac, x] : std::initializer_list<std::pair<Field2*, const Field2*>>{{&aclwupt, &lwupt}, {&aclwuptc, &lwuptc}, {&aclwdnt, &lwdnt}, {&aclwdntc, &lwdntc}, {&aclwupb, &lwupb}, {&aclwupbc, &lwupbc}, {&aclwdnb, &lwdnb}, {&aclwdnbc, &lwdnbc}, {&acswupt, &swupt}, {&acswuptc, &swuptc}, {&acswdnt, &swdnt}, {&acswdntc, &swdntc}, {&acswupb, &swupb}, {&acswupbc, &swupbc}, {&acswdnb, &swdnb}, {&acswdnbc, &swdnbc}}) {
      if constexpr (kFuseMulAdd) acc.add(cols, KAccum2{ac->view(), x->cview(), dt});
      else column_for(Range2D{0, g_.nx, 0, g_.ny}, KAccum2{ac->view(), x->cview(), dt});  // CUDA FP32: as before
    }
    acc.run();
  }
  vmdump::dump("vm_phy_prep", 1,
               {&prep.th_phy, &prep.pi_phy, &prep.t_phy, &prep.p_hyd, &prep.p_hyd_w, &prep.p8w, &prep.t8w, &prep.rho,
                &prep.dz8w, &prep.z, &prep.u_phy, &prep.v_phy, &prep.p_phy});
  surface_driver(s, b);
  vmdump::dump("vm_surface", 1, {},
               {&hfx, &qfx, &ust, &znt, &mol, &qsfc, &tsk, &flhc, &flqc, &br, &psim, &psih, &wspd, &u10, &v10, &t2,
                &th2, &q2, &lh, &grdflx, &pblh, &regime, &zol, &fm, &fh, &rmol, &canwat});
  pbl_driver(s, b);
  vmdump::dump("vm_pbl", 1, {&pt.rublten, &pt.rvblten, &pt.rthblten, &pt.rqvblten, &exch_h}, {&pblh});
  cumulus_driver(s, b);
  if (o_.cu_physics == 3) convtrans_prep(s);
  fddagd_driver(s, b);
}

void PhysicsSuite::part2(const dyn::State& s, const dyn::BaseState& b, dyn::Tendencies& t) {
  const CouplingFlags f{radiation_on(), o_.bl_pbl_physics > 0, o_.cu_physics, o_.use_theta_m == 1, o_.fdda.grid_fdda};
  calculate_phy_tend(pt, s, b, g_, f);
  update_phy_ten(t, pt, s, g_, f);
  if (o_.use_theta_m == 1) {
    vmdump::dump("vm_conv_in", 0, {&t.t_tendf, &t.q_tendf[s.P_QV], wrf_t1_lag && t1_lag_set_ ? &t1_lag_ : &s.t_1,
                                   &s.q_1[s.P_QV]});
    if (!wrf_t1_lag) {
      conv_t_tendf_to_moist(t, s.t_1, s, g_);
    } else {  // grid%t_1 lags one step behind the dycore's t_1 here (see conv_t_tendf_to_moist)
      if (!t1_lag_set_) t1_lag_.copy_from(s.t_1);
      conv_t_tendf_to_moist(t, t1_lag_, s, g_);
      t1_lag_.copy_from(s.t_1);
      t1_lag_set_ = true;
    }
    vmdump::dump("vm_conv_out", 0, {&t.t_tendf});
  }
}

void PhysicsSuite::after_rk(const dyn::State& s, const dyn::BaseState& b) {
  advance_ppt(s);
  phy_prep_part2(pt, s, b, g_,
                 CouplingFlags{radiation_on(), o_.bl_pbl_physics > 0, o_.cu_physics, o_.use_theta_m == 1, o_.fdda.grid_fdda});
}

// module_after_all_rk_steps.F -> diagnostics_driver -> diagnostic_output_calc, then clwrf_output_calc, at the end of
// the step with solve_em's curr_secs2 (seconds of the step start since this run's start) and xtime of the step start
void PhysicsSuite::after_all_rk_steps() {
  const bool prec = o_.prec_acc_dt > 0;
  if (!(o_.bucket_mm > 0) && !prec && o_.output_diagnostics != 1) return;
  const real curr_secs2 = wrf_time::real_time<real>(clock_since_run_start());  // solve_em: real_time(tmpTimeInterval2)
  const bool xtime0 = adapt_step_flag ? elapsed == wrf_time::Interval{} : itimestep == 1;
  KDiagOutputCalc k{};
  k.bucket = o_.bucket_mm > 0 && std::lround(curr_secs2) % 3600 == 0;
  k.bucket_j_on = o_.bucket_j > 0;
  k.xtime0 = xtime0;
  k.bucket_mm = real(o_.bucket_mm);
  k.bucket_j = real(o_.bucket_j);
  k.rainc = rainc.view();
  if (rainnc_mp_) k.rainnc = rainnc_mp_->view();
  if (o_.bucket_mm > 0) {
    k.i_rainc = i_rainc.view();
    k.i_rainnc = i_rainnc.view();
  }
  if (o_.bucket_j > 0) {
    const std::array<Field2*, 16> ac = acrad();
    for (int n = 0; n < 16; ++n) {
      k.ac[n] = ac[std::size_t(n)]->view();
      k.i_ac[n] = i_acrad[std::size_t(n)].view();
    }
  }
  k.prec_acc = prec;
  if (prec) {
    k.prec_reset = std::fmod(curr_secs2, real(60.) * real(o_.prec_acc_dt)) == real(0.);
    k.raincv = raincv.cview();
    if (rainncv_mp_) k.rainncv = rainncv_mp_->cview();
    if (snowncv_mp_) k.snowncv = snowncv_mp_->cview();
    k.t2 = t2.cview();
    k.prec_acc_c = prec_acc_c.view();
    k.prec_acc_nc = prec_acc_nc.view();
    k.snow_acc_nc = snow_acc_nc.view();
  }
  if (k.bucket || prec) column_for(g_.columns(), k);
  if (o_.output_diagnostics != 1) return;
  // clwrf_output_calc (module_diagnostics_driver.F:769-834); xtime = minutesSinceSimulationStart of the step start
  const real dt = real(g_.dt);
  const real xtime = wrf_time::minutes<real>(clock_since_start());
  const long per = std::lround(real(o_.auxhist3_interval) * real(60.) / dt);  // NINT(clwrfH*60./dt)
  KClwrfOutputCalc c{};
  c.reinit = std::lround(curr_secs2 / dt) % per == 0;
  if (c.reinit) {
    nsteps = 1;
  } else {
    nsteps = nsteps + 1;
    c.finish = std::lround((curr_secs2 + dt) / dt) % per == 0;
  }
  c.dt = dt;
  c.tt = xtime + dt / real(60.);
  c.nsteps = real(nsteps);
  c.t2 = t2.cview(); c.q2 = q2.cview(); c.u10 = u10.cview(); c.v10 = v10.cview(); c.skintemp = tsk.cview();
  c.raincv = raincv.cview();
  if (rainncv_mp_) c.rainncv = rainncv_mp_->cview();
  c.t2min = t2min.view(); c.t2max = t2max.view(); c.tt2min = tt2min.view(); c.tt2max = tt2max.view();
  c.t2mean = t2mean.view(); c.t2std = t2std.view(); c.q2min = q2min.view(); c.q2max = q2max.view();
  c.tq2min = tq2min.view(); c.tq2max = tq2max.view(); c.q2mean = q2mean.view(); c.q2std = q2std.view();
  c.skintempmin = skintempmin.view(); c.skintempmax = skintempmax.view(); c.tskintempmin = tskintempmin.view();
  c.tskintempmax = tskintempmax.view(); c.skintempmean = skintempmean.view(); c.skintempstd = skintempstd.view();
  c.u10max = u10max.view(); c.v10max = v10max.view(); c.spduv10max = spduv10max.view();
  c.tspduv10max = tspduv10max.view(); c.u10mean = u10mean.view(); c.v10mean = v10mean.view();
  c.spduv10mean = spduv10mean.view(); c.u10std = u10std.view(); c.v10std = v10std.view();
  c.spduv10std = spduv10std.view(); c.raincvmax = raincvmax.view(); c.rainncvmax = rainncvmax.view();
  c.traincvmax = traincvmax.view(); c.trainncvmax = trainncvmax.view(); c.raincvmean = raincvmean.view();
  c.rainncvmean = rainncvmean.view(); c.raincvstd = raincvstd.view(); c.rainncvstd = rainncvstd.view();
  column_for(g_.columns(), c);
}

std::vector<const Field2*> PhysicsSuite::fields2() const {
  std::vector<const Field2*> v = {&lwcf, &swcf, &hrang, &uratx, &vratx, &tratx, &ra, &rs, &shall, &lwupt, &lwuptc, &lwdnt, &lwdntc, &lwupb, &lwupbc, &lwdnb, &lwdnbc, &swupt, &swuptc, &swdnt, &swdntc, &swupb, &swupbc, &swdnb, &swdnbc, &swvisdir, &swvisdif, &swnirdir, &swnirdif, &swddir, &swddni, &swddif, &swddirc, &swddnic, &diffuse_frac, &aclwupt, &aclwuptc, &aclwdnt, &aclwdntc, &aclwupb, &aclwupbc, &aclwdnb, &aclwdnbc, &acswupt, &acswuptc, &acswdnt, &acswdntc, &acswupb, &acswupbc, &acswdnb, &acswdnbc, &olr, &tsk, &xland, &xice, &lakemask, &water_depth, &mavail, &tmn, &vegfra, &shdmin, &shdmax, &snoalb, &albbck, &albedo, &emiss, &embck, &znt, &z0, &ust, &ustm, &mol, &rmol, &pblh, &hfx, &qfx, &lh, &grdflx, &qsfc, &flhc, &flqc, &wspd, &br, &fm, &fh, &zol, &regime, &u10, &v10, &t2, &th2, &q2, &psfc, &ch, &snow, &snowh, &snowc, &canwat, &lai, &snotime, &qz0, &rainbl, &raincv, &raincv_a, &raincv_b, &rainncv, &rainshv, &rainc, &rainsh, &pratec, &pratesh, &nca, &htop, &hbot, &cutop, &cubot, &cuppt, &sr, &glw, &swdown, &gsw, &smstav, &smstot, &sfcrunoff, &udrunoff, &acsnom, &acsnow, &snopcx, &potevp, &noahres, &sfcevp, &sfcexc, &achfx, &aclhf, &acgrdflx, &dx2d, &var2d, &uoce, &voce, &ctopo, &ctopo2, &ck, &cka, &cd, &cda, &wstar, &delta, &hol, &thz0, &uz0, &vz0, &akhs, &akms, &ct, &tshltr, &th10, &qshltr, &q10, &pshltr, &u10e, &v10e, &mixht};
  if (o_.sf_surface_physics == 4) {
    v.insert(v.end(), {&xlat_sfc, &xlong_sfc, &tvxy, &tgxy, &canicexy, &canliqxy, &eahxy, &tahxy, &cmxy, &chxy,
                       &fwetxy, &sneqvoxy, &alboldxy, &qsnowxy, &qrainxy, &wslakexy, &zwtxy, &waxy, &wtxy, &lfmassxy,
                       &rtmassxy, &stmassxy, &woodxy, &stblcpxy, &fastcpxy, &xsaixy, &taussxy, &smcwtdxy, &deeprechxy,
                       &rechxy, &grainxy, &gddxy, &qtdrain, &t2mvxy, &t2mbxy, &q2mvxy, &q2mbxy, &tradxy, &neexy,
                       &gppxy, &nppxy, &fvegxy, &runsfxy, &runsbxy, &ecanxy, &edirxy, &etranxy, &fsaxy, &firaxy,
                       &aparxy, &psnxy, &savxy, &sagxy, &rssunxy, &rsshaxy, &bgapxy, &wgapxy, &tgvxy, &tgbxy, &chvxy,
                       &chbxy, &shgxy, &shcxy, &shbxy, &evgxy, &evbxy, &ghvxy, &ghbxy, &irgxy, &ircxy, &irbxy, &trxy,
                       &evcxy, &chleafxy, &chucxy, &chv2xy, &chb2xy, &chstarxy, &acc_ssoilxy, &acc_qinsurxy,
                       &acc_qsevaxy, &eflxbxy, &acc_dwaterxy, &acc_prcpxy, &acc_ecanxy, &acc_etranxy, &acc_edirxy, &acc_glaflwxy});
  }
  if (o_.gwd_opt == 1) v.insert(v.end(), {&dusfcg, &dvsfcg});
  if (o_.sf_sfclay_physics == 5) v.push_back(&cqs);
  if (o_.bl_pbl_physics == 5 && o_.mynn.edmf > 0)  // package mynn_dmp_edmf1
    v.insert(v.end(), {&maxwidth, &maxmf, &ztop_plume, &excess_h, &excess_q});
  if (o_.fractional_seaice == 1 || o_.sst_update == 1) v.insert(v.end(), {&sst, &tsk_save});
  if (o_.sst_update == 1) v.push_back(&xicem);
  if (o_.sst_skin == 1) {
    if (o_.fractional_seaice != 1 && o_.sst_update != 1) v.push_back(&sst);
    v.insert(v.end(), {&sstsk, &dtw});
  }
  if (o_.tmn_update == 1) v.insert(v.end(), {&tyr, &tyra, &tdly});
  if (o_.prec_acc_opt) v.insert(v.end(), {&prec_acc_c, &prec_acc_nc, &snow_acc_nc});
  v.insert(v.end(), clwrf_.begin(), clwrf_.end());
  if (o_.sf_surface_physics == 1) v.push_back(&capg);  // THC: phy_init's landuse_init value (WrfHistory)
  if (o_.fdda.grid_fdda == 1) v.insert(v.end(), {&mu_ndg_old, &mu_ndg_new});
  return v;
}

std::vector<const Field3*> PhysicsSuite::fields3() const {
  std::vector<const Field3*> v = {&rthratenlw, &rthratensw, &rthratenlwc, &rthratenswc, &o3rad, &tslb, &smois, &sh2o, &smcrel, &exch_h, &exch_m, &tke_pbl, &el_pbl, &w0avg, &cldfra_dp, &cldfra_sh, &qc_cu, &qi_cu, &gd_cloud, &gd_cloud2, &gd_cloud_a, &gd_cloud2_a, &gd_cldfr, &pt.rthraten, &pt.rublten, &pt.rvblten, &pt.rthblten, &pt.rqvblten, &pt.rqcblten, &pt.rqiblten, &pt.rucuten, &pt.rvcuten, &pt.rthcuten, &pt.rqvcuten, &pt.rqccuten, &pt.rqrcuten, &pt.rqicuten, &pt.rqscuten, &pt.rthften, &pt.rqvften, &prep.th_phy, &prep.th_phy_m_t0, &prep.p_phy, &prep.pi_phy, &prep.t_phy, &prep.rho, &prep.u_phy, &prep.v_phy, &prep.z, &prep.p_hyd, &prep.z_at_w, &prep.dz8w, &prep.p8w, &prep.t8w, &prep.p_hyd_w};
  if (o_.sf_surface_physics == 4) {
    v.insert(v.end(), {&tsnoxy, &snicexy, &snliqxy, &zsnsoxy, &albsoildirxy, &albsoildifxy, &smoiseq, &acc_etranixy});
  }
  if (o_.gwd_opt == 1) v.insert(v.end(), {&dtaux3d, &dtauy3d});
  if (o_.tmn_update == 1) v.push_back(&tlag);
  if (o_.bl_pbl_physics == 5) {
    v.insert(v.end(), {&qke, &tsq, &qsq, &cov, &sh3d, &sm3d, &qc_bl, &qi_bl, &cldfra_bl});
    if (o_.bl_mynn_output > 0) v.insert(v.end(), {&edmf_a, &edmf_w, &edmf_thl, &edmf_qt, &edmf_ent, &edmf_qc});
    if (o_.tke_budget == 1) v.insert(v.end(), {&qshear, &qbuoy, &qdiss, &qwt, &dqke});
  }
  if (o_.fdda.grid_fdda == 1)
    v.insert(v.end(), {&u_ndg_old, &v_ndg_old, &t_ndg_old, &q_ndg_old, &ph_ndg_old, &u_ndg_new, &v_ndg_new, &t_ndg_new,
                       &q_ndg_new, &ph_ndg_new, &hfx_fdda, &pt.rundgdten, &pt.rvndgdten, &pt.rthndgdten, &pt.rqvndgdten});
  return v;
}

}  // namespace cppwrf::phys::driver
