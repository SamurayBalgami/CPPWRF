// SPDX-License-Identifier: GPL-3.0-or-later
#include "cases/domain_runner.hpp"
#include "core/tiles.hpp"

#include <cmath>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <stdexcept>

#ifdef CPPWRF_HAVE_NETCDF
#include <netcdf.h>
#endif

#include <algorithm>
#include <cctype>
#include <map>
#include <type_traits>

#include "cases/config_keys.hpp"
#include "core/constants.hpp"
#include "core/halo.hpp"
#include "core/precision.hpp"
#include "dyn/diagnostics.hpp"
#include "wrf_io/global_atts.hpp"

namespace cppwrf::cases {

namespace {

const char* bc_name(BC b) {
  return b == BC::Periodic ? "periodic" : (b == BC::Symmetric ? "symmetric" : "specified");
}

#ifdef CPPWRF_HAVE_NETCDF
// A WRF restart file (wrfrst_d0N): FLAG_RESTART and WRF's Times variable (CPPWRF's own restart files
// have FLAG_RESTART without Times)
bool is_wrfrst(const std::string& path) {
  int id;
  if (nc_open(path.c_str(), NC_NOWRITE, &id) != NC_NOERR) return false;
  int flag = 0, vid;
  const bool r = nc_get_att_int(id, NC_GLOBAL, "FLAG_RESTART", &flag) == NC_NOERR &&
                 nc_inq_varid(id, "Times", &vid) == NC_NOERR;
  nc_close(id);
  return r;
}

// WRF alarm a of a restart file (output_wrf's WRF_ALARM_ISRINGING_a, WRF_ALARM_SECS_TIL_NEXT_RING_a):
// {ringing, seconds to the next ring}; seconds -1 when the file has no such alarm
// a scalar variable of a WRF restart file (Time = 0); 0 when the file has none
double wrf_scalar(const std::string& path, const char* name) {
  int id, vid;
  double v = 0;
  if (nc_open(path.c_str(), NC_NOWRITE, &id) != NC_NOERR) throw std::runtime_error("cannot open " + path);
  if (nc_inq_varid(id, name, &vid) == NC_NOERR) nc_get_var_double(id, vid, &v);
  nc_close(id);
  return v;
}

std::pair<int, long> wrf_alarm(const std::string& path, int a) {
  std::pair<int, long> r{0, -1};
  int id, v;
  if (nc_open(path.c_str(), NC_NOWRITE, &id) != NC_NOERR) return r;
  char n1[40], n2[40];
  std::snprintf(n1, sizeof n1, "WRF_ALARM_ISRINGING_%02d", a);
  std::snprintf(n2, sizeof n2, "WRF_ALARM_SECS_TIL_NEXT_RING_%02d", a);
  if (nc_get_att_int(id, NC_GLOBAL, n1, &v) == NC_NOERR) r.first = v;
  if (nc_get_att_int(id, NC_GLOBAL, n2, &v) == NC_NOERR) r.second = v;
  nc_close(id);
  return r;
}

// The WRF variable of a restart field (names of save_restart_file)
std::vector<std::string> wrf_names(const std::string& n) {
  auto up = [](std::string x) {
    std::transform(x.begin(), x.end(), x.begin(), [](unsigned char c) { return char(std::toupper(c)); });
    return x;
  };
  static const std::map<std::string, std::string> moist = {
      {"qv", "QVAPOR"}, {"qc", "QCLOUD"}, {"qr", "QRAIN"}, {"qi", "QICE"}, {"qs", "QSNOW"},
      {"qg", "QGRAUP"}, {"qni", "QNICE"}, {"qnr", "QNRAIN"}, {"qke_adv", "qke_adv"},
      {"qnc", "QNCLOUD"}, {"qnwfa", "QNWFA"}, {"qnifa", "QNIFA"}, {"qnbca", "QNBCA"}, {"qns", "QNSNOW"},
      {"qng", "QNGRAUPEL"}};
  if (n.rfind("q1_", 0) == 0 || n.rfind("q2_", 0) == 0) {  // moist/scalar arrays have one time level (q_1 = q_2
    const std::string q = n.substr(3);                      // at the step start); tke_1 / tke_2
    auto it = moist.find(q);
    if (it != moist.end()) return {it->second};
    return {up(q) + (n[1] == '1' ? "_1" : "_2"), up(q)};
  }
  static const std::map<std::string, std::string> renamed = {
      {"t_1", "THM_1"}, {"t_2", "THM_2"}, {"sfc_t1_lag", "THM_1"},  // grid%t_1 of first_rk_step_part2
      {"sfc_xice", "SEAICE"}, {"sfc_sfcrunoff", "SFROFF"}, {"sfc_udrunoff", "UDROFF"},
      {"sfc_xlat_sfc", "XLAT"}, {"sfc_xlong_sfc", "XLONG"}, {"sfc_rthratenlw", "RTHRATLW"},
      {"sfc_rthratensw", "RTHRATSW"}, {"sfc_rthratenlwc", "RTHRATLWC"}, {"sfc_rthratenswc", "RTHRATSWC"},
      {"sfc_t2mvxy", "T2V"}, {"sfc_t2mbxy", "T2B"}, {"sfc_q2mvxy", "Q2V"}, {"sfc_q2mbxy", "Q2B"}};
  auto r = renamed.find(n);
  if (r != renamed.end()) return {r->second};
  if (n.rfind("sfc_", 0) == 0) {
    const std::string u = up(n.substr(4));
    if (u.size() > 2 && u.compare(u.size() - 2, 2, "XY") == 0) return {u, u.substr(0, u.size() - 2)};
    return {u};
  }
  return {up(n)};
}

// Restart fields from a WRF wrfrst file (Time = 0); WRF's kms:kme arrays give their first nz levels
void read_wrfrst(const std::string& path, io_netcdf::RestartMeta& meta, std::vector<io_netcdf::VarView>& vars) {
  int id;
  if (nc_open(path.c_str(), NC_NOWRITE, &id) != NC_NOERR) throw std::runtime_error("cannot open " + path);
  auto dimlen = [&](const char* d) {
    int did;
    std::size_t l = 0;
    if (nc_inq_dimid(id, d, &did) == NC_NOERR) nc_inq_dimlen(id, did, &l);
    return int(l);
  };
  meta.nx = dimlen("west_east"); meta.ny = dimlen("south_north"); meta.nz = dimlen("bottom_top");
  float dt = 0;
  nc_get_att_float(id, NC_GLOBAL, "DT", &dt);
  meta.dt = dt;
  int vid, it = 0;
  if (nc_inq_varid(id, "ITIMESTEP", &vid) == NC_NOERR) nc_get_var_int(id, vid, &it);
  meta.step = it;
  double xt = 0;
  if (nc_inq_varid(id, "XTIME", &vid) == NC_NOERR) nc_get_var_double(id, vid, &xt);
  meta.time_sec = xt * 60.;
  std::vector<std::string> missing;
  std::vector<double> buf;
  for (io_netcdf::VarView& v : vars) {
    int var = -1;
    for (const std::string& wn : wrf_names(v.name))
      if (nc_inq_varid(id, wn.c_str(), &var) == NC_NOERR) break; else var = -1;
    if (var < 0) {  // not in WRF's restart stream: WRF's initial value 0, or what phy_init sets on
      missing.push_back(v.name);  // restarts too (myjsfcinit: LOWLYR = 1), which the model's init has
      if (v.name == "sfc_lowlyr") continue;
      real* d = static_cast<real*>(const_cast<void*>(v.data));
      for (int k = 0; k < std::max(1, v.nz); ++k)
        for (int j = 0; j < v.ny; ++j)
          for (int i = 0; i < v.nx; ++i) d[k * v.sk + j * v.sj + i] = real(0);
      continue;
    }
    int nd;
    nc_inq_varndims(id, var, &nd);
    std::vector<int> dids(static_cast<std::size_t>(nd));
    nc_inq_vardimid(id, var, dids.data());
    std::vector<std::size_t> len(static_cast<std::size_t>(nd));
    for (int d = 0; d < nd; ++d) nc_inq_dimlen(id, dids[std::size_t(d)], &len[std::size_t(d)]);
    // (Time, [k,] j, i); a 2-D field of the fdda2d array (MU_NDG_OLD/NEW): (Time, one_stag = 1, j, i)
    const bool onestag = nd == 4 && len[1] == 1 && v.nz <= 1 && int(len[2]) == v.ny && int(len[3]) == v.nx;
    if (onestag) {
      const std::size_t st4[4] = {0, 0, 0, 0}, ct4[4] = {1, 1, len[2], len[3]};
      buf.resize(len[2] * len[3]);
      if (nc_get_vara_double(id, var, st4, ct4, buf.data()) != NC_NOERR)
        throw std::runtime_error("wrfrst: cannot read " + v.name);
      real* d = static_cast<real*>(const_cast<void*>(v.data));
      for (int j = 0; j < v.ny; ++j)
        for (int i = 0; i < v.nx; ++i) d[j * v.sj + i] = real(buf[std::size_t(j) * std::size_t(v.nx) + std::size_t(i)]);
      continue;
    }
    const bool three = nd == 4;
    if (nd < 3 || int(len[std::size_t(nd - 1)]) != v.nx || int(len[std::size_t(nd - 2)]) != v.ny ||
        (three && int(len[1]) < v.nz) || (!three && v.nz > 1))
      throw std::runtime_error("wrfrst: " + std::string(path) + ": shape of " + v.name + " differs");
    const int nk = three ? v.nz : 1;
    std::vector<std::size_t> st(std::size_t(nd), 0), ct(len);
    ct[0] = 1;
    if (three) ct[1] = std::size_t(nk);
    buf.resize(std::size_t(nk) * std::size_t(v.ny) * std::size_t(v.nx));
    if (nc_get_vara_double(id, var, st.data(), ct.data(), buf.data()) != NC_NOERR)
      throw std::runtime_error("wrfrst: cannot read " + v.name);
    real* d = static_cast<real*>(const_cast<void*>(v.data));
    for (int k = 0; k < nk; ++k)
      for (int j = 0; j < v.ny; ++j)
        for (int i = 0; i < v.nx; ++i)
          d[k * v.sk + j * v.sj + i] = real(buf[(std::size_t(k) * std::size_t(v.ny) + std::size_t(j)) * std::size_t(v.nx) + std::size_t(i)]);
  }
  nc_close(id);
  if (!missing.empty()) {
    std::string m;
    for (const std::string& x : missing) m += " " + x;
    if (tile::writer()) std::fprintf(stderr, "cppwrf: %s: not in the restart stream, start from 0:%s\n", path.c_str(), m.c_str());
  }
}
#endif

#ifdef CPPWRF_HAVE_NETCDF
#ifndef CPPWRF_COMMIT
#define CPPWRF_COMMIT "unknown"
#endif

// The options a CPPWRF restart file records and a resumed run must have as well: every configuration key except the
// run, restart, output and input settings ([run], [restart], [output], [real], time.history_interval_s,
// phys.auxhist3_interval, phys.table_dir), as sorted "section.key = value" lines
std::string restart_options(const io::Config& cfg) {
  static const char* const skip_sections[] = {"run.", "restart.", "output.", "real."};
  static const char* const skip_keys[] = {"time.history_interval_s", "phys.auxhist3_interval", "phys.table_dir"};
  std::string o;
  for (const auto& [k, v] : cfg.entries()) {
    bool skip = false;
    for (const char* p : skip_sections) skip = skip || k.rfind(p, 0) == 0;
    for (const char* p : skip_keys) skip = skip || k == p;
    if (!skip) o += k + " = " + v + "\n";
  }
  return o;
}

std::map<std::string, std::string> option_lines(const std::string& o) {
  std::map<std::string, std::string> m;
  std::istringstream in(o);
  for (std::string line; std::getline(in, line);) {
    const std::size_t eq = line.find(" = ");
    if (eq != std::string::npos) m[line.substr(0, eq)] = line.substr(eq + 3);
  }
  return m;
}

// A CPPWRF restart file must be of this format version, from this commit (unless run.restart_any_commit) and of a run
// with the same options; WRF's wrfrst files are the restart across versions and option changes
void check_native_restart(const std::string& path, const io_netcdf::RestartMeta& f, const io::Config& cfg) {
  if (f.version != io_netcdf::kRestartVersion)
    throw std::runtime_error(path + ": CPPWRF restart format version " + std::to_string(f.version) +
                             (f.version == 0 ? " (none recorded)" : "") + ", this build reads version " +
                             std::to_string(io_netcdf::kRestartVersion) + ": resume from the run's wrfrst file");
  if (f.commit != CPPWRF_COMMIT && !cfg.get_bool("run.restart_any_commit", false))
    throw std::runtime_error(path + ": written by commit " + f.commit + ", this build is " + CPPWRF_COMMIT +
                             ": resume from the run's wrfrst file (or set run.restart_any_commit = true)");
  const std::string mine = restart_options(cfg);
  if (f.options == mine) return;
  const auto a = option_lines(f.options), b = option_lines(mine);
  std::string d;
  for (const auto& [k, v] : a)
    if (!b.count(k) || b.at(k) != v) d += "; " + k + " = " + v + " in the file, " + (b.count(k) ? b.at(k) : "unset") + " here";
  for (const auto& [k, v] : b)
    if (!a.count(k)) d += "; " + k + " = " + v + " here, unset in the file";
  throw std::runtime_error(path + ": written by a run with other options (" + d.substr(2) + ")");
}
#endif

// WRF's timing label of an output file: "Writing <file name> for domain <I8>"
std::string writing(const std::string& path, const std::string& tag) {
  char b[64];
  std::snprintf(b, sizeof b, " for domain %8d", std::stoi(tag.substr(1)));
  return "Writing " + std::filesystem::path(path).filename().string() + b;
}

}  // namespace

DomainRunner::DomainRunner(const io::Config& cfg, cases::Model& m, const std::string& out_dir,
                           std::string domain_tag)
    : cfg_(cfg), m_(m), out_dir_(out_dir), domain_tag_(std::move(domain_tag)) {
  cname_ = cfg_.get_string("run.case");
  out_fmt_ = cfg_.get_string("output.format", "native");
  write_native_ = (out_fmt_ == "native" || out_fmt_ == "both");
  write_wrfout_ = (out_fmt_ == "wrfout" || out_fmt_ == "both");
  if (out_fmt_ != "native" && out_fmt_ != "wrfout" && out_fmt_ != "both") {
    throw std::runtime_error("unknown output.format: '" + out_fmt_ + "' (native|wrfout|both)");
  }
}

DomainRunner::~DomainRunner() = default;

#ifdef CPPWRF_HAVE_NETCDF
void DomainRunner::save_restart_file(const std::string& path, long step, double time_sec) {
  // a decomposed run: the writer's code with the whole fields (tile::Service)
  const tile::Service svc;
  if (svc.served()) return;
  const Grid& g = m_.g;
  dyn::State& st = *m_.st;
  dyn::RK3* rk = m_.rk.get();

  io_netcdf::RestartMeta meta;
  meta.step = step;
  meta.time_sec = time_sec;
  meta.nx = g.nx; meta.ny = g.ny; meta.nz = g.nz;
  meta.dx = g.dx; meta.dy = g.dy; meta.dt = g.dt;
  meta.case_name = cname_;
  meta.date_str = wrf_io::add_seconds(start_date_, std::lround(time_sec));
  meta.commit = CPPWRF_COMMIT;
  meta.options = restart_options(cfg_);

  const io_netcdf::DType dt = sizeof(real) == 8 ? io_netcdf::DType::F64 : io_netcdf::DType::F32;
  std::vector<std::vector<real>> bufs;
  std::vector<io_netcdf::VarView> vars;

  auto add_field3 = [&](const std::string& name, const Field3& f) {
    bufs.emplace_back();
    const Layout L = tile::download_any(f, bufs.back());
    char stag = f.stagger() == Stagger::U ? 'U' : (f.stagger() == Stagger::V ? 'V' : (f.stagger() == Stagger::W ? 'W' : 'M'));
    vars.emplace_back(name, stag, L.nx, L.ny, L.nz, bufs.back().data() + L.offset, dt, L.sj, L.sk);
  };

  auto add_field2 = [&](const std::string& name, const Field2& f) {
    bufs.emplace_back();
    const Layout L = tile::download_any(f, bufs.back());
    vars.emplace_back(name, 'M', L.nx, L.ny, 1, bufs.back().data() + L.offset, dt, L.sj, 0);
  };

  add_field3("u_1", st.u_1); add_field3("u_2", st.u_2);
  add_field3("v_1", st.v_1); add_field3("v_2", st.v_2);
  add_field3("w_1", st.w_1); add_field3("w_2", st.w_2);
  add_field3("t_1", st.t_1); add_field3("t_2", st.t_2);
  add_field3("ph_1", st.ph_1); add_field3("ph_2", st.ph_2);
  add_field2("mu_1", st.mu_1); add_field2("mu_2", st.mu_2);
  add_field3("p", st.p);
  add_field3("al", st.al);

  for (int n = 0; n < st.n_scalars(); ++n) {
    add_field3("q1_" + st.q_names[n], st.q_1[n]);
    add_field3("q2_" + st.q_names[n], st.q_2[n]);
  }
  if (st.n_moist > 0) {
    add_field3("h_diabatic", st.h_diabatic);
  }
  if (rk && rk->physics()) {
    add_field2("rainnc", rk->physics()->rainnc);
    add_field2("rainncv", rk->physics()->rainncv);
    if (rk->physics()->ice_precip()) {
      add_field2("snownc", rk->physics()->snownc);
      add_field2("snowncv", rk->physics()->snowncv);
      add_field2("graupelnc", rk->physics()->graupelnc);
      add_field2("graupelncv", rk->physics()->graupelncv);
      add_field2("sr", rk->physics()->sr);
    }
    if (rk->physics()->params().mp_physics == 28) {  // Registry i01rhdu: in the restart stream
      add_field2("qnwfa2d", rk->physics()->qnwfa2d);
      add_field2("qnifa2d", rk->physics()->qnifa2d);
    }
  }

  if (m_.suite) {  // column physics state (soil, surface, PBL, lagged t_1)
    for (auto& [name, f] : m_.suite->carried2()) add_field2(name, *f);
    for (auto& [name, f] : m_.suite->carried3()) add_field3(name, *f);
    for (auto& [name, f] : m_.suite->carried_int()) {  // integers stored as reals (exact)
      std::vector<int> hi;
      const Layout L = tile::download_any(*f, hi);
      bufs.emplace_back(hi.begin(), hi.end());
      vars.emplace_back(name, 'M', L.nx, L.ny, 1, bufs.back().data() + L.offset, dt, L.sj, 0);
    }
  }

  io_netcdf::write_restart(path, meta, vars);
}

void DomainRunner::load_restart_file(const std::string& path) {
  const Grid& g = m_.g;
  dyn::State& st = *m_.st;
  dyn::RK3* rk = m_.rk.get();

  io_netcdf::RestartMeta meta;
  const io_netcdf::DType dt = sizeof(real) == 8 ? io_netcdf::DType::F64 : io_netcdf::DType::F32;
  std::vector<std::vector<real>> bufs;
  std::vector<io_netcdf::VarView> vars;

  struct Target3 { std::string name; Field3* f; size_t buf_idx; };
  struct Target2 { std::string name; Field2* f; size_t buf_idx; };
  std::vector<Target3> targets3;
  std::vector<Target2> targets2;

  auto reg_field3 = [&](const std::string& name, Field3& f) {
    size_t idx = bufs.size();
    bufs.emplace_back();
    const Layout L = tile::local_whole(f, bufs.back());
    char stag = f.stagger() == Stagger::U ? 'U' : (f.stagger() == Stagger::V ? 'V' : (f.stagger() == Stagger::W ? 'W' : 'M'));
    vars.emplace_back(name, stag, L.nx, L.ny, L.nz, bufs.back().data() + L.offset, dt, L.sj, L.sk);
    targets3.push_back({name, &f, idx});
  };

  auto reg_field2 = [&](const std::string& name, Field2& f) {
    size_t idx = bufs.size();
    bufs.emplace_back();
    const Layout L = tile::local_whole(f, bufs.back());
    vars.emplace_back(name, 'M', L.nx, L.ny, 1, bufs.back().data() + L.offset, dt, L.sj, 0);
    targets2.push_back({name, &f, idx});
  };

  reg_field3("u_1", st.u_1); reg_field3("u_2", st.u_2);
  reg_field3("v_1", st.v_1); reg_field3("v_2", st.v_2);
  reg_field3("w_1", st.w_1); reg_field3("w_2", st.w_2);
  reg_field3("t_1", st.t_1); reg_field3("t_2", st.t_2);
  reg_field3("ph_1", st.ph_1); reg_field3("ph_2", st.ph_2);
  reg_field2("mu_1", st.mu_1); reg_field2("mu_2", st.mu_2);
  reg_field3("p", st.p);
  reg_field3("al", st.al);
  const bool wrf_file = is_wrfrst(path);
  // base-state fields of a WRF restart file (nest feedback changes the parent's)
  struct TargetB { BaseFieldT<3>* f3; BaseFieldT<2>* f2; size_t buf_idx; };
  std::vector<TargetB> targets_b;
  if (wrf_file) {  // WRF's restart stream also carries these diagnostics of the last step
    reg_field3("ww", st.ww);
    reg_field3("ww_m", st.ww_m);
    reg_field3("php", st.php);
    reg_field3("alt", st.alt);
    dyn::BaseState& b = *m_.base;
    auto reg_base = [&](const std::string& name, auto& f, char stag) {
      if (f.uniform()) return;
      size_t idx = bufs.size();
      bufs.emplace_back();
      const Layout L = tile::local_whole(f, bufs.back());
      vars.emplace_back(name, stag, L.nx, L.ny, L.nz, bufs.back().data() + L.offset, dt, L.sj, L.sk);
      if constexpr (std::is_same_v<std::decay_t<decltype(f)>, BaseFieldT<3>>) targets_b.push_back({&f, nullptr, idx});
      else targets_b.push_back({nullptr, &f, idx});
    };
    reg_base("PHB", b.phb, 'W'); reg_base("PB", b.pb, 'M'); reg_base("ALB", b.alb, 'M'); reg_base("T_INIT", b.t_init, 'M');
    reg_base("MUB", b.mub, 'M'); reg_base("HGT", b.ht, 'M');
    if (b.mapped) {
      reg_base("MAPFAC_MX", b.msftx, 'M'); reg_base("MAPFAC_MY", b.msfty, 'M'); reg_base("MAPFAC_UX", b.msfux, 'U');
      reg_base("MAPFAC_UY", b.msfuy, 'U'); reg_base("MAPFAC_VX", b.msfvx, 'V'); reg_base("MAPFAC_VY", b.msfvy, 'V');
      reg_base("MF_VX_INV", b.msfvx_inv, 'V'); reg_base("F", b.f, 'M'); reg_base("E", b.e, 'M');
      reg_base("SINALPHA", b.sina, 'M'); reg_base("COSALPHA", b.cosa, 'M');
    }
  }

  for (int n = 0; n < st.n_scalars(); ++n) {
    reg_field3("q1_" + st.q_names[n], st.q_1[n]);
    reg_field3("q2_" + st.q_names[n], st.q_2[n]);
  }
  if (st.n_moist > 0) {
    reg_field3("h_diabatic", st.h_diabatic);
  }
  if (rk && rk->physics()) {
    reg_field2("rainnc", rk->physics()->rainnc);
    reg_field2("rainncv", rk->physics()->rainncv);
    if (rk->physics()->ice_precip()) {
      reg_field2("snownc", rk->physics()->snownc);
      reg_field2("snowncv", rk->physics()->snowncv);
      reg_field2("graupelnc", rk->physics()->graupelnc);
      reg_field2("graupelncv", rk->physics()->graupelncv);
      reg_field2("sr", rk->physics()->sr);
    }
    if (rk->physics()->params().mp_physics == 28) {
      reg_field2("qnwfa2d", rk->physics()->qnwfa2d);
      reg_field2("qnifa2d", rk->physics()->qnifa2d);
    }
  }

  struct TargetI { phys::driver::IntField2* f; size_t buf_idx; };
  std::vector<TargetI> targets_i;
  if (m_.suite) {
    for (auto& [name, f] : m_.suite->carried2()) reg_field2(name, *f);
    for (auto& [name, f] : m_.suite->carried3()) reg_field3(name, *f);
    for (auto& [name, f] : m_.suite->carried_int()) {
      std::vector<int> hi;
      const Layout L = tile::local_whole(*f, hi);
      size_t idx = bufs.size();
      bufs.emplace_back(hi.begin(), hi.end());
      vars.emplace_back(name, 'M', L.nx, L.ny, 1, bufs.back().data() + L.offset, dt, L.sj, 0);
      targets_i.push_back({f, idx});
    }
  }

  if (m_.suite && m_.suite->options().tmn_update == 1 && !wrf_file)  // NYEAR / NDAY: WRF's restart stream only
    throw std::runtime_error("tmn_update: resume from the wrfrst file of the run, not " + path);
  if (m_.adapt && !wrf_file)  // the adaptive state (LAST_DT_SEC, ...) is in WRF's restart stream only
    throw std::runtime_error("time.adaptive: resume from the wrfrst file of the run, not " + path);
  if (wrf_file) {
    read_wrfrst(path, meta, vars);
    meta.dx = g.dx; meta.dy = g.dy;
  } else {
    check_native_restart(path, io_netcdf::read_restart_meta(path), cfg_);
    io_netcdf::read_restart(path, meta, vars);
  }

  if (meta.nx != g.nx || meta.ny != g.ny || meta.nz != g.nz) {
    throw std::runtime_error("restart file grid dimension mismatch");
  }
  if (!m_.adapt && std::abs(meta.dt - g.dt) > 1e-6 * g.dt) {
    throw std::runtime_error("restart file dt (" + std::to_string(meta.dt) + ") does not match grid dt (" + std::to_string(g.dt) + ")");
  }

  start_step = meta.step;
  if (m_.nsteps < start_step) {
    throw std::runtime_error("run.run_time (" + std::to_string(m_.run_time) + "s / step " + std::to_string(m_.nsteps) +
                             ") is less than restart file step " + std::to_string(start_step));
  }
  if (wrf_file) {
    // input_wrf (restart_only) sets the alarms from the file: an input alarm (auxinput4) keeps its interval and
    // rings next after WRF_ALARM_SECS_TIL_NEXT_RING seconds (share/input_wrf.F:243-279); an output alarm (history)
    // takes those seconds as its interval as well (RingInterval=interval, share/input_wrf.F:301-325); negative
    // values are skipped
    const long hsecs = wrf_alarm(path, 1).second;
    if (m_.adapt) {  // the alarms by time from the restart time (adapt_before_step)
      hist_alarm_t_ = hsecs >= 0 && hsecs < 1700000000;
      if (hist_alarm_t_) hist_iv_t_ = wrf_time::make(hsecs);
      if (hsecs == 0) throw std::runtime_error(path + ": WRF_ALARM_SECS_TIL_NEXT_RING_01 = 0");
    } else if (hsecs >= 1700000000) {
      hist_iv_ = 0;  // a forever interval: no history
    } else if (hsecs >= 0) {
      const double st = double(hsecs) / g.dt;
      if (hsecs == 0 || std::abs(st - std::round(st)) > 1e-9 * st)
        throw std::runtime_error(path + ": WRF_ALARM_SECS_TIL_NEXT_RING_01 = " + std::to_string(hsecs) +
                                 " s (the history interval after the restart) is not a multiple of the time step");
      hist_iv_ = std::lround(st);
      hist_ref_ = start_step;
    }
    if (m_.adapt) {  // the adaptive time step's restart fields (Registry.EM_COMMON:366-374, 410-412, dtbc)
      AdaptTimeStep& a = *m_.adapt;
      a.last_dt_sec = int(wrf_scalar(path, "LAST_DT_SEC"));
      a.last_dt_sec_num = int(wrf_scalar(path, "LAST_DT_SEC_NUM"));
      a.last_dt_sec_den = int(wrf_scalar(path, "LAST_DT_SEC_DEN"));
      a.last_step_updated = int(wrf_scalar(path, "LAST_STEP_UPDATED"));
      a.stepping_to_time = wrf_scalar(path, "STEPPING_TO_TIME") != 0.0;
      if (m_.suite) {
        m_.suite->radtacttime = real(wrf_scalar(path, "RADTACTTIME"));
        m_.suite->bldtacttime = real(wrf_scalar(path, "BLDTACTTIME"));
        m_.suite->cudtacttime = real(wrf_scalar(path, "CUDTACTTIME"));
      }
      if (m_.bc) m_.bc->dtbc = wrf_scalar(path, "DTBC");
      // the resumed clock starts at the restart time of the file's Times (whole seconds)
      m_.sim_offset = wrf_time::make(std::int64_t(std::floor(meta.time_sec + 1e-6)));
      m_.now = wrf_time::Interval{};
    }
    const auto [aring, asecs] = wrf_alarm(path, 30);
    if (asecs >= 0 && asecs < 1700000000) aux4_first_s_ = double(start_step) * g.dt + double(asecs);
    aux4_ring_at_start_ = aring == 1 ? 1 : 0;
    const auto [ring10, secs10] = wrf_alarm(path, 36);  // AUXINPUT10_ALARM (grid_fdda)
    if (secs10 >= 0 && secs10 < 1700000000) aux10_first_s_ = double(start_step) * g.dt + double(secs10);
    aux10_ring_at_start_ = ring10 == 1 ? 1 : 0;
    if (aux3_iv_ > 0) {  // AUXHIST3_ALARM: an output alarm as the history one (share/input_wrf.F:290-325)
      const auto [ring3, secs3] = wrf_alarm(path, 4);
      if (secs3 >= 1700000000) {
        aux3_iv_ = 0;
      } else if (secs3 >= 0) {
        const double st = double(secs3) / g.dt;
        if (secs3 == 0 || std::abs(st - std::round(st)) > 1e-9 * st)
          throw std::runtime_error(path + ": WRF_ALARM_SECS_TIL_NEXT_RING_04 = " + std::to_string(secs3) +
                                   " s (the auxhist3 interval after the restart) is not a multiple of the time step");
        aux3_iv_ = std::lround(st);
        aux3_ref_ = start_step;
      }
      aux3_ring_at_start_ = ring3 == 1 ? 1 : 0;
    }
    if (m_.suite) m_.suite->nsteps = int(wrf_scalar(path, "NSTEPS"));  // grid%nsteps (clwrf_output_calc)
    if (m_.suite && m_.suite->options().tmn_update == 1) {  // tmnupdate's NYEAR and NDAY (Registry r)
      m_.suite->nyear = int(std::lround(wrf_scalar(path, "NYEAR")));
      m_.suite->nday = real(wrf_scalar(path, "NDAY"));
    }
  }

  // a decomposed run: every worker read the file (whole fields) and keeps the points it holds
  auto put = [&](auto& f, std::vector<real>& whole) {
    const std::vector<real> h = tile::local_part(f, whole);
    copy_to_dev(f.data() - f.layout().offset, h.data(), f.layout().total * sizeof(real));
  };
  for (const auto& t : targets3) {
    put(*t.f, bufs[t.buf_idx]);
    fill_halo(*t.f, g);
  }
  for (const auto& t : targets2) {
    put(*t.f, bufs[t.buf_idx]);
    fill_halo(*t.f, g);
  }
  for (const auto& t : targets_b) {
    if (t.f3) put(*t.f3, bufs[t.buf_idx]);
    else put(*t.f2, bufs[t.buf_idx]);
  }
  for (const auto& t : targets_i) {
    std::vector<int> hw(bufs[t.buf_idx].size());
    for (size_t k = 0; k < hw.size(); ++k) hw[k] = int(std::lround(bufs[t.buf_idx][k]));
    t.f->upload(tile::local_part(*t.f, hw));
  }
  if (m_.suite) m_.suite->restarted(start_step);
}
#endif

// Output field lists and the wrfout writer (also called by the nest driver before start(), so that
// the nest initialisation feedback reaches the parent's first history frame)
void DomainRunner::prepare_output() {
  if (output_prepared_) return;
  output_prepared_ = true;
  if (start_date_.empty())
    start_date_ = cfg_.get_string("run.start_date", !m_.start_date.empty() ? m_.start_date : "2000-01-01_00:00:00");
  if (m_.rk && m_.rk->physics()) {
    extra_2d_ = {&m_.rk->physics()->rainnc, &m_.rk->physics()->rainncv};
    if (m_.rk->physics()->ice_precip()) {
      extra_2d_.push_back(&m_.rk->physics()->snownc);
      extra_2d_.push_back(&m_.rk->physics()->snowncv);
      extra_2d_.push_back(&m_.rk->physics()->graupelnc);
      extra_2d_.push_back(&m_.rk->physics()->graupelncv);
      extra_2d_.push_back(&m_.rk->physics()->sr);
    }
    if (m_.rk->physics()->params().mp_physics == 28)
      for (const Field2* f : {&m_.rk->physics()->qnwfa2d, &m_.rk->physics()->qnifa2d}) extra_2d_.push_back(f);
    if (m_.rk->physics()->refl_10cm.layout().total > 0) extra_3d_.push_back(&m_.rk->physics()->refl_10cm);
  }
  if (m_.suite) {  // column physics surface and cumulus fields (WRF names in lower case)
    const phys::driver::PhysicsSuite& su = *m_.suite;
    for (const Field2* f : {&su.hfx, &su.qfx, &su.lh, &su.ust, &su.znt, &su.pblh, &su.tsk, &su.grdflx, &su.qsfc,
                            &su.flhc, &su.flqc, &su.t2, &su.th2, &su.q2, &su.u10, &su.v10, &su.psfc, &su.albedo,
                            &su.albbck, &su.emiss, &su.canwat, &su.snow, &su.snowh, &su.snowc, &su.noahres,
                            &su.acgrdflx, &su.achfx, &su.aclhf, &su.sfcevp, &su.potevp, &su.mol, &su.rmol, &su.br,
                            &su.wspd, &su.fm, &su.fh, &su.zol, &su.regime, &su.sfcexc, &su.lai, &su.xland,
                            &su.rainc, &su.raincv, &su.nca, &su.pratec, &su.cutop, &su.cubot, &su.htop, &su.hbot})
      extra_2d_.push_back(f);
    extra_3d_.insert(extra_3d_.end(), {&su.tslb, &su.smois, &su.sh2o, &su.pt.rublten, &su.pt.rvblten, &su.pt.rthblten,
                                       &su.pt.rqvblten, &su.exch_h});
    if (su.options().sf_sfclay_physics == 2 || su.options().bl_pbl_physics == 2) {
      for (const Field2* f : {&su.thz0, &su.uz0, &su.vz0, &su.akhs, &su.akms, &su.ct, &su.tshltr, &su.th10, &su.qshltr,
                              &su.q10, &su.pshltr, &su.u10e, &su.v10e, &su.mixht})
        extra_2d_.push_back(f);
      extra_3d_.insert(extra_3d_.end(), {&su.tke_pbl, &su.el_pbl});
    }
    if (su.options().sf_surface_physics == 4) {
      for (const Field2* f : {&su.tvxy, &su.tgxy, &su.canicexy, &su.canliqxy, &su.eahxy, &su.tahxy, &su.cmxy,
                              &su.chxy, &su.fwetxy, &su.sneqvoxy, &su.alboldxy, &su.qsnowxy, &su.qrainxy, &su.wslakexy,
                              &su.zwtxy, &su.waxy, &su.wtxy, &su.lfmassxy, &su.rtmassxy, &su.stmassxy, &su.woodxy,
                              &su.stblcpxy, &su.fastcpxy, &su.xsaixy, &su.taussxy, &su.smcwtdxy, &su.deeprechxy,
                              &su.rechxy, &su.t2mvxy, &su.t2mbxy, &su.q2mvxy, &su.q2mbxy, &su.tradxy, &su.neexy,
                              &su.gppxy, &su.nppxy, &su.fvegxy, &su.runsfxy, &su.runsbxy, &su.ecanxy, &su.edirxy,
                              &su.etranxy, &su.fsaxy, &su.firaxy, &su.aparxy, &su.psnxy, &su.savxy, &su.sagxy,
                              &su.rssunxy, &su.rsshaxy, &su.bgapxy, &su.wgapxy, &su.tgvxy, &su.tgbxy, &su.chvxy,
                              &su.chbxy, &su.shgxy, &su.shcxy, &su.shbxy, &su.evgxy, &su.evbxy, &su.ghvxy, &su.ghbxy,
                              &su.irgxy, &su.ircxy, &su.irbxy, &su.trxy, &su.evcxy, &su.chleafxy, &su.chucxy,
                              &su.chv2xy, &su.chb2xy, &su.rs, &su.sfcrunoff, &su.udrunoff, &su.acsnow, &su.acsnom})
        extra_2d_.push_back(f);
    }
    if (su.radiation_on()) {
      for (const Field2* f : {&su.glw, &su.gsw, &su.swdown, &su.coszen}) extra_2d_.push_back(f);
      extra_3d_.push_back(&su.pt.rthraten);
      extra_3d_.push_back(&su.cldfra);
      if (auto* pc = m_.rk->physics(); pc && pc->params().microp_re)
        extra_3d_.insert(extra_3d_.end(), {&pc->re_cloud, &pc->re_ice, &pc->re_snow});
    }
    if (su.options().cu_physics != 0)
    {
      extra_3d_.insert(extra_3d_.end(), {&su.w0avg, &su.pt.rthcuten, &su.pt.rqvcuten, &su.pt.rqccuten});
      if (m_.st->P_QR >= 0) extra_3d_.push_back(&su.pt.rqrcuten);
      if (m_.st->P_QI >= 0) extra_3d_.push_back(&su.pt.rqicuten);
      if (m_.st->P_QS >= 0) extra_3d_.push_back(&su.pt.rqscuten);
      if (su.options().cu_physics == 16 || su.options().cu_physics == 3)
        extra_3d_.insert(extra_3d_.end(), {&su.pt.rucuten, &su.pt.rvcuten, &su.pt.rthften, &su.pt.rqvften});
      if (su.options().cu_physics == 6)
        extra_3d_.insert(extra_3d_.end(), {&su.pt.rucuten, &su.pt.rvcuten, &su.pt.rqvften});
    }
    if (m_.st->P_QC >= 0) extra_3d_.push_back(&su.pt.rqcblten);
    if (m_.st->P_QI >= 0) extra_3d_.push_back(&su.pt.rqiblten);
  }

#ifdef CPPWRF_HAVE_NETCDF
  if ((write_wrfout_ || need_history_) && !wrfout_)
  {
    std::vector<const Field2*> f2 = extra_2d_;
    std::vector<const Field3*> f3;  // first match wins: the microphysics' grid%rho is the last writer
    if (m_.rk && m_.rk->physics())
      for (const Field3* f : m_.rk->physics()->fields()) f3.push_back(f);
    f3.insert(f3.end(), extra_3d_.begin(), extra_3d_.end());
    if (m_.suite) {
      for (const Field2* f : m_.suite->fields2()) f2.push_back(f);
      for (const Field3* f : m_.suite->fields3()) f3.push_back(f);
    }
    if (m_.diff) {
      for (const Field3* f : m_.diff->fields()) f3.push_back(f);
      for (const Field2* f : m_.diff->fields2()) f2.push_back(f);
    }
    // output.wrf_dir: the directory of the WRF files (wrfout, wrfrst, auxhist; default: the domain's output directory)
    wrfout_ = std::make_unique<WrfHistory>(cfg_, m_, cfg_.get_string("output.wrf_dir", out_dir_), domain_tag_,
                                           start_date_, f2, f3);
    if (m_.rk) m_.rk->on_first_rk_prep = [this] { wrfout_->first_rk_prep(); };
  }
#endif
}

bool DomainRunner::start() {
  const Grid& g = m_.g;
  dyn::State& st = *m_.st;
  dyn::BaseState& base = *m_.base;
  const dyn::LargeStepParams& lp = m_.lp;
  const dyn::AcousticParams& ap = m_.ap;
  const cases::CaseDef& cd = m_.cd;

  diag_iv_ = cfg_.get_int("output.diag_interval", 10);
  out_iv_ = cfg_.get_int("output.out_interval", std::max(1L, m_.nsteps));
  if (diag_iv_ < 1) throw std::runtime_error("output.diag_interval must be >= 1 (got " + std::to_string(diag_iv_) + ")");
  if (out_iv_ < 1) throw std::runtime_error("output.out_interval must be >= 1 (got " + std::to_string(out_iv_) + ")");
  hist_iv_ = out_iv_;  // load_restart_file may change it
  hist_ref_ = 0;
  {  // AUXHIST3_ALARM: auxhist3_interval (minutes); load_restart_file may change it
    const long a3 = cfg_.get_int("phys.auxhist3_interval", 0);
    const double st = double(a3) * 60.0 / g.dt;
    if (a3 < 0 || (a3 > 0 && st != std::floor(st)))
      throw std::runtime_error("phys.auxhist3_interval must be >= 0 and a multiple of time.dt (minutes)");
    aux3_iv_ = std::lround(st);
    aux3_ref_ = 0;
    aux3_write_ = cfg_.get_bool("output.auxhist3", false);
    if (aux3_write_ && (!write_wrfout_ || aux3_iv_ <= 0))
      throw std::runtime_error("output.auxhist3 (io_form_auxhist3 = 2) needs output.format = wrfout or both and "
                               "phys.auxhist3_interval > 0");
    if (aux3_iv_ > 0 && m_.adapt)
      throw std::runtime_error("phys.auxhist3_interval with time.adaptive is not supported (the auxhist3 alarm by time "
                               "is not ported)");
  }

  if (g.dt <= 0.0) throw std::runtime_error("time.dt must be > 0 (got " + std::to_string(g.dt) + ")");
  if (g.nx <= 0) throw std::runtime_error("grid.nx must be > 0 (got " + std::to_string(g.nx) + ")");
  if (g.ny <= 0) throw std::runtime_error("grid.ny must be > 0 (got " + std::to_string(g.ny) + ")");
  if (g.nz <= 0) throw std::runtime_error("grid.nz must be > 0 (got " + std::to_string(g.nz) + ")");
  if (m_.run_time < 0.0) throw std::runtime_error("run.run_time must be >= 0 (got " + std::to_string(m_.run_time) + ")");
  if (m_.run_time > 0.0 && !m_.adapt) {
    double steps_exact = m_.run_time / g.dt;
    if (std::abs(steps_exact - std::round(steps_exact)) > 1e-4) {
      throw std::runtime_error("run.run_time (" + std::to_string(m_.run_time) + ") must be an integer multiple of time.dt (" + std::to_string(g.dt) + ")");
    }
  }

  std::string restart_file = cfg_.get_string("run.restart_file", "");
  double restart_interval = cfg_.get_double("restart.interval", cfg_.get_double("output.restart_interval", 0.0));
  if (restart_interval < 0.0) throw std::runtime_error("restart.interval must be >= 0 (got " + std::to_string(restart_interval) + ")");
  rst_iv_s_ = restart_interval;
  rst_end_ = m_.adapt ? 0 : std::lround(cfg_.get_double("restart.end", 0.0) / g.dt);
  if (m_.adapt && cfg_.get_double("restart.end", 0.0) > 0)
    throw std::runtime_error("restart.end is not supported with time.adaptive");
  if (m_.adapt) {  // the history alarm by time (set_timekeeping: history_interval), PrevRingTime = the start
    const long hs = cfg_.get_int("time.history_interval_s", 0);
    hist_alarm_t_ = hs > 0;
    if (hist_alarm_t_) hist_iv_t_ = wrf_time::make(hs);
  }
  stop_on_nonfinite_ = cfg_.get_bool("run.stop_on_nonfinite", true);
  write_native_restart_ = cfg_.get_bool("restart.native", true);
  wrf_timing_ = cfg_.get_bool("output.wrf_timing", false);
  // the non-finite check of every step (else on the diagnostic steps only, output.diag_interval)
  nonfinite_every_step_ = cfg_.get_bool("run.check_nonfinite_every_step", false);
  start_date_ = cfg_.get_string("run.start_date", !m_.start_date.empty() ? m_.start_date : "2000-01-01_00:00:00");

#ifndef CPPWRF_HAVE_NETCDF
  if (write_wrfout_) {
    throw std::runtime_error("output.format=" + out_fmt_ + " requires NetCDF support (CPPWRF_HAVE_NETCDF)");
  }
  if (rst_iv_s_ > 0 || !restart_file.empty()) {
    throw std::runtime_error("restarts require NetCDF support (CPPWRF_HAVE_NETCDF)");
  }
#endif

  prepare_output();  // reads the output.* keys
  check_config_keys(cfg_);  // a key no code reads (misspelled, wrong section, not ported) is an error

  start_step = 0;
#ifdef CPPWRF_HAVE_NETCDF
  if (!restart_file.empty()) {
    load_restart_file(restart_file);
    if (wrfout_)
      wrfout_->set_restart_time(m_.adapt ? wrf_time::real_time<double>(m_.sim_offset) : double(start_step) * g.dt);
    // med_before_solve_io writes an auxiliary history stream whose alarm the restart file left ringing
    if (aux3_write_ && wrfout_ && aux3_ring_at_start_ == 1) {
      wrfout_->set_exact_time(elapsed(start_step), m_.adapt != nullptr);
      wrfout_->write_auxhist3(start_step, time_s(start_step));
    }
  }
#endif
  rst_prev_ = double(start_step) * g.dt;  // the alarm's PrevRingTime starts at the run's start (ESMF_Clock.F90:773)
  if (m_.adapt) {
    rst_iv_t_ = wrf_time::make(std::llround(rst_iv_s_));
    if (rst_iv_s_ != std::floor(rst_iv_s_)) throw std::runtime_error("restart.interval must be whole seconds");
    if (m_.suite && m_.suite->options().sst_update == 1)
      throw std::runtime_error("sst_update with time.adaptive is not supported (the auxinput4 alarm by time is not ported)");
  }
  if (aux10_on()) {  // set_timekeeping: StopTime = the run's start + auxinput10_end_h (none without an end)
    const int end_h = m_.suite->options().fdda.end_h;
    aux10_stop_s_ = end_h > 0 ? double(start_step) * g.dt + double(end_h) * 3600.0 : -1.0;
    if (wrfout_)
      wrfout_->set_auxinput10_alarm(double(m_.suite->options().fdda.interval_m) * 60.0, aux10_first_s_, aux10_stop_s_);
  }

  // a decomposed run: the writer (core/tiles.hpp) makes the files; every worker takes part in the gathers
  const bool wr = tile::writer();
  if (wr) std::filesystem::create_directories(out_dir_);

  // run.json
  {
    io::JsonWriter j;
    j.start_object();
    j.key("grid"); j.start_object();
    j.key_value("nx", (long long)g.nx); j.key_value("ny", (long long)g.ny); j.key_value("nz", (long long)g.nz);
    j.key_value("dx", g.dx); j.key_value("dy", g.dy); j.key_value("dt", g.dt);
    j.key_value("ztop", g.ztop); j.key_value("p_top", g.p_top);
    j.key_value("bc_x", std::string_view(bc_name(g.bc_x))); j.key_value("bc_y", std::string_view(bc_name(g.bc_y)));
    j.key("eta_levels"); j.start_array(); for (double e : m_.eta) j.write_double(e); j.end_array();
    j.end_object();
    j.key_value("case", std::string_view(cname_));
    j.key("case_params"); j.start_object();
    for (auto& [k, v] : cd.params) j.key_value(k, v);
    j.end_object();
    j.key("params"); j.start_object();
    j.key_value("epssm", double(ap.epssm)); j.key_value("smdiv", double(ap.smdiv)); j.key_value("emdiv", double(ap.emdiv));
    j.key_value("khdif", double(lp.khdif)); j.key_value("kvdif", double(lp.kvdif));
    j.key_value("top_lid", lp.top_lid); j.key_value("time_step_sound", (long long)m_.n_sound);
    j.key_value("run_time", m_.run_time); j.key_value("nsteps", (long long)m_.nsteps);
    j.key_value("h_adv_order", (long long)lp.h_adv_order); j.key_value("v_adv_order", (long long)lp.v_adv_order);
    j.key_value("hybrid_opt", (long long)m_.hybrid_opt);
    j.key_value("diff_opt", (long long)m_.diff_opt);
    j.key_value("km_opt", (long long)m_.km_opt);
    j.key_value("pr_inv", double(lp.pr_inv));
    j.key_value("moist_adv_opt", (long long)m_.sp.moist_adv_opt); j.key_value("scalar_adv_opt", (long long)m_.sp.scalar_adv_opt);
    j.key("scalars"); j.start_array(); for (auto& n : st.q_names) j.write_string(n); j.end_array();
    j.key_value("n_moist", (long long)st.n_moist);
    j.key_value("mp_physics", (long long)(m_.rk && m_.rk->physics() ? m_.rk->physics()->params().mp_physics : 0));
    j.end_object();
    j.key_value("precision", std::string_view(precision_name));
    j.key_value("backend", std::string_view(backend_name()));
    j.key_value("small_step", dyn::RK3::small_step_available());
    j.key_value("config_raw", std::string_view("__CPPWRF_CONFIG_JSON_RAW__"));
    j.end_object();
    std::string js = j.str();
    std::string cj = cfg_.to_json();
    std::string token = "\"config_raw\":\"__CPPWRF_CONFIG_JSON_RAW__\"";
    auto pos = js.find(token);
    if (pos != std::string::npos) {
      js.replace(pos, token.size(), "\"config\":" + cj);
    }
    if (wr) io::write_text_file_atomic(out_dir_ + "/run.json", js + "\n");
  }

  // Preserve pre-restart rows in diag.csv verbatim (M7)
  std::vector<std::string> pre_diag_lines;
  if (start_step > 0 && std::filesystem::exists(out_dir_ + "/diag.csv")) {
    std::ifstream f(out_dir_ + "/diag.csv");
    std::string line;
    if (std::getline(f, line)) {
      while (std::getline(f, line)) {
        if (line.empty()) continue;
        auto comma = line.find(',');
        if (comma != std::string::npos) {
          try {
            long step_val = std::stol(line.substr(0, comma));
            if (step_val < start_step) {
              pre_diag_lines.push_back(line);
            }
          } catch (...) {}
        }
      }
    }
  }

  if (wr)
    diag_ = std::make_unique<io::DiagWriter>(out_dir_ + "/diag.csv",
                                           std::vector<std::string>{"step", "time", "max_abs_u", "max_abs_v", "max_abs_w", "min_th_pert", "max_th_pert",
                                                                    "dry_mass", "theta_mass", "total_energy", "wall_s"});
  for (const auto& line : pre_diag_lines) {
    if (diag_) diag_->raw_line(line);
  }

  if (wr) snap_ = std::make_unique<io::SnapshotWriter>(out_dir_);
  dg_ = std::make_unique<dyn::Diagnostics>(g, cfg_.get_int("dyn.use_theta_m", 1) == 1);

  prepare_output();

  t0_ = std::chrono::steady_clock::now();
  step_time = 0.0;

  if (wr)
    std::printf("cppwrf: case=%s grid=%dx%dx%d dx=%g dt=%g n_sound=%d steps=%ld backend=%s precision=%s\n",
              cname_.c_str(), g.nx, g.ny, g.nz, g.dx, g.dt, m_.n_sound, m_.nsteps, backend_name(), precision_name);

  if (!do_diag(start_step)) return false;
  if (start_step == 0) do_snap(start_step);
  device_memory_report("after the setup");
  wrf_tick_ = std::chrono::steady_clock::now();
  return true;
}

// WRF's end_timing: "Timing for <what>: <F10.5> elapsed seconds"
void DomainRunner::wrf_timing_line(const std::string& what, std::chrono::steady_clock::time_point since) const {
  if (!tile::writer()) return;
  const double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - since).count();
  std::printf("Timing for %s: %10.5f elapsed seconds\n", what.c_str(), s);
  std::fflush(stdout);
}

void DomainRunner::after_solve(long n) {
#ifdef CPPWRF_HAVE_NETCDF
  if (write_wrfout_ && wrfout_ && (hist_due(n) || n == m_.nsteps || rst_due(n) || aux3_due(n))) wrfout_->after_solve(n);
#else
  (void)n;
#endif
}

// use_adaptive_time_step, at the start of step n: med_latbound_in, adapt_timestep (Model::adapt_step), then what
// ESMF_ClockAdvance will do after the step: the end time, the history and restart alarms, the stop time
void DomainRunner::adapt_before_step(long n) {
  m_.adapt_step(n);
  const wrf_time::Interval t = m_.step_end;
  t_end_.resize(std::size_t(n - start_step) + 1);
  hist_ring_.resize(t_end_.size(), 0);
  rst_ring_.resize(t_end_.size(), 0);
  const std::size_t i = std::size_t(n - start_step);
  t_end_[i] = t;
  hist_ring_[i] = 0;
  if (hist_alarm_t_ && hist_prev_t_ + hist_iv_t_ <= t) {
    hist_ring_[i] = 1;
    hist_prev_t_ = hist_prev_t_ + hist_iv_t_;
  }
  rst_ring_[i] = 0;
  if (rst_iv_s_ > 0 && rst_prev_t_ + rst_iv_t_ <= t) {
    rst_ring_[i] = 1;
    rst_prev_t_ = rst_prev_t_ + rst_iv_t_;
  }
  // the time loop ends when the clock reaches the stop time (ESMF_ClockIsStopTime: current >= stop)
  if (m_.sim_offset + t >= wrf_time::make(std::llround(m_.run_time))) m_.nsteps = n;
}

void DomainRunner::before_step(long n) {
  if (m_.adapt) adapt_before_step(n);
#ifdef CPPWRF_HAVE_NETCDF
  if (write_wrfout_ && wrfout_ && (hist_due(n) || n == m_.nsteps || rst_due(n) || aux3_due(n)))
    wrfout_->before_step(n);
#endif
  if (pending_ >= 0) {  // deferred frame of the previous step (set_defer_output)
    const long p = pending_;
    pending_ = -1;
    if (p % diag_iv_ == 0) do_diag(p);
    if (p % out_iv_ == 0 || hist_due(p) || aux3_due(p)) do_snap(p);
  }
  step_start_ = std::chrono::steady_clock::now();
  // solve_em: restart_flag = Is_alarm_tstep(restart alarm) (PrevRingTime + interval <= CurrTime + dt), i.e. the
  // alarm rings at the end of step n
  if (m_.suite) m_.suite->restart_flag = rst_due(n);
  // solve_em: diag_flag = Is_alarm_tstep(history alarm): the microphysics computes REFL_10CM in this step
  if (m_.rk && m_.rk->physics()) m_.rk->physics()->diagflag = hist_due(n);
  if (m_.before_step) m_.before_step(n);
#ifdef CPPWRF_HAVE_NETCDF
  // sst_update: med_before_solve_io reads auxinput4 after the history output when its alarm rings
  if (m_.suite && m_.suite->options().sst_update == 1 && aux4_read_step_ != n - 1 && aux4_due(n - 1))
    read_aux4(n - 1);
  // grid_fdda: med_before_solve_io reads auxinput10 (wrffdda_d0N) when its alarm rings
  if (aux10_on() && aux10_read_step_ != n - 1 && aux10_due(n - 1)) read_aux10(n - 1);
#endif
}

#ifdef CPPWRF_HAVE_NETCDF
// AUXINPUT4_ALARM: created at the start with auxinput4_interval (minutes), ringing at the start; a run resumed from
// a WRF restart file rings first as the file says (load_restart_file)
bool DomainRunner::aux4_due(long s) const {
  if (s == start_step && start_step > 0 && aux4_ring_at_start_ >= 0) return aux4_ring_at_start_ == 1;
  const double t = double(s) * m_.g.dt, iv = cfg_.get_double("phys.auxinput4_interval", 360.0) * 60.0;
  return iv > 0 && t >= aux4_first_s_ - 1e-6 &&
         std::fabs((t - aux4_first_s_) - iv * std::round((t - aux4_first_s_) / iv)) < 1e-6;
}

bool DomainRunner::aux10_on() const { return m_.suite && m_.suite->options().fdda.grid_fdda == 1; }

bool DomainRunner::aux10_due(long s) const {
  if (s == start_step && start_step > 0 && aux10_ring_at_start_ >= 0) return aux10_ring_at_start_ == 1;
  const double t = double(s) * m_.g.dt, iv = double(m_.suite->options().fdda.interval_m) * 60.0;
  if (aux10_stop_s_ >= 0 && t > aux10_stop_s_ + 1e-6) return false;  // ESMF_ClockAdvance: CurrTime > StopTime
  return iv > 0 && t >= aux10_first_s_ - 1e-6 &&
         std::fabs((t - aux10_first_s_) - iv * std::round((t - aux10_first_s_) / iv)) < 1e-6;
}

void DomainRunner::read_aux10(long s) {
  read_wrffdda(cfg_.get_string("real.dir") + "/" + cfg_.get_string("real.wrffdda", "wrffdda_" + domain_tag_),
               wrf_io::add_seconds(start_date_, std::lround(double(s) * m_.g.dt)), *m_.suite);
  aux10_read_step_ = s;
}

void DomainRunner::read_aux4(long s) {
  std::string lw = cfg_.get_string("real.wrfinput", "wrfinput_d01");
  if (lw.rfind("wrfinput", 0) == 0) lw.replace(0, 8, "wrflowinp");
  read_wrflowinp(cfg_.get_string("real.dir") + "/" + cfg_.get_string("real.wrflowinp", lw),
                 wrf_io::add_seconds(start_date_, std::lround(double(s) * m_.g.dt)), *m_.suite);
  aux4_read_step_ = s;
}
#endif

bool DomainRunner::reads_state(long n) const {
  if (m_.adapt || n == m_.nsteps || (nonfinite_every_step_ && !nonfinite_seen_)) return true;
  if (n % diag_iv_ == 0 || n % out_iv_ == 0 || hist_due(n) || aux3_due(n)) return true;
#ifdef CPPWRF_HAVE_NETCDF
  if (rst_iv_s_ > 0 && rst_due(n)) return true;
#endif
  return false;
}

bool DomainRunner::after_step(long n) {
  step_time += std::chrono::duration<double>(std::chrono::steady_clock::now() - step_start_).count();
  if (m_.adapt) m_.advance_clock();
  if (wrf_timing_) {  // integrate: "main: time <current time> on domain <I3>" after the solve
    char what[96];
    std::snprintf(what, sizeof what, "main: time %s on domain %3d",
                  wrf_io::add_seconds(start_date_, std::lround(time_s(n))).c_str(), std::stoi(domain_tag_.substr(1)));
    wrf_timing_line(what, wrf_tick_);
    wrf_tick_ = std::chrono::steady_clock::now();
  }
  bool last = (n == m_.nsteps);
  if (nonfinite_every_step_ && !nonfinite_seen_) {  // run.check_nonfinite_every_step: the diagnostics' reductions
    const dyn::DiagRow r = dg_->compute(*m_.st, *m_.base);
    if (!r.finite()) {
      nonfinite_seen_ = true;  // reported once when the run goes on (run.stop_on_nonfinite = false)
      if (nonfinite(n, r)) return false;
    }
  }
  if (defer_output_ && !last && (n % diag_iv_ == 0 || n % out_iv_ == 0 || hist_due(n) || aux3_due(n))) {
    pending_ = n;
  } else if (n % diag_iv_ == 0 || last) {
    if (!do_diag(n)) return false;
  }
  if ((n % out_iv_ == 0 || hist_due(n) || aux3_due(n) || last) && pending_ != n) {
    do_snap(n);
  }
#ifdef CPPWRF_HAVE_NETCDF
  const bool ring = rst_due(n);
  if (ring && !m_.adapt) rst_prev_ += rst_iv_s_;
  // d01: med_before_solve_io of the next step reads auxinput4 before med_restart_out writes the restart files of
  // this time (a nest reads in its own med_before_solve_io, after the parent's med_restart_out)
  if (ring && !last && domain_tag_ == "d01" && m_.suite && m_.suite->options().sst_update == 1 && aux4_due(n))
    read_aux4(n);
  if (ring && !last && domain_tag_ == "d01" && aux10_on() && aux10_due(n)) read_aux10(n);
  if (rst_iv_s_ > 0 && (ring || last) && (rst_end_ <= 0 || n <= rst_end_)) {
    do_restart(n, ring);
  }
#endif
  return true;
}

void DomainRunner::finish() {
  if (!tile::writer()) return;
  if (m_.nsteps > start_step) {
    double cells = double(m_.g.nx) * m_.g.ny * m_.g.nz;
    long taken = m_.nsteps - start_step;
    std::printf("cppwrf: done, %ld steps, stepping %.3f s, %.2f ns/cell/step\n", taken, step_time,
                step_time / (cells * taken) * 1e9);
    device_memory_report("at the end");
  } else {
    std::printf("cppwrf: initialised, no time stepping (run.run_time = 0)\n");
  }
}

// The first non-finite value of the prognostic state (fields in this order, then k, j, i), for the error message
std::string DomainRunner::first_nonfinite() const {
  const dyn::State& st = *m_.st;
  std::vector<real> h;
  auto scan = [&](const std::string& name, const auto& f) -> std::string {
    Layout L;
    tile::download(f, h, L);  // a decomposed run: the whole field on the writer
    if (!tile::writer()) return "";
    for (int k = 0; k < std::max(L.nz, 1); ++k)
      for (int j = 0; j < L.ny; ++j)
        for (int i = 0; i < L.nx; ++i)
          if (!std::isfinite(double(h[L.index(i, j, k)]))) {
            char b[160];
            std::snprintf(b, sizeof b, "%s at (i, j, k) = (%d, %d, %d) from 1: %g", name.c_str(), i + 1, j + 1, k + 1,
                          double(h[L.index(i, j, k)]));
            return b;
          }
    return "";
  };
  // every field is gathered (a collective of a decomposed run); the first message is kept
  std::string w;
  auto keep = [&](std::string m) {
    if (w.empty()) w = std::move(m);
  };
  const std::pair<const char*, const Field3*> f3[] = {
      {"u", &st.u_2}, {"v", &st.v_2}, {"w", &st.w_2}, {"t (theta perturbation)", &st.t_2},
      {"ph (geopotential perturbation)", &st.ph_2}, {"p (pressure perturbation)", &st.p}, {"al", &st.al}};
  for (const auto& [name, f] : f3) keep(scan(name, *f));
  keep(scan("mu (dry air mass perturbation)", st.mu_2));
  for (int n = 0; n < st.n_scalars(); ++n) keep(scan(st.q_names[n], st.q_2[n]));
  if (!w.empty()) return w;
  return "none in the prognostic fields";
}

bool DomainRunner::nonfinite(long n, const dyn::DiagRow& r) {
  const std::string first = first_nonfinite();
  if (tile::writer())
    std::fprintf(stderr, "ERROR: non-finite values at step %ld (t=%g s): max|u|=%g max|w|=%g th'=[%g,%g]; first: %s\n", n,
                 time_s(n), r.max_abs_u, r.max_abs_w, r.min_th_pert, r.max_th_pert, first.c_str());
  // run.stop_on_nonfinite = false: go on as WRF does (its output then has the same NaN / Inf to compare)
  return stop_on_nonfinite_;
}

bool DomainRunner::do_diag(long n) {
  dyn::DiagRow r = dg_->compute(*m_.st, *m_.base);
  double wall = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0_).count();
  if (!r.finite() && nonfinite(n, r)) return false;
  if (diag_)
    diag_->row({double(n), time_s(n), r.max_abs_u, r.max_abs_v, r.max_abs_w, r.min_th_pert, r.max_th_pert,
              r.dry_mass, r.theta_mass, r.total_energy, wall});
  return true;
}

void DomainRunner::do_snap(long n) {
  const Grid& g = m_.g;
  dyn::State& st = *m_.st;
  dyn::BaseState& base = *m_.base;

  if (write_native_ && (n % out_iv_ == 0 || n == m_.nsteps)) {
    auto vars = dyn::snapshot_vars(st, base, g, store_, extra_2d_, extra_3d_);
    if (snap_) snap_->write(n, time_s(n), vars);
  }

#ifdef CPPWRF_HAVE_NETCDF
  // WRF writes history only when the history alarm rings (med_last_solve_io): no extra frame at the last
  // step of a run that is not a multiple of history_interval (the native snapshot above keeps it)
  if (wrfout_) wrfout_->set_exact_time(elapsed(n), m_.adapt != nullptr);  // XTIME and Times of the clock
  if (write_wrfout_ && wrfout_ && (n == 0 || hist_due(n))) {
    const auto t = std::chrono::steady_clock::now();
    wrfout_->write(n, time_s(n));
    if (wrf_timing_) wrf_timing_line(writing(wrfout_->last_path(), domain_tag_), t);
  }
  if (aux3_write_ && wrfout_ && (n == 0 || aux3_due(n))) {
    const auto t = std::chrono::steady_clock::now();
    wrfout_->write_auxhist3(n, time_s(n));
    if (wrf_timing_) wrf_timing_line(writing(wrfout_->last_path(), domain_tag_), t);
  }
#endif
}

#ifdef CPPWRF_HAVE_NETCDF
// RESTART_ALARM (set_timekeeping.F:412, an interval only): ESMF_ClockAdvance rings when PrevRingTime + interval
// <= the current time and then adds the interval to PrevRingTime once (ESMF_Clock.F90:1020-1029), so an
// interval that is not a multiple of dt rings at the first step past each multiple of it
bool DomainRunner::rst_due(long n) const {
  if (m_.adapt) return n > start_step && n - start_step < long(rst_ring_.size()) && rst_ring_[std::size_t(n - start_step)];
  return rst_iv_s_ > 0 && rst_prev_ + rst_iv_s_ <= double(n) * m_.g.dt + 1e-6 * m_.g.dt;
}

void DomainRunner::do_restart(long n, bool ring) {
  char rst_name[64];
  std::snprintf(rst_name, sizeof(rst_name), "restart_%06ld.nc", n);
  std::string rst_path = out_dir_ + "/" + rst_name;
  const auto t_rst = std::chrono::steady_clock::now();
  if (write_native_restart_) save_restart_file(rst_path, n, time_s(n));
  // wrfrst only when WRF's restart alarm rings, not at an off-interval last step; output_wrf writes the seconds
  // to the next ring as interval - (time - PrevRingTime) in whole seconds (share/output_wrf.F:413-435)
  if (wrfout_ && ring && m_.adapt) {
    // output_wrf.F:413-435: interval - (current time - PrevRingTime) in whole seconds; the history alarm rang at this
    // step only when it is the last one (med_restart_out of a later step runs after med_hist_out turned it off)
    const wrf_time::Interval t = t_end_[std::size_t(n - start_step)];
    wrfout_->set_exact_time(elapsed(n));
    const bool hring = n == m_.nsteps && hist_due(n);
    const long hsecs = hist_alarm_t_ ? long(hist_iv_t_.S - (t - hist_prev_t_).S) : 1700000000L;
    wrfout_->set_history_alarm(hring ? 1 : 0, hsecs);
    wrfout_->write_restart(n, time_s(n), 0.0, 0.0, double(rst_iv_t_.S - (t - rst_prev_t_).S), aux4_first_s_);
  } else if (wrfout_ && ring) {
    wrfout_->set_exact_time(elapsed(n), false);
    wrfout_->set_auxhist3_alarm(double(aux3_iv_) * m_.g.dt, double(aux3_ref_) * m_.g.dt);
    wrfout_->write_restart(n, n * m_.g.dt, double(hist_iv_) * m_.g.dt, double(hist_ref_) * m_.g.dt,
                           std::trunc(rst_iv_s_) - std::trunc(n * m_.g.dt - rst_prev_), aux4_first_s_);
  }
  if (wrf_timing_ && wrfout_ && ring) wrf_timing_line(writing("restart", domain_tag_), t_rst);
}
#endif

}  // namespace cppwrf::cases
