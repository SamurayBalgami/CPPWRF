// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Model assembly from a config (host side): grid, case, vertical levels, base and initial
// state, scalars, numerical parameters and the RK3 integrator. Shared by main and tests.
#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "cases/adapt_timestep.hpp"
#include "cases/cases.hpp"
#include "core/wrf_time.hpp"
#include "dyn/lateral_bc.hpp"
#include "dyn/diffusion_driver.hpp"
#include "dyn/rk3.hpp"
#include "io/config.hpp"
#include "phys/driver/suite.hpp"

namespace cppwrf::cases {

struct Model {
  Grid g;
  CaseDef cd;
  std::vector<double> eta;
  std::vector<double> xlat;
  std::vector<double> xlong;
  std::unique_ptr<dyn::BaseState> base;
  std::unique_ptr<dyn::State> st;
  std::unique_ptr<dyn::Tendencies> tend;
  dyn::LargeStepParams lp;
  dyn::AcousticParams ap;
  dyn::ScalarParams sp;
  double run_time = 0;
  long nsteps = 0;
  int n_sound = 0;
  int diff_opt = 0;
  int km_opt = 1;
  int hybrid_opt = 0;
  int map_proj = 0;
  double cen_lat = 0.0, cen_lon = 0.0;
  double truelat1 = 0.0, truelat2 = 0.0;
  double moad_cen_lat = 0.0, stand_lon = 0.0;
  std::string start_date;
  // fields only the initialisation sets, for the history output (ideal runs: TSK, TMN, the first frame's T)
  std::map<std::string, std::vector<double>> init_out;
  std::unique_ptr<dyn::RK3> rk;  // null when nsteps == 0
  std::unique_ptr<dyn::LateralBC> bc;  // real data: specified lateral boundaries
  std::unique_ptr<dyn::DiffusionDriver> diff;
  std::unique_ptr<phys::driver::PhysicsSuite> suite;  // column physics (sfclay/LSM/PBL), null: off  // WRF diff_opt 1 / sixth-order diffusion (null: off)
  // Called before step n (1-based) of the time loop: boundary interval switching (real data).
  std::function<void(long)> before_step;

  // ---- use_adaptive_time_step (time.adaptive = true): WRF's clock and adapt_timestep ----
  std::unique_ptr<AdaptTimeStep> adapt;  // null: a fixed time step
  // a fixed time step: WRF's clock step (set_timekeeping.F: time_step + time_step_fract_num / den for d01, the
  // parent's / parent_time_step_ratio for a nest; time.dt_den = that denominator, which the nest driver sets); the
  // clock after n steps is n times it, exactly (ESMF_ClockAdvance)
  wrf_time::Interval dt_clock;
  wrf_time::Interval now;         // current time - this run's start (the start of the coming step)
  wrf_time::Interval step_end;    // now + the step's dt (set by adapt_step)
  wrf_time::Interval sim_offset;  // this run's start - the simulation start (a resumed run: the restart time)
  wrf_time::Interval run_length;  // stop time - this run's start
  // med_latbound_in at the time since the simulation start: the boundary records and dtbc (real data)
  std::function<void(const wrf_time::Interval&)> before_step_time;
  // solve_em.F:352-386 at the start of step n: the boundary input, adapt_timestep, the new dt of every component,
  // the CFL maxima zeroed; step_end = now + dt
  void adapt_step(long n);
  // ESMF_ClockAdvance after step n
  void advance_clock() { now = step_end; }
  // the large step of every component and the acoustic step count of solve_em.F:458 (adaptive time step)
  void set_dt(double dt);

  static Model build(const io::Config& cfg);
};

// case = real: grid, base and initial state, boundaries from wrfinput/wrfbdy (src/cases/real_case.cpp)
void init_real_case(const io::Config& cfg, Model& m);
// mp_physics = 28: QNWFA2D / QNIFA2D from wrfinput, then thompson_init's aerosol profiles (real_case.cpp)
void init_real_aerosols(const io::Config& cfg, Model& m);
// Column physics (real data, P1 suite): true if any of phys.sf_sfclay_physics,
// sf_surface_physics, bl_pbl_physics is set; init_real_physics builds the suite, fills the
// initial surface state as WRF start_domain/phy_init and attaches it to m.rk (real_physics.cpp).
bool wants_column_physics(const io::Config& cfg);
void init_real_physics(const io::Config& cfg, Model& m);
// sst_update = 1: the auxinput4 record of `date` (WRF date string) from wrflowinp_d0N into the suite's fields
void read_wrflowinp(const std::string& path, const std::string& date, phys::driver::PhysicsSuite& su);
// grid_fdda = 1: the auxinput10 record of `date` from wrffdda_d0N into the suite's analyses (fdda3d, fdda2d)
void read_wrffdda(const std::string& path, const std::string& date, phys::driver::PhysicsSuite& su);
// phy_init's landuse_init (LANDUSE.TBL for the season of julday) on the wrfinput LU_INDEX, SEAICE, SNOWC;
// usemonalb: ALBBCK keeps the wrfinput value (albbck_in) and snow-covered points take ALBEDO = SNOALB
// (snoalb_in, the wrfinput SNOALB); both may be empty without usemonalb
struct LanduseInit {
  std::vector<double> albbck, albedo, z0, embck, emiss, mavail, xland, thc;
  int isn = 1;                  // season (1 summer, 2 winter)
  int lucats = 0, luseas = 0;   // LANDUSE.TBL categories and seasons
  std::vector<double> lu_state;  // WRF's LU_STATE: per category SCFX, then per season ALBD SLMO SFEM SFZ0 SFHC THERIN
};
LanduseInit landuse_init(const std::string& table_dir, const std::string& mminlu, int julday, double cen_lat,
                         int iswater, int isice, const std::vector<double>& lu, const std::vector<double>& xice,
                         const std::vector<double>& snowc, int fractional_seaice, bool usemonalb,
                         const std::vector<double>& albbck_in, const std::vector<double>& snoalb_in);

// Comma-separated list (whitespace trimmed, empty entries dropped).
std::vector<std::string> split_list(const std::string& s);
// domain.bc_x / bc_y: periodic | symmetric | specified | open
BC parse_bc(const std::string& s);

}  // namespace cppwrf::cases
