// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// wrfout_d0N history files as WRF v4.8.0 writes them: the history stream of the WRF I/O schema
// (data/wrf_schema) for this configuration, with WRF's dimensions, variables, attributes and global
// attributes. Values come from the model state (by WRF name); a variable the model does not carry keeps
// its wrfinput value (WRF reads it from the input stream and leaves it unchanged) or WRF's initial 0.
#ifdef CPPWRF_HAVE_NETCDF
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "cases/model.hpp"
#include "core/wrf_time.hpp"
#include "io/config.hpp"
#include "phys/driver/phy_prep.hpp"

namespace cppwrf::wrf_io {
struct DomainAtts;
struct OutVar;
class StreamFile;
class WrfSchema;
class WrfConfig;
class Namelist;
}  // namespace cppwrf::wrf_io

namespace cppwrf::cases {

class WrfHistory {
 public:
  // fields: model fields written under their (WRF lower-case) names
  WrfHistory(const io::Config& cfg, const Model& m, std::string out_dir, std::string domain_tag,
             std::string start_date, std::vector<const Field2*> fields2, std::vector<const Field3*> fields3);
  ~WrfHistory();
  // one history frame at model time time_sec after the start (step = WRF's itimestep)
  void write(long step, double time_sec);
  // one frame of the auxhist3 stream (med_hist_out(AUXHIST3_ALARM): auxhist3_outname, frames_per_auxhist3)
  void write_auxhist3(long step, double time_sec);
  // AUXHIST3_ALARM for the restart files (alarm 4): its interval and a time it rang, in seconds (interval 0: none)
  void set_auxhist3_alarm(double interval_s, double ref_s) { aux3_iv_s_ = interval_s; aux3_ref_s_ = ref_s; }
  // grid_fdda: AUXINPUT10_ALARM for the restart files (alarm 36): its interval, a time it rang and its StopTime, in
  // seconds since the simulation start (interval 0: none; stop < 0: none)
  void set_auxinput10_alarm(double interval_s, double ref_s, double stop_s) {
    aux10_iv_s_ = interval_s;
    aux10_ref_s_ = ref_s;
    aux10_stop_s_ = stop_s;
  }
  // wrfrst_d0N_<date>: the restart stream at model time time_sec when the restart alarm rings (alarms from the
  // history alarm's interval and a time it rang, in seconds; the restart alarm's seconds to its next ring; a time the
  // sst_update alarm rang)
  void write_restart(long step, double time_sec, double history_interval_s, double history_ref_s,
                     double restart_secs_to_ring, double auxinput4_ref_s);
  // before step n of a frame that will be written: runs without column physics evaluate phy_prep as
  // first_rk_step_part1 does every step (P_HYD of the frame)
  void before_step(long n);
  // phy_prep of that step where first_rk_step_part1 runs it (RK stage 1, after rk_step_prep)
  void first_rk_prep();
  // after the solve of step n, before nest feedback changes the state: WRF's T (th_phy_m_t0) of the frame
  void after_solve(long n);
  // med_nest_feedback for the history fields the model does not carry (Registry u= functions)
  // med_feedback_domain for the column-physics state: every field of the parent's physics suite with a Registry
  // feedback function (copy_fcn / copy_fcnm / copy_fcni) takes the child's values inside the nest
  void feedback_physics(WrfHistory& child, int ipos, int jpos, int ratio);
  void feedback_from(WrfHistory& child, int i_parent_start, int j_parent_start, int ratio);
  // med_nest_initial: parent%ht_coarse = parent%ht when a nest starts or restarts, with or without feedback
  // (share/mediation_integrate.F:789, 908)
  void keep_ht_coarse();
  // start_domain of a domain whose nest opened during the run (med_nest_initial: start_domain(nest), then
  // start_domain(parent)): start_em's slope arrays and laplacian again from the blended / fed-back terrain
  void restart_slopes();
  // a run resumed from a restart file at time_sec: START_DATE is the restart time
  void set_restart_time(double time_sec) { restart_sec_ = time_sec; }
  // the clock's exact time since the simulation start of the next write (Times = its whole seconds, XTIME =
  // minutesSinceSimulationStart; adaptive: the adaptive time step's clock, XTIME in real, else n fixed clock steps,
  // XTIME in double as before in the FP32 build), and the history alarm of the next write_restart (adaptive time step:
  // ringing, seconds to the next ring)
  void set_exact_time(const wrf_time::Interval& t, bool adaptive = true) {
    exact_ = t;
    has_exact_ = true;
    exact_adaptive_ = adaptive;
  }
  void set_history_alarm(int ring, long secs) { hist_alarm_ring_ = ring; hist_alarm_secs_ = secs; }
  // the file of the last write (write, write_auxhist3, write_restart), for the log
  const std::string& last_path() const { return last_path_; }

 private:
  // value() of a stream variable; ideal x-z runs repeat the model's row (WRF: e_sn = 3, two identical rows)
  bool out_value(const wrf_io::OutVar& v, std::vector<double>& out);
  bool value(const std::string& name, const std::string& varname, const std::vector<std::size_t>& dims,
             std::vector<double>& out);
  wrf_io::DomainAtts domain_atts();
  void start_em_slopes();
  bool from_wrfinput(const std::string& name, std::size_t n, std::vector<double>& out);

  // nest feedback: the Registry fields with a u= function (history and restart streams) and, per nest, the
  // parent / nest field pairs of feedback_physics and the fields feedback_from leaves to the model
  struct FeedbackCache;
  FeedbackCache& feedback_cache();
  std::unique_ptr<FeedbackCache> fb_cache_;

  const Model& m_;
  std::string out_dir_, domain_tag_, start_date_, wrfinput_, hist_outname_, rst_outname_, last_path_, hist_path_, aux3_path_;
  std::vector<const Field2*> f2_;
  std::vector<const Field3*> f3_;
  std::unique_ptr<wrf_io::Namelist> nl_;
  std::unique_ptr<wrf_io::WrfSchema> schema_;
  std::unique_ptr<wrf_io::WrfSchema> fb_schema_;  // Registry streams without iofields_filename (nest feedback)
  std::unique_ptr<wrf_io::WrfConfig> wc_;
  std::unique_ptr<wrf_io::StreamFile> file_;
  int frames_per_outfile_ = 10;
  std::unique_ptr<wrf_io::StreamFile> aux3_file_;
  std::string aux3_outname_;
  int frames_per_aux3_ = 999999;
  double aux3_iv_s_ = 0, aux3_ref_s_ = 0;
  int jrep_ = 1;  // output rows per model row: 2 for ideal x-z runs (ny = 1)
  double auxinput4_interval_s_ = 0;  // sst_update: the AUXINPUT4 alarm
  double aux10_iv_s_ = 0, aux10_ref_s_ = 0, aux10_stop_s_ = -1;  // grid_fdda: the AUXINPUT10 alarm
  int wrfinput_id_ = -1;
  std::vector<double> p_hyd0_;  // P_HYD of the initial state (start_em)
  std::unique_ptr<phys::driver::PhyPrepFields> prep_;  // runs without column physics
  std::map<long, std::vector<double>> p_hyd_snap_;  // P_HYD of phy_prep at the start of the step
  std::map<long, std::vector<double>> t_snap_;  // T at the end of the solve, by step
  bool same_m_ = false, same_u_ = false, same_v_ = false;
  bool model_only_ = false;
  std::map<std::string, std::vector<double>> fed_;  // nest-feedback values of such fields
  std::map<std::string, std::vector<double>> phy_init_;  // phy_init fields of runs without column physics
  long step_ = 0;
  long prep_step_ = -1;
  double restart_sec_ = 0;
  double time_sec_ = 0;
  bool has_exact_ = false;
  bool exact_adaptive_ = true;
  wrf_time::Interval exact_;
  int hist_alarm_ring_ = -1;
  long hist_alarm_secs_ = 0;
  std::string date_of(double time_sec) const;  // Times of a write

};

}  // namespace cppwrf::cases
#endif
