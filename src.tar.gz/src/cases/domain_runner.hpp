// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include <chrono>
#include <memory>
#include <string>
#include <vector>

#include "cases/model.hpp"
#include "core/wrf_time.hpp"
#include "dyn/diagnostics.hpp"
#include "io/config.hpp"
#include "io/output.hpp"

#ifdef CPPWRF_HAVE_NETCDF
#include "io_netcdf/restart.hpp"
#include "cases/wrf_history.hpp"
#endif

namespace cppwrf::cases {

class DomainRunner {
 public:
  DomainRunner(const io::Config& cfg, cases::Model& m, const std::string& out_dir,
               std::string domain_tag = "d01");
  ~DomainRunner();

  DomainRunner(const DomainRunner&) = delete;
  DomainRunner& operator=(const DomainRunner&) = delete;

  // Initializes domain state, loads restarts if needed, writes run.json, diag header, first diag/snap
  bool start();
  // output field lists and the wrfout writer (idempotent; start() calls it)
  void prepare_output();

  // Called before step n (1-based): boundary interval updates, start timing
  void before_step(long n);

  // Called after step n (1-based): step timing, diag, snapshot, wrfout, restart
  bool after_step(long n);
  // after_step(n) reads the model's fields (output, diagnostics, restart): a tiled run gathers them first
  bool reads_state(long n) const;
  // Called right after the solve of step n, before nests run and feed back (WRF's end of solve_em)
  void after_solve(long n);
  // Nested domains: WRF writes history in med_before_solve_io, i.e. a frame for step n at the start
  // of step n+1 (after the parent's next med_nest_force, whose couple/uncouple round trip changes
  // the state by an ulp); the last frame after the last step (med_last_solve_io).
  void set_defer_output(bool d) { defer_output_ = d; }
  // two-way nests: the WRF-field view (WrfHistory) carries the physics feedback, also when no wrfout is written
  void set_need_history(bool h) { need_history_ = h; }

  // Prints completion statistics
  void finish();

  long start_step = 0;
  double step_time = 0.0;

  const std::string& out_dir() const { return out_dir_; }
#ifdef CPPWRF_HAVE_NETCDF
  WrfHistory* history() { return wrfout_.get(); }
#endif
  const std::string& domain_tag() const { return domain_tag_; }

 private:
  bool defer_output_ = false;
  bool need_history_ = false;
  bool output_prepared_ = false;
  long pending_ = -1;  // deferred diag/snap step
  bool do_diag(long n);
  bool nonfinite(long n, const dyn::DiagRow& r);  // reports non-finite values; true: stop the run
  std::string first_nonfinite() const;
  void do_snap(long n);

#ifdef CPPWRF_HAVE_NETCDF
  void do_restart(long n, bool ring);
  void save_restart_file(const std::string& path, long step, double time_sec);
  void load_restart_file(const std::string& path);
#endif

  const io::Config& cfg_;
  cases::Model& m_;
  std::string out_dir_;
  std::string domain_tag_;

  long diag_iv_ = 10;
  long out_iv_ = 1;
  // WRF's HISTORY_ALARM: rings every hist_iv_ steps after step hist_ref_ (the start; a run resumed from a WRF
  // restart file takes the interval and first ring from it, see load_restart_file); 0: never
  long hist_iv_ = 1, hist_ref_ = 0;
  bool hist_due(long n) const {
    if (m_.adapt) return n > start_step && n - start_step < long(hist_ring_.size()) && hist_ring_[std::size_t(n - start_step)];
    return hist_iv_ > 0 && n > hist_ref_ && (n - hist_ref_) % hist_iv_ == 0;
  }
  // WRF's AUXHIST3_ALARM (auxhist3_interval, phys.auxhist3_interval minutes): as the history alarm, also after a
  // restart from a WRF file (its seconds to the next ring become the interval; ringing at the start when the file
  // says so); aux3_write_: io_form_auxhist3 = 2, the auxhist3 files (output.auxhist3)
  long aux3_iv_ = 0, aux3_ref_ = 0;
  int aux3_ring_at_start_ = -1;
  bool aux3_write_ = false;
  bool aux3_due(long n) const { return aux3_iv_ > 0 && n > aux3_ref_ && (n - aux3_ref_) % aux3_iv_ == 0; }
  double rst_iv_s_ = 0.0;  // restart interval (s), WRF's RESTART_ALARM
  double rst_prev_ = 0.0;  // the alarm's PrevRingTime (s)
  bool rst_due(long n) const;
  // adaptive time step: the exact time (since this run's start) at the end of step start_step + i, and the history and
  // restart alarms of ESMF_ClockAdvance by time (PrevRingTime + interval <= current time; PrevRingTime += interval)
  std::vector<wrf_time::Interval> t_end_{wrf_time::Interval{}};
  std::vector<char> hist_ring_{0}, rst_ring_{0};
  wrf_time::Interval hist_iv_t_, hist_prev_t_, rst_iv_t_, rst_prev_t_;
  bool hist_alarm_t_ = false;
  void adapt_before_step(long n);
  // the model time at the end of step n, seconds since the simulation start
  double time_s(long n) const {
    if (!m_.adapt) return double(n) * m_.g.dt;
    return wrf_time::real_time<double>(m_.sim_offset + t_end_[std::size_t(n - start_step)]);
  }
  // the clock at the end of step n since the simulation start (a fixed time step: n clock steps)
  wrf_time::Interval elapsed(long n) const {
    if (!m_.adapt) return m_.dt_clock * int(n);
    return m_.sim_offset + t_end_[std::size_t(n - start_step)];
  }
  // sst_update: AUXINPUT4_ALARM rings at aux4_first_s_ + k * interval (from the start, or as the WRF restart file
  // set it) and at the restart time when a WRF restart file has it ringing (-1: a CPPWRF restart file, by the schedule)
  double aux4_first_s_ = 0.0;
  int aux4_ring_at_start_ = -1;
  long aux4_read_step_ = -1;  // the step (time n * dt) whose wrflowinp record was read last
  bool aux4_due(long s) const;
  void read_aux4(long s);
  // grid_fdda: AUXINPUT10_ALARM (gfdda_interval_m) rings as the auxinput4 one up to its StopTime, this run's start
  // + gfdda_end_h (aux10_stop_s_ < 0: none); a ring reads the analyses of that time from wrffdda_d0N
  double aux10_first_s_ = 0.0, aux10_stop_s_ = -1.0;
  int aux10_ring_at_start_ = -1;
  long aux10_read_step_ = -1;
  bool aux10_on() const;
  bool aux10_due(long s) const;
  void read_aux10(long s);
  long rst_end_ = 0;  // restart.end: last step with a restart file (0: no end)
  bool stop_on_nonfinite_ = true;
  bool nonfinite_every_step_ = false;  // run.check_nonfinite_every_step
  bool nonfinite_seen_ = false;
  std::string start_date_;
  std::string cname_;
  std::string out_fmt_;
  bool write_native_ = true;
  bool write_wrfout_ = false;

  std::chrono::steady_clock::time_point t0_;
  std::chrono::steady_clock::time_point step_start_;
  // output.wrf_timing: WRF's "Timing for main" / "Timing for Writing" lines on stdout (the drop-in wrf.exe's log)
  bool wrf_timing_ = false;
  std::chrono::steady_clock::time_point wrf_tick_;
  bool write_native_restart_ = true;  // restart.native: CPPWRF's own restart_<step>.nc next to the wrfrst files
  void wrf_timing_line(const std::string& what, std::chrono::steady_clock::time_point since) const;

  std::unique_ptr<io::DiagWriter> diag_;
  std::unique_ptr<io::SnapshotWriter> snap_;
  std::unique_ptr<dyn::Diagnostics> dg_;
  std::vector<std::vector<real>> store_;
  std::vector<const Field2*> extra_2d_;
  std::vector<const Field3*> extra_3d_;

#ifdef CPPWRF_HAVE_NETCDF
  std::unique_ptr<WrfHistory> wrfout_;
#endif
};

}  // namespace cppwrf::cases
