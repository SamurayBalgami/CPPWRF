// SPDX-License-Identifier: GPL-3.0-or-later
#include "cases/nest_driver.hpp"

#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <iterator>
#include <map>
#include <sstream>
#include <stdexcept>

#include "core/backend.hpp"
#include "core/constants.hpp"
#include "core/halo.hpp"
#include "core/tiles.hpp"
#include "nest/nest_bdy.hpp"
#include "nest/nest_couple.hpp"
#include "nest/nest_feedback.hpp"
#include "nest/nest_init.hpp"
#include "nest/nest_interp.hpp"

#ifdef CPPWRF_HAVE_NETCDF
#include "io_netcdf/wrf_readers.hpp"
#include <netcdf.h>
#endif

namespace cppwrf::cases {

namespace {

std::string make_dom_tag(int dom_id) {
  char buf[16];
  std::snprintf(buf, sizeof(buf), "d%02d", dom_id);
  return std::string(buf);
}

#ifdef CPPWRF_HAVE_NETCDF
struct BaseParams {
  double t00, p00, a, tiso, a_strat, p_strat;
};

BaseParams read_base_params_nc(const std::string& path) {
  int nc = 0;
  if (nc_open(path.c_str(), NC_NOWRITE, &nc) != NC_NOERR)
    throw std::runtime_error("nest_driver: cannot open " + path);
  auto get = [&](const char* name) {
    int v = 0;
    double x = 0;
    if (nc_inq_varid(nc, name, &v) != NC_NOERR || nc_get_var_double(nc, v, &x) != NC_NOERR) {
      nc_close(nc);
      throw std::runtime_error(std::string("nest_driver: wrfinput lacks base-state parameter ") + name);
    }
    return x;
  };
  BaseParams b{get("T00"), get("P00"), get("TLP"), get("TISO"), get("TLP_STRAT"), get("P_STRAT")};
  nc_close(nc);
  return b;
}

// Re-run WRF start_em base-state, hydrostatic al/p, optional press_adj on mu_2, halo fills,
// and surface w initialization after terrain blending (child, press_adj=true) or feedback (parent, press_adj=false).
void recompute_start_domain(const io::Config& cfg, Model& m, const BaseField2* ht_fine_for_press_adj) {
  const std::string dir = cfg.get_string("real.dir");
  const std::string wi = dir + "/" + cfg.get_string("real.wrfinput", "wrfinput_d01");
  const BaseParams bp = read_base_params_nc(wi);
  const Grid& g = m.g;
  const int nx = g.nx, ny = g.ny, nz = g.nz;
  const int hypso = m.ap.hypsometric_opt;
  dyn::BaseState& b = *m.base;
  dyn::State& s = *m.st;

  // A decomposed run: the worker's buffers laid out as whole fields (tile::local_whole; the points it does not hold
  // are 0 and their columns' results are not used: every column is computed from its own values, and the fills
  // below store the points the worker holds)
  std::vector<real> h_ht;
  const Layout Lht = tile::local_whole(b.ht, h_ht);

  std::vector<double> ht_2d(std::size_t(nx) * ny);
  for (int j = 0; j < ny; ++j)
    for (int i = 0; i < nx; ++i)
      ht_2d[std::size_t(j) * nx + i] = static_cast<double>(h_ht[Lht.index(i, j, 0)]);

  std::vector<double> pb(std::size_t(nx) * ny * nz), alb(pb.size()), t_init(pb.size());
  std::vector<double> mub(std::size_t(nx) * ny), phb(std::size_t(nx) * ny * (nz + 1));
  {
    const double t00 = bp.t00, p00 = bp.p00, a = bp.a, tiso = bp.tiso, a_strat = bp.a_strat, p_strat = bp.p_strat;
    for (int j = 0; j < ny; ++j)
      for (int i = 0; i < nx; ++i) {
        const std::size_t ij = std::size_t(j) * nx + i;
        const double ht = ht_2d[ij];
        const double p_surf =
            p00 * libm::exp(-t00 / a + libm::pow((t00 / a) * (t00 / a) - 2. * cst::g * ht / a / cst::r_d, 0.5));  // **0.5
        for (int k = 0; k < nz; ++k) {
          const std::size_t n = (std::size_t(k) * ny + j) * nx + i;
          pb[n] = double(b.c3h[k]) * (p_surf - b.p_top) + double(b.c4h[k]) + b.p_top;
          double temp = std::max(tiso, t00 + a * libm::log(pb[n] / p00));
          if (pb[n] < p_strat) temp = tiso + a_strat * libm::log(pb[n] / p_strat);
          t_init[n] = temp * libm::pow(p00 / pb[n], cst::r_d / cst::cp) - cst::t0;
          alb[n] = (cst::r_d / cst::p1000mb) * (t_init[n] + cst::t0) * libm::pow(pb[n] / cst::p1000mb, cst::cvpm);
        }
        mub[ij] = p_surf - b.p_top;
        phb[ij] = ht * cst::g;
        for (int k = 1; k <= nz; ++k) {
          const std::size_t n = (std::size_t(k) * ny + j) * nx + i;
          const std::size_t nm = (std::size_t(k - 1) * ny + j) * nx + i;
          if (hypso == 1) {
            phb[n] = phb[nm] - double(b.dnw[k - 1]) * (double(b.c1h[k - 1]) * mub[ij] + double(b.c2h[k - 1])) * alb[nm];
          } else {
            const double pfu = double(b.c3f[k]) * mub[ij] + double(b.c4f[k]) + b.p_top;
            const double pfd = double(b.c3f[k - 1]) * mub[ij] + double(b.c4f[k - 1]) + b.p_top;
            const double phm = double(b.c3h[k - 1]) * mub[ij] + double(b.c4h[k - 1]) + b.p_top;
            phb[n] = phb[nm] + alb[nm] * phm * libm::log(pfd / pfu);
          }
        }
        for (int k = 0; k < nz; ++k) {
          const std::size_t n = (std::size_t(k) * ny + j) * nx + i;
          pb[n] = double(b.c3h[k]) * mub[ij] + double(b.c4h[k]) + b.p_top;
          alb[n] = (cst::r_d / cst::p1000mb) * (t_init[n] + cst::t0) * libm::pow(pb[n] / cst::p1000mb, cst::cvpm);
        }
      }
  }

  auto cl = [](int a, int lo, int hi) { return a < lo ? lo : (a > hi ? hi : a); };
  auto m2 = [&](const std::vector<double>& v) {
    return [&v, nx, ny, cl](int i, int j, int) { return v[std::size_t(cl(j, 0, ny - 1)) * nx + cl(i, 0, nx - 1)]; };
  };
  auto m3 = [&](const std::vector<double>& v, int nk) {
    return [&v, nx, ny, nk, cl](int i, int j, int k) {
      return v[(std::size_t(cl(k, 0, nk - 1)) * ny + cl(j, 0, ny - 1)) * nx + cl(i, 0, nx - 1)];
    };
  };

  b.ht.fill_host_halo(m2(ht_2d));
  b.mub.fill_host_halo(m2(mub));
  b.pb.fill_host_halo(m3(pb, nz));
  b.alb.fill_host_halo(m3(alb, nz));
  b.t_init.fill_host_halo(m3(t_init, nz));
  b.phb.fill_host_halo(m3(phb, nz + 1));

  std::vector<real> h_ph, h_mu, h_thm;
  const Layout Lph = tile::local_whole(s.ph_2, h_ph);
  const Layout Lmu = tile::local_whole(s.mu_2, h_mu);
  const Layout Lm = tile::local_whole(s.t_2, h_thm);

  auto idx3 = [&](int i, int j, int k) { return (std::size_t(k) * ny + j) * nx + i; };
  std::vector<double> al(pb.size()), p(pb.size());
  for (int k = 0; k < nz; ++k)
    for (int j = 0; j < ny; ++j)
      for (int i = 0; i < nx; ++i) {
        const std::size_t n = idx3(i, j, k), n1 = idx3(i, j, k + 1);
        const double mu = static_cast<double>(h_mu[Lmu.index(i, j, 0)]);
        const double mt = mub[std::size_t(j) * nx + i] + mu;
        const double ph0 = static_cast<double>(h_ph[Lph.index(i, j, k)]);
        const double ph1 = static_cast<double>(h_ph[Lph.index(i, j, k + 1)]);
        const double thm = static_cast<double>(h_thm[Lm.index(i, j, k)]);
        double a;
        if (hypso == 2) {
          const double pfu = double(b.c3f[k + 1]) * mt + double(b.c4f[k + 1]) + b.p_top;
          const double pfd = double(b.c3f[k]) * mt + double(b.c4f[k]) + b.p_top;
          const double phm = double(b.c3h[k]) * mt + double(b.c4h[k]) + b.p_top;
          a = (ph1 - ph0 + phb[n1] - phb[n]) / phm / libm::log(pfd / pfu) - alb[n];
        } else {
          // start_em.F:812: (c1h mub + c2h) + c1h mu_1, not c1h (mub + mu_1) + c2h
          const double mb = mub[std::size_t(j) * nx + i];
          a = -1.0 / ((double(b.c1h[k]) * mb + double(b.c2h[k])) + double(b.c1h[k]) * mu) *
              (alb[n] * (double(b.c1h[k]) * mu) + double(b.rdnw[k]) * (ph1 - ph0));
        }
        al[n] = a;
        p[n] = cst::p1000mb * libm::pow((cst::r_d * (cst::t0 + thm)) / (cst::p1000mb * (a + alb[n])), cst::cpovcv) -
               pb[n];
      }

  s.al.fill_host([&](int i, int j, int k) { return al[idx3(i, j, k)]; });
  s.p.fill_host([&](int i, int j, int k) { return p[idx3(i, j, k)]; });

  // start_em.F lines 988-996: IF (press_adj) mu_2(i,j) += al(i,1,j) / (alt(i,1,j) * alb(i,1,j)) * g * (ht - ht_fine)
  if (ht_fine_for_press_adj != nullptr) {
    std::vector<real> h_ht_fine;
    const Layout Lhf = tile::local_whole(*ht_fine_for_press_adj, h_ht_fine);
    std::vector<double> mu_adj(std::size_t(nx) * ny);
    for (int j = 0; j < ny; ++j)
      for (int i = 0; i < nx; ++i) {
        const std::size_t ij = std::size_t(j) * nx + i;
        const std::size_t n0 = idx3(i, j, 0);
        const double mu = static_cast<double>(h_mu[Lmu.index(i, j, 0)]);
        const double htf = static_cast<double>(h_ht_fine[Lhf.index(i, j, 0)]);
        const double alt0 = al[n0] + alb[n0];
        mu_adj[ij] = mu + al[n0] / (alt0 * alb[n0]) * cst::g * (ht_2d[ij] - htf);
      }
    s.mu_2.fill_host([&](int i, int j, int) { return mu_adj[std::size_t(j) * nx + i]; });
  }

  // a decomposed run: the points of the other workers inside this worker's allocation (the host fills above set
  // them from the worker's own copies of the neighbours' columns, which the nest's start has left behind)
  tile::exchange_all();
  fill_halos({&s.u_2, &s.v_2, &s.w_2, &s.t_2, &s.ph_2, &s.al, &s.p}, g);
  fill_halo(s.mu_2, g);
  for (int q = 0; q < s.n_scalars(); ++q) {
    fill_halo(s.q_2[q], g);
    s.q_1[q].copy_from(s.q_2[q]);
  }
  s.u_1.copy_from(s.u_2);
  s.v_1.copy_from(s.v_2);
  s.t_1.copy_from(s.t_2);
  s.ph_1.copy_from(s.ph_2);
  s.mu_1.copy_from(s.mu_2);
  dyn::set_w_surface(s.w_1, s.u_1, s.v_1, b, g, true);
  dyn::set_w_surface(s.w_2, s.u_2, s.v_2, b, g, true);
  tile::exchange_all();  // w's surface values
}
#endif

}  // namespace

bool has_nests(const io::Config& root_cfg) {
  return root_cfg.get_int("domains.max_dom", 1) > 1;
}

std::vector<NestDomainSpec> parse_nest_specs(const io::Config& root_cfg) {
  const int max_dom = static_cast<int>(root_cfg.get_int("domains.max_dom", 1));
  if (max_dom < 1) throw std::runtime_error("domains.max_dom must be >= 1");

  // Mark all [domains] and [d0N] keys accessed on root_cfg (a [d0N] key reaches the domain's configuration below,
  // whose DomainRunner::start() rejects an unknown one); a [domains] key must be one of those read here
  static const char* const kDomainsKeys[] = {"max_dom", "feedback", "smooth_option", "spec_bdy_width", "blend_width",
                                             "parent_id", "i_parent_start", "j_parent_start", "parent_grid_ratio",
                                             "parent_time_step_ratio"};
  for (const std::string& k : root_cfg.keys()) {
    if (k.rfind("domains.", 0) == 0) {
      const std::string n = k.substr(8);
      const bool dom = n.size() > 4 && n[0] == 'd' && std::isdigit(n[1]) && std::isdigit(n[2]) && n[3] == '_';
      if (!dom && std::find(std::begin(kDomainsKeys), std::end(kDomainsKeys), n) == std::end(kDomainsKeys))
        throw std::runtime_error("unknown configuration key '" + k + "'");
    }
    if (k.rfind("domains.", 0) == 0 || (k.size() >= 4 && k[0] == 'd' && std::isdigit(k[1]) && std::isdigit(k[2]) && k[3] == '.')) {
      root_cfg.mark_accessed(k);
    }
  }

  // Noah-MP with nests: WRF 4.8.0 aborts in the nest run's history output (heap corruption in open_w_dataset)
  for (const std::string& k : root_cfg.keys())
    if ((k == "phys.sf_surface_physics" || (k.size() > 18 && k.compare(k.size() - 18, 18, "sf_surface_physics") == 0)) &&
        root_cfg.get_int(k, 0) == 4)
      throw std::runtime_error("nested runs with Noah-MP (sf_surface_physics = 4) are not supported: WRF 4.8.0 aborts");
  // aerosol-aware Thompson: the nest's QNWFA2D / QNIFA2D (Registry "d" / "u") are not interpolated / fed back
  if (max_dom > 1 && root_cfg.get_int("phys.mp_physics", 0) == 28)
    throw std::runtime_error("nested runs with mp_physics = 28 (aerosol-aware Thompson) are not supported");
  const int def_feedback = static_cast<int>(root_cfg.get_int("domains.feedback", 1));
  const int def_smooth = static_cast<int>(root_cfg.get_int("domains.smooth_option", 2));  // WRF Registry default
  const int def_spec_bdy = static_cast<int>(root_cfg.get_int("domains.spec_bdy_width", 5));
  const int def_blend = static_cast<int>(root_cfg.get_int("domains.blend_width", 5));

  std::vector<NestDomainSpec> specs(max_dom);

  for (int id = 1; id <= max_dom; ++id) {
    NestDomainSpec& sp = specs[id - 1];
    sp.dom_id = id;
    sp.tag = make_dom_tag(id);
    const std::string pfx = sp.tag + ".";
    const std::string dpfx = "domains." + sp.tag + "_";

    auto get_int_dom = [&](const std::string& name, int def_val) -> int {
      if (root_cfg.has(pfx + name)) return static_cast<int>(root_cfg.get_int(pfx + name));
      if (root_cfg.has(dpfx + name)) return static_cast<int>(root_cfg.get_int(dpfx + name));
      if (id == 2 && root_cfg.has("domains." + name)) return static_cast<int>(root_cfg.get_int("domains." + name));
      return def_val;
    };

    if (id == 1) {
      sp.parent_id = 0;
      sp.i_parent_start = 1;
      sp.j_parent_start = 1;
      sp.parent_grid_ratio = 1;
      sp.parent_time_step_ratio = 1;
      sp.feedback = def_feedback;
      sp.smooth_option = def_smooth;
    } else {
      sp.parent_id = get_int_dom("parent_id", id - 1);
      if (sp.parent_id < 1 || sp.parent_id >= id)
        throw std::runtime_error("invalid parent_id for domain " + sp.tag);
      sp.i_parent_start = get_int_dom("i_parent_start", 1);
      sp.j_parent_start = get_int_dom("j_parent_start", 1);
      sp.parent_grid_ratio = get_int_dom("parent_grid_ratio", 1);  // Registry defaults
      sp.parent_time_step_ratio = get_int_dom("parent_time_step_ratio", 1);
      sp.feedback = get_int_dom("feedback", def_feedback);
      sp.smooth_option = get_int_dom("smooth_option", def_smooth);
      sp.spec_bdy_width = get_int_dom("spec_bdy_width", def_spec_bdy);
      sp.blend_width = get_int_dom("blend_width", def_blend);
    }

    // Build per-domain io::Config
    std::string ext_cfg_path;
    if (root_cfg.has(pfx + "config")) ext_cfg_path = root_cfg.get_string(pfx + "config");
    else if (root_cfg.has(dpfx + "config")) ext_cfg_path = root_cfg.get_string(dpfx + "config");

    std::vector<std::string> ov;
    double child_dt = 0.0;
    if (id >= 2) {
      const NestDomainSpec& parent_sp = specs[sp.parent_id - 1];
      const double parent_dt = parent_sp.cfg.get_double("time.dt", 60.0);
      child_dt = parent_dt / sp.parent_time_step_ratio;
      const long long parent_out_iv = parent_sp.cfg.get_int("output.out_interval", 1);
      const long long parent_diag_iv = parent_sp.cfg.get_int("output.diag_interval", 10);

      ov.push_back("real.wrfinput=wrfinput_" + sp.tag);
      ov.push_back("real.nested=true");
      // input_wrf.F compares them with the nest's wrfinput (I_PARENT_START, J_PARENT_START)
      ov.push_back("real.i_parent_start=" + std::to_string(sp.i_parent_start));
      ov.push_back("real.j_parent_start=" + std::to_string(sp.j_parent_start));
      ov.push_back("real.spec_bdy_width=" + std::to_string(sp.spec_bdy_width));
      {
        std::ostringstream oss;
        oss.precision(17);
        oss << "time.dt=" << child_dt;
        ov.push_back(oss.str());
        // the clock's step: the parent's / parent_time_step_ratio exactly (set_timekeeping.F:365-367), whose
        // denominator the model reads (Model::dt_clock)
        ov.push_back("time.dt_den=" + std::to_string(parent_sp.cfg.get_int("time.dt_den", 1) * sp.parent_time_step_ratio));
      }
      // check_a_mundo: a nest's namelist dx / dy is dx(1) / dy(1) over the accumulated parent_grid_ratio
      // (get_moad_factor), whatever the namelist gives; input_wrf compares the nest's wrfinput with it
      int factor = sp.parent_grid_ratio;
      for (int p = sp.parent_id; p > 1; p = specs[p - 1].parent_id) factor *= specs[p - 1].parent_grid_ratio;
      for (const char* k : {"real.dx", "real.dy"})
        if (root_cfg.has(k)) {
          std::ostringstream oss;
          oss.precision(17);
          oss << k << "=" << root_cfg.get_double(k) / double(factor);
          ov.push_back(oss.str());
        }
      ov.push_back("output.out_interval=" + std::to_string(parent_out_iv * sp.parent_time_step_ratio));
      ov.push_back("output.diag_interval=" + std::to_string(parent_diag_iv * sp.parent_time_step_ratio));
      // a resumed run: this domain's restart file next to the root's (wrfrst_d01_<date> -> wrfrst_d0N_<date>)
      const std::string rf = root_cfg.get_string("run.restart_file", "");
      const std::string key = "wrfrst_d01_";
      const std::size_t at = rf.rfind(key);
      if (!rf.empty()) {
        if (at == std::string::npos)
          throw std::runtime_error("nested runs resume from WRF restart files (run.restart_file = wrfrst_d01_<date>)");
        ov.push_back("run.restart_file=" + rf.substr(0, at) + "wrfrst_" + sp.tag + "_" + rf.substr(at + key.size()));
      }
    }

    // Map shorthand keys in [d0N] or domains.d0N_* to standard Model/DomainRunner sections
    auto map_key = [&](const std::string& sub, const std::string& val) {
      if (sub == "config" || sub == "parent_id" || sub == "i_parent_start" || sub == "j_parent_start" ||
          sub == "parent_grid_ratio" || sub == "parent_time_step_ratio" || sub == "feedback" ||
          sub == "smooth_option" || sub == "blend_width") {
        return;
      }
      if (sub == "spec_bdy_width") ov.push_back("real.spec_bdy_width=" + val);
      else if (sub == "wrfinput" || sub == "wrfbdy" || sub == "dir" || sub == "bdy_interval" || sub == "nested" ||
               sub == "e_we" || sub == "e_sn" || sub == "e_vert" || sub == "wrflowinp" || sub == "wrffdda")
        ov.push_back("real." + sub + "=" + val);
      else if (sub == "dt" && id >= 2 && std::abs(std::stod(val) - child_dt) > 1e-9 * child_dt)
        // WRF: a nest's time step is its parent's divided by parent_time_step_ratio (the namelist value is ignored)
        throw std::runtime_error(sp.tag + ".dt = " + val + " differs from the parent's dt / parent_time_step_ratio");
      else if (sub == "dt" || sub == "time_step_sound")
        ov.push_back("time." + sub + "=" + val);
      else if (sub == "out_interval" || sub == "diag_interval" || sub == "format" || sub == "out_dir" || sub == "restart_interval")
        ov.push_back("output." + (sub == "out_dir" ? std::string("dir") : sub) + "=" + val);
      else if (sub == "nx" || sub == "ny" || sub == "nz" || sub == "dx" || sub == "dy")
        ov.push_back("domain." + sub + "=" + val);
      else if (sub.rfind("phys_", 0) == 0)  // per-domain physics (WRF max_domains options: cu_physics, radt, ...)
        ov.push_back("phys." + sub.substr(5) + "=" + val);
      else if (sub.rfind("fdda_", 0) == 0)  // per-domain grid nudging (&fdda max_domains options)
        ov.push_back("fdda." + sub.substr(5) + "=" + val);
      else if (sub.find('.') != std::string::npos)
        ov.push_back(sub + "=" + val);
      else
        ov.push_back("dyn." + sub + "=" + val);
    };

    for (const std::string& k : root_cfg.keys()) {
      if (k.rfind(pfx, 0) == 0) {
        map_key(k.substr(pfx.size()), root_cfg.get_string(k));
      } else if (k.rfind(dpfx, 0) == 0) {
        map_key(k.substr(dpfx.size()), root_cfg.get_string(k));
      }
    }

    if (!ext_cfg_path.empty()) {
      sp.cfg = io::Config::load(ext_cfg_path, ov);
    } else {
      // Serialize non-domain-specific keys from root_cfg as base INI
      std::ostringstream base_ini;
      for (const std::string& k : root_cfg.keys()) {
        if (k.rfind("domains.", 0) == 0) continue;
        if (k.size() >= 4 && k[0] == 'd' && std::isdigit(k[1]) && std::isdigit(k[2]) && k[3] == '.') continue;
        if (id >= 2 && (k == "real.wrfbdy" || k == "real.bdy_interval" || k == "real.dx" || k == "real.dy" ||
                        k == "real.e_we" || k == "real.e_sn" || k == "real.e_vert" || k == "real.wrflowinp" ||
                        k == "real.wrffdda"))
          continue;  // domain 1's (a nest's come from its [d0N] section)
        auto dot = k.find('.');
        if (dot != std::string::npos) {
          base_ini << "[" << k.substr(0, dot) << "]\n" << k.substr(dot + 1) << " = " << root_cfg.get_string(k) << "\n";
        }
      }
      sp.cfg = io::Config::from_string(base_ini.str(), ov);
    }
    if (sp.cfg.has("output.dir")) sp.cfg.mark_accessed("output.dir");
  }

  // med_restart_out writes every domain when d01's restart alarm rings (restart_interval is one value); each
  // domain's own alarm (DomainRunner) rings at those times only when the interval is a multiple of d01's dt
  auto rst_interval = [](const io::Config& c) {
    return c.get_double("restart.interval", c.get_double("output.restart_interval", 0.0));
  };
  const double rst1 = rst_interval(specs[0].cfg), dt1 = specs[0].cfg.get_double("time.dt", 60.0);
  for (const NestDomainSpec& sp : specs)
    if (rst_interval(sp.cfg) != rst1)
      throw std::runtime_error(sp.tag + ": the restart interval differs from d01's (WRF's restart_interval is one value)");
  if (rst1 > 0 && std::abs(rst1 / dt1 - std::round(rst1 / dt1)) > 1e-9 * (rst1 / dt1))
    throw std::runtime_error("nested runs: the restart interval must be a multiple of d01's time.dt");

  return specs;
}

void med_nest_initial(const io::Config& parent_cfg, Model& parent,
                      const NestDomainSpec& child_spec, Model& child) {
#ifndef CPPWRF_HAVE_NETCDF
  (void)parent_cfg; (void)parent; (void)child_spec; (void)child;
  throw std::runtime_error("med_nest_initial requires NetCDF support");
#else
  const Grid& cg = child.g;
  const int nx = cg.nx, ny = cg.ny, nz = cg.nz;
  const int ipos = child_spec.i_parent_start;
  const int jpos = child_spec.j_parent_start;
  const int nri = child_spec.parent_grid_ratio;
  const int nrj = child_spec.parent_grid_ratio;

  // 1. med_interp_domain(parent, child): SINT-interpolate parent ht, mub, phb onto child
  BaseField2 ht_int(cg, Stagger::M, "ht_int", false), mub_int(cg, Stagger::M, "mub_int", false);
  BaseField3 phb_int(cg, Stagger::W, "phb_int", false);
  {
    const tile::Use use(cg);  // the nest's patch; the parent's fields as wholes
    const nest::WholeField<2> p_ht(parent.base->ht), p_mub(parent.base->mub);
    const nest::WholeField<3> p_phb(parent.base->phb);
    auto c_ht = nest::const_view2(p_ht);
    auto n_ht = nest::mut_view2(ht_int);
    parallel_for(Range3D{0, nx, 0, ny, 0, 1},
                 nest::KSintView2D<decltype(c_ht), decltype(n_ht)>{c_ht, n_ht, ipos, jpos, nri, nrj, false, false});

    auto c_mub = nest::const_view2(p_mub);
    auto n_mub = nest::mut_view2(mub_int);
    parallel_for(Range3D{0, nx, 0, ny, 0, 1},
                 nest::KSintView2D<decltype(c_mub), decltype(n_mub)>{c_mub, n_mub, ipos, jpos, nri, nrj, false, false});

    auto c_phb = nest::const_view3(p_phb);
    auto n_phb = nest::mut_view3(phb_int);
    parallel_for(Range3D{0, nx, 0, ny, 0, nz + 1},
                 nest::KSintView3D<decltype(c_phb), decltype(n_phb)>{c_phb, n_phb, ipos, jpos, nri, nrj, false, false});
  }

  // 2. Load raw wrfinput_d0N fields (before start_domain(child) recomputes base state / w)
  const std::string dir = child_spec.cfg.get_string("real.dir");
  const std::string wi = dir + "/" + child_spec.cfg.get_string("real.wrfinput", "wrfinput_" + child_spec.tag);
  // a decomposed run reads the worker's patch and halo of the 3-D variables
  const io_netcdf::WrfInputData d = io_netcdf::read_wrfinput(wi, [](int fnx, int fny) {
    if (!tile::tiled()) return io_netcdf::Window{};
    const tile::PatchBox w = tile::input_window(fnx, fny);
    return io_netcdf::Window{w.i0, w.i1, w.j0, w.j1};
  });

  auto cl = [](int a, int lo, int hi) { return a < lo ? lo : (a > hi ? hi : a); };
  auto m2 = [&](const std::vector<double>& v) {
    return [&v, nx, ny, cl](int i, int j, int) { return v[std::size_t(cl(j, 0, ny - 1)) * nx + cl(i, 0, nx - 1)]; };
  };
  auto m3 = [&](const io_netcdf::WArray& v, int nk) {
    return [&v, nx, ny, nk, cl](int i, int j, int k) {
      return v[(std::size_t(cl(k, 0, nk - 1)) * ny + cl(j, 0, ny - 1)) * nx + cl(i, 0, nx - 1)];
    };
  };

  BaseField2 ht_fine(cg, Stagger::M, "ht_fine", false), save_mub(cg, Stagger::M, "save_mub", false);
  ht_fine.fill_host_halo(m2(d.hgt));
  save_mub.fill_host_halo(m2(d.mub));

  child.base->ht.fill_host_halo(m2(d.hgt));
  child.base->mub.fill_host_halo(m2(d.mub));
  child.base->phb.fill_host_halo(m3(d.phb, nz + 1));
  child.base->pb.fill_host_halo(m3(d.pb, nz));
  child.base->alb.fill_host_halo(m3(d.alb, nz));

  // p: kept from the child's own start (WRF: med_initialdata_input runs start_domain(nest) after reading
  // wrfinput, which recomputes p from theta_m and al before adjust_tempqv)
  child.st->w_2.fill_host([](int, int, int) { return 0.0; });
  child.st->w_1.fill_host([](int, int, int) { return 0.0; });

  // 3. blend_terrain(ht, mub, phb) when the nest's input says save_topo_from_real = 1 (Registry i02: read from
  // wrfinput_d0N; 0 when the variable is missing; real.exe writes 1, wrf.exe 0)
  int save_topo_from_real = 0;
  {
    int nc = 0, v = 0;
    if (nc_open(wi.c_str(), NC_NOWRITE, &nc) == NC_NOERR) {
      if (nc_inq_varid(nc, "SAVE_TOPO_FROM_REAL", &v) == NC_NOERR) nc_get_var_int(nc, v, &save_topo_from_real);
      nc_close(nc);
    }
  }
  const tile::Use use_child(cg);
  if (save_topo_from_real == 1) {
    nest::blend_terrain_field2(ht_int, child.base->ht, nx, ny, child_spec.spec_bdy_width, child_spec.blend_width);
    nest::blend_terrain_field2(mub_int, child.base->mub, nx, ny, child_spec.spec_bdy_width, child_spec.blend_width);
    nest::blend_terrain_field3(phb_int, child.base->phb, nx, ny, nz + 1, child_spec.spec_bdy_width,
                               child_spec.blend_width);
  }

  // 4. adjust_tempqv on child t_2 and qv
  const int use_theta_m = child.st->P_QV >= 0 ? 1 : 0;
  if (child.st->P_QV >= 0) {
    nest::adjust_tempqv_fields(child.base->mub, save_mub, child.base->c3h, child.base->c4h, child.base->p_top,
                               child.st->t_2, child.st->p, child.st->q_2[child.st->P_QV], use_theta_m, nx, ny, nz);
  }

  // 5. If feedback != 0, med_nest_feedback(parent, child) runs BEFORE start_domain(child) and start_domain(parent)
  if (child_spec.feedback != 0) {
    med_nest_feedback(parent, child, child_spec);
  }

  // 6. start_domain(child) with press_adj = true
  recompute_start_domain(child_spec.cfg, child, &ht_fine);

  // 7. start_domain(parent) with press_adj = false
  {
    const tile::Use use_parent(parent.g);
    recompute_start_domain(parent_cfg, parent, nullptr);
  }
  dev_sync();
#endif
}

namespace {
// u, v, w, ph, t and the scalars of a domain, batched (one launch per direction for 8 fields; the same values as
// filling them one by one)
void fill_state_halos(dyn::State& st, const Grid& g) {
  std::vector<Field3*> fs{&st.u_2, &st.v_2, &st.w_2, &st.ph_2, &st.t_2};
  for (int s = 0; s < st.n_scalars(); ++s) fs.push_back(&st.q_2[s]);
  fill_halos(fs, g);
}
}  // namespace

void med_nest_force(Model& parent, Model& child, const NestDomainSpec& child_spec) {
  const Grid& pg = parent.g;
  const Grid& cg = child.g;
  const int ipos = child_spec.i_parent_start;
  const int jpos = child_spec.j_parent_start;
  const int nri = child_spec.parent_grid_ratio;
  const int nrj = child_spec.parent_grid_ratio;
  const double cdt = pg.dt;

  // A decomposed run (nest/nest_whole.hpp): each domain's kernels run on its own patch (tile::Use). Of the boundary
  // slabs (whole edges on every worker) a worker computes the entries of the nest's points it holds (its patch and
  // halo: the boundary kernels read the entries of a point's neighbours), from the nest's own field, whose halo is
  // exchanged first, and from the box of the parent's field under those points (the 5 x 5 stencil included).
  const int cdom = cg.dom, cnx = cg.nx, cny = cg.ny;
  const std::function<tile::PatchBox(int)> pbox = [=](int t) {
    const tile::PatchBox c = tile::patch(cdom, t);
    const int h = Grid::halo;
    const int i0 = std::max(0, c.i0 - h), i1 = std::min(cnx + 1, c.i1 + h + 1);
    const int j0 = std::max(0, c.j0 - h), j1 = std::min(cny + 1, c.j1 + h + 1);
    return tile::PatchBox{(ipos - 1) + i0 / nri - 3, (ipos - 1) + (i1 + nri) / nri + 4, (jpos - 1) + j0 / nrj - 3,
                          (jpos - 1) + (j1 + nrj) / nrj + 4};
  };
  // 1. Couple parent in-place
  {
    const tile::Use use(pg);
    // mu_2's halo is left as the dycore's halo schedule had it (WRF's uncouple reads it at ids/jds); the points of
    // it that another worker owns are that worker's values, as in a run with one patch (the staggered couplings
    // average mu_2 across the patch's edge)
    nest::exchange_field(parent.st->mu_2);
    nest::couple_or_uncouple_state(pg, *parent.st, *parent.base, true);
    fill_state_halos(*parent.st, pg);
  }

  // 2. Couple child in-place
  {
    const tile::Use use(cg);
    nest::exchange_field(child.st->mu_2);
    nest::couple_or_uncouple_state(cg, *child.st, *child.base, true);
  }

  // 3. Interpolate parent -> child LateralBC slabs (bdy_interp1 / KBdySlabView3D / KBdySlabView2D)
  dyn::LateralBC& lbc = *child.bc;
  {
    const tile::Whole whole;
    auto force3 = [&](dyn::LateralBC::Var v, const Field3& pf, const Field3& cf) {
      nest::exchange_field(cf);
      const nest::WholeField<3> P(pf, pbox);
      nest::force_nest_bdy_field3(lbc, v, P, cf, cg.nx, cg.ny, ipos, jpos, nri, nrj, cdt);
    };
    force3(dyn::LateralBC::U, parent.st->u_2, child.st->u_2);
    force3(dyn::LateralBC::V, parent.st->v_2, child.st->v_2);
    force3(dyn::LateralBC::W, parent.st->w_2, child.st->w_2);
    force3(dyn::LateralBC::PH, parent.st->ph_2, child.st->ph_2);
    force3(dyn::LateralBC::T, parent.st->t_2, child.st->t_2);
    {
      const nest::WholeField<2> P(parent.st->mu_2, pbox);  // the nest's mu_2: exchanged before the coupling
      nest::force_nest_bdy_field2(lbc, dyn::LateralBC::MU, P, child.st->mu_2, cg.nx, cg.ny, ipos, jpos, nri, nrj, cdt);
    }
    const int n_scalars = std::min(parent.st->n_scalars(), child.st->n_scalars());
    for (int s = 0; s < n_scalars; ++s) {
      // Registry: tke has no f (force) flag - the nest keeps flow-dependent boundaries for it (solve_em)
      if (s == child.st->P_TKE) continue;
      nest::exchange_field(child.st->q_2[s]);
      const nest::WholeField<3> P(parent.st->q_2[s], pbox);
      nest::force_nest_bdy_scalar_field3(lbc, s, P, child.st->q_2[s], cg.nx, cg.ny, cg.nz, ipos, jpos, nri, nrj, cdt);
    }
  }
  lbc.dtbc = 0.0;

  // o3rad (Registry rdf=(p2c)): the child's whole field from the parent's, which only domain 1 computes
  if (parent.suite && child.suite && parent.suite->radiation() && child.suite->radiation()) {
    {
      const tile::Use use(pg);
      fill_halo(parent.suite->o3rad, pg);
    }
    const tile::Use use(cg);
    const nest::WholeField<3> p_o3(parent.suite->o3rad, pbox);
    auto c_o3 = nest::const_view3(p_o3);
    auto n_o3 = nest::mut_view3(child.suite->o3rad);
    parallel_for(Range3D{0, cg.nx, 0, cg.ny, 0, cg.nz},
                 nest::KSintView3D<decltype(c_o3), decltype(n_o3)>{c_o3, n_o3, ipos, jpos, nri, nrj, false, false});
    nest::exchange_field(child.suite->o3rad);
  }

  // 4. Uncouple child and parent in-place (preserving exact reciprocal-multiply roundoff)
  {
    const tile::Use use(cg);
    nest::couple_or_uncouple_state(cg, *child.st, *child.base, false);
  }
  {
    const tile::Use use(pg);
    nest::couple_or_uncouple_state(pg, *parent.st, *parent.base, false);
  }
  {
    const tile::Use use(cg);
    fill_state_halos(*child.st, cg);
  }
  const tile::Use use(pg);
  fill_state_halos(*parent.st, pg);
}

void med_nest_feedback(Model& parent, const Model& child, const NestDomainSpec& child_spec,
                       nest::FeedbackScratch* scratch) {
  const Grid& pg = parent.g;
  const Grid& cg = child.g;
  const int n_nx = cg.nx, n_ny = cg.ny, n_nz = cg.nz;
  const int ipos = child_spec.i_parent_start;
  const int jpos = child_spec.j_parent_start;
  const int nri = child_spec.parent_grid_ratio;
  const int nrj = child_spec.parent_grid_ratio;
  const int sm = child_spec.smooth_option;

  // a decomposed run: the parent's patch; of each nest field the box over that patch (nest/nest_whole.hpp): the
  // nest's points inside the parent's cells of the patch and two cells around it
  const tile::Use use(pg);
  const int pdom = pg.dom;
  const std::function<tile::PatchBox(int)> cbox = [=](int t) {
    const tile::PatchBox p = tile::patch(pdom, t);
    return tile::PatchBox{(p.i0 - (ipos - 1) - 2) * nri, (p.i1 - (ipos - 1) + 2) * nri, (p.j0 - (jpos - 1) - 2) * nrj,
                          (p.j1 - (jpos - 1) + 2) * nrj};
  };
  auto W3 = [&](const auto& f) { return nest::WholeField<3>(f, cbox); };
  auto W2 = [&](const auto& f) { return nest::WholeField<2>(f, cbox); };
  // Note: WRF med_feedback_domain operates directly on UNCOUPLED fields (no couple_or_uncouple_em call)
  nest::feedback_field3(pg, parent.st->u_2, W3(child.st->u_2), n_nx, n_ny, n_nz, ipos, jpos, nri, nrj, true, false, sm, 1, scratch);
  nest::feedback_field3(pg, parent.st->v_2, W3(child.st->v_2), n_nx, n_ny, n_nz, ipos, jpos, nri, nrj, false, true, sm, 1, scratch);
  nest::feedback_field3(pg, parent.st->w_2, W3(child.st->w_2), n_nx, n_ny, n_nz + 1, ipos, jpos, nri, nrj, false, false, sm, 1, scratch);
  nest::feedback_field3(pg, parent.st->ph_2, W3(child.st->ph_2), n_nx, n_ny, n_nz + 1, ipos, jpos, nri, nrj, false, false, sm, 1, scratch);
  nest::feedback_field3(pg, parent.st->t_2, W3(child.st->t_2), n_nx, n_ny, n_nz, ipos, jpos, nri, nrj, false, false, sm, 1, scratch);
  nest::feedback_field2(pg, parent.st->mu_2, W2(child.st->mu_2), n_nx, n_ny, ipos, jpos, nri, nrj, sm, 1, scratch);

  const int n_scalars = std::min(parent.st->n_scalars(), child.st->n_scalars());
  for (int s = 0; s < n_scalars; ++s) {
    if (s == parent.st->P_TKE) continue;  // tke is not fed back (Registry: no u flag)
    nest::feedback_field3(pg, parent.st->q_2[s], W3(child.st->q_2[s]), n_nx, n_ny, n_nz, ipos, jpos, nri, nrj, false, false, sm, 1, scratch);
  }

  // Base-state fields fed back in inc/nest_feedbackup_interp.inc; inc/nest_feedbackup_smooth.inc smooths them
  // and ht as well (map factors, f, e, sina, cosa are fed back without smoothing)
  nest::feedback_field3(pg, parent.base->phb, W3(child.base->phb), n_nx, n_ny, n_nz + 1, ipos, jpos, nri, nrj, false, false, sm, 1, scratch);
  nest::feedback_field2(pg, parent.base->mub, W2(child.base->mub), n_nx, n_ny, ipos, jpos, nri, nrj, sm, 1, scratch);
  nest::feedback_field3(pg, parent.base->alb, W3(child.base->alb), n_nx, n_ny, n_nz, ipos, jpos, nri, nrj, false, false, sm, 1, scratch);
  nest::feedback_field3(pg, parent.base->pb, W3(child.base->pb), n_nx, n_ny, n_nz, ipos, jpos, nri, nrj, false, false, sm, 1, scratch);
  nest::feedback_field2(pg, parent.base->ht, W2(child.base->ht), n_nx, n_ny, ipos, jpos, nri, nrj, sm, 1, scratch);

  if (parent.base->mapped && child.base->mapped) {
    nest::feedback_field2_fcnm(parent.base->msftx, W2(child.base->msftx), n_nx, n_ny, ipos, jpos, nri, nrj, false, false);
    nest::feedback_field2_fcnm(parent.base->msfty, W2(child.base->msfty), n_nx, n_ny, ipos, jpos, nri, nrj, false, false);
    nest::feedback_field2_fcnm(parent.base->msfux, W2(child.base->msfux), n_nx, n_ny, ipos, jpos, nri, nrj, true, false);
    nest::feedback_field2_fcnm(parent.base->msfuy, W2(child.base->msfuy), n_nx, n_ny, ipos, jpos, nri, nrj, true, false);
    nest::feedback_field2_fcnm(parent.base->msfvx, W2(child.base->msfvx), n_nx, n_ny, ipos, jpos, nri, nrj, false, true);
    nest::feedback_field2_fcnm(parent.base->msfvx_inv, W2(child.base->msfvx_inv), n_nx, n_ny, ipos, jpos, nri, nrj, false, true);
    nest::feedback_field2_fcnm(parent.base->msfvy, W2(child.base->msfvy), n_nx, n_ny, ipos, jpos, nri, nrj, false, true);
    nest::feedback_field2_fcnm(parent.base->f, W2(child.base->f), n_nx, n_ny, ipos, jpos, nri, nrj, false, false);
    nest::feedback_field2_fcnm(parent.base->e, W2(child.base->e), n_nx, n_ny, ipos, jpos, nri, nrj, false, false);
    nest::feedback_field2_fcnm(parent.base->sina, W2(child.base->sina), n_nx, n_ny, ipos, jpos, nri, nrj, false, false);
    nest::feedback_field2_fcnm(parent.base->cosa, W2(child.base->cosa), n_nx, n_ny, ipos, jpos, nri, nrj, false, false);
  }

  // update_after_feedback_em: only a DM halo exchange in WRF (no-op on one task): the parent's halos
  // keep their values (the dycore refreshes them on WRF's schedule)
}

int run_nested(const io::Config& root_cfg, const std::string& out_dir) {
  // A decomposed run: a domain's launches are clipped to the worker's patch of that domain (tile::Use); tiles run
  // the host code one at a time (tile::Serial), released for the time steps.
  tile::Serial serial;
  // adapt_timestep's nest branches (the child's dt from the parent's, adaptation_domain) are not ported
  if (root_cfg.get_bool("time.adaptive", false))
    throw std::runtime_error("time.adaptive (WRF use_adaptive_time_step) with nests is not supported");
  std::vector<NestDomainSpec> specs = parse_nest_specs(root_cfg);
  const int max_dom = static_cast<int>(specs.size());

  struct DomInstance {
    NestDomainSpec spec;
    Model model;
    std::unique_ptr<DomainRunner> runner;
    std::vector<int> children;  // 0-based indices into doms
    nest::FeedbackScratch fb_scratch;  // the feedback smoothers' temporaries on this domain (a parent) grid
    long step = 0;
    bool started = false;
  };

  std::vector<DomInstance> doms(max_dom);
  for (int i = 0; i < max_dom; ++i) {
    doms[i].spec = std::move(specs[i]);
    if (doms[i].spec.parent_id > 0) {
      doms[doms[i].spec.parent_id - 1].children.push_back(i);
    }
  }

  // 1. Build all domains; med_nest_initial of domain 1's children (WRF nests_to_open at the top of domain 1's
  // first step, before its t = 0 output). Deeper nests open at their parent's first step (open_children below).
  for (int i = 0; i < max_dom; ++i) {
    doms[i].model = Model::build(doms[i].spec.cfg);
  }
  // A resumed run opens every nest before the restart files are read (they overwrite the initial state).
  const bool resumed = !root_cfg.get_string("run.restart_file", "").empty();
  std::vector<bool> opened(max_dom, false);
  for (int i = 0; i < max_dom; ++i)
    if (i == 0 || resumed)
      for (int c_idx : doms[i].children) {
        med_nest_initial(doms[i].spec.cfg, doms[i].model, doms[c_idx].spec, doms[c_idx].model);
        opened[c_idx] = true;
      }

  // 2. Create DomainRunner per domain (out_dir/d01, out_dir/d02, ...)
  for (int i = 0; i < max_dom; ++i) {
    std::string dom_out = out_dir + "/" + doms[i].spec.tag;
    const tile::Use use(doms[i].model.g);
    doms[i].runner = std::make_unique<DomainRunner>(doms[i].spec.cfg, doms[i].model, dom_out, doms[i].spec.tag);
    if (doms[i].spec.parent_id > 0) doms[i].runner->set_defer_output(true);
  }

#ifdef CPPWRF_HAVE_NETCDF
  // med_nest_initial's feedback (feedback != 0) of the history fields the model does not carry
  for (int i = 0; i < max_dom; ++i)
    for (int c_idx : doms[i].children)
      if (doms[c_idx].spec.feedback != 0) {
        doms[i].runner->set_need_history(true);
        doms[c_idx].runner->set_need_history(true);
      }
  for (int i = 0; i < max_dom; ++i) {
    const tile::Use use(doms[i].model.g);
    doms[i].runner->prepare_output();
  }
#endif
  // med_nest_initial: parent%ht_coarse = parent%ht; its feedback (feedback != 0) of the history fields the model
  // does not carry, then start_domain(parent) (start_em, topo_wind = 0): CTOPO = CTOPO2 = 1 again (the fed-back
  // average of ones is 1 + 1 ulp)
  auto initial_history_feedback = [&](int i, int c_idx) {
#ifdef CPPWRF_HAVE_NETCDF
    if (doms[i].runner->history()) doms[i].runner->history()->keep_ht_coarse();
#endif
    if (doms[c_idx].spec.feedback == 0) return;
#ifdef CPPWRF_HAVE_NETCDF
    if (doms[i].runner->history() && doms[c_idx].runner->history()) {
      const NestDomainSpec& cs = doms[c_idx].spec;
      doms[i].runner->history()->feedback_physics(*doms[c_idx].runner->history(), cs.i_parent_start,
                                                  cs.j_parent_start, cs.parent_grid_ratio);
      doms[i].runner->history()->feedback_from(*doms[c_idx].runner->history(), cs.i_parent_start,
                                               cs.j_parent_start, cs.parent_grid_ratio);
    }
#endif
    if (doms[i].model.suite) {
      doms[i].model.suite->ctopo.fill_host([](int, int, int) { return 1.0; });
      doms[i].model.suite->ctopo2.fill_host([](int, int, int) { return 1.0; });
    }
  };
  for (int i = 0; i < max_dom; ++i)
    for (int c_idx : doms[i].children)
      if (opened[c_idx]) initial_history_feedback(i, c_idx);
  // nests_to_open(grid) at the top of grid's first step: after med_nest_force(parent, grid), before grid's t = 0
  // output and its first solve
  auto open_children = [&](int idx) {
    for (int c_idx : doms[idx].children)
      if (!opened[c_idx]) {
        med_nest_initial(doms[idx].spec.cfg, doms[idx].model, doms[c_idx].spec, doms[c_idx].model);
        initial_history_feedback(idx, c_idx);
#ifdef CPPWRF_HAVE_NETCDF
        for (int d : {c_idx, idx})
          if (doms[d].runner->history()) doms[d].runner->history()->restart_slopes();
#endif
        opened[c_idx] = true;
      }
  };

  // a domain's start in its patch; then every field's halo from the other workers (the start sets fields on the host)
  auto start = [&](int i) {
    const tile::Use use(doms[i].model.g);
    const bool ok = doms[i].runner->start();
    tile::exchange_all();
    return ok;
  };
  // 3. Root domain (d01) writes its t=0 initial frame before its first step
  if (!start(0)) return 3;
  doms[0].started = true;
  doms[0].step = doms[0].runner->start_step;
  // a resumed run: the nests read their restart files before the first med_nest_force, which takes the
  // nest's boundary tendencies from its current state (no initial frames are written)
  if (doms[0].step > 0)
    for (int i = 1; i < max_dom; ++i) {
      if (!start(i)) return 3;
      doms[i].started = true;
      doms[i].step = doms[i].runner->start_step;
    }

  auto feedback = [&](DomInstance& d, DomInstance& c) {
    if (c.spec.feedback == 0) return;
    med_nest_feedback(d.model, c.model, c.spec, &d.fb_scratch);
    dev_sync();
#ifdef CPPWRF_HAVE_NETCDF
    if (d.runner->history() && c.runner->history()) {  // the physics state, then history-only fields (Registry u=)
      d.runner->history()->feedback_physics(*c.runner->history(), c.spec.i_parent_start, c.spec.j_parent_start,
                                            c.spec.parent_grid_ratio);
      d.runner->history()->feedback_from(*c.runner->history(), c.spec.i_parent_start, c.spec.j_parent_start,
                                         c.spec.parent_grid_ratio);
    }
#endif
  };

  // Recursive WRF integrate (frame/module_integrate.F), one step of dom_idx:
  //   - solve dom_idx
  //   - med_nest_force(dom_idx, c) for every child c
  //   - for every child c: c's first step opens c's own children (nests_to_open) and writes c's t = 0 frame
  //     (after the first med_nest_force, as in WRF); parent_time_step_ratio steps of c
  //   - med_nest_feedback(dom_idx, c) for every child c. In the run's last step (domain 1 at its stop time) WRF
  //     skips this loop and each nest feeds back at the end of its own integrate (should_do_last_io), i.e. before
  //     its next sibling is integrated.
  //   - dom_idx.runner->after_step(step) (writes the parent's history frame after the feedback, as in WRF)
  std::function<bool(int)> advance_domain = [&](int idx) -> bool {
    DomInstance& d = doms[idx];
    const long n = ++d.step;
    {
      const tile::Use use(d.model.g);
      d.runner->before_step(n);
      serial.unlock();
      d.model.rk->step(*d.model.st, *d.model.tend, *d.model.base);
      serial.lock();
      d.runner->after_solve(n);
    }
    // CUDA graphs: no wait per step (one stream; every read of device data waits), except in the run's last
    // root step (the stepping times end with the device's work)
    const bool wait = !step_graphs_on() || doms[0].step == doms[0].model.nsteps;
    if (wait) dev_sync();

    for (int c_idx : d.children) {
      med_nest_force(d.model, doms[c_idx].model, doms[c_idx].spec);
      if (wait) dev_sync();
    }
    const bool stop_time = doms[0].step == doms[0].model.nsteps;
    for (int c_idx : d.children) {
      DomInstance& c = doms[c_idx];
      if (!c.started) {
        open_children(c_idx);
        if (!start(c_idx)) return false;
        c.started = true;
        c.step = c.runner->start_step;
      }
      const int ratio = c.spec.parent_time_step_ratio;
      for (int sub = 0; sub < ratio; ++sub) {
        if (!advance_domain(c_idx)) return false;
      }
      if (stop_time) feedback(d, c);
    }
    if (!stop_time)
      for (int c_idx : d.children) feedback(d, doms[c_idx]);

    const tile::Use use(d.model.g);
    if (!d.runner->after_step(n)) return false;
    return true;
  };

  // If run_time == 0 (0 steps), still start child runners after an initial force so t=0 snapshots exist
  if (doms[0].model.nsteps == doms[0].runner->start_step) {
    for (int i = 0; i < max_dom; ++i) {
      for (int c_idx : doms[i].children) {
        DomInstance& c = doms[c_idx];
        med_nest_force(doms[i].model, c.model, c.spec);
        dev_sync();
        if (!c.started) {
          open_children(c_idx);
          if (!start(c_idx)) return 3;
          c.started = true;
        }
      }
    }
  } else {
    const long total_root_steps = doms[0].model.nsteps;
    while (doms[0].step < total_root_steps) {
      if (!advance_domain(0)) return 3;
    }
  }

  for (int i = 0; i < max_dom; ++i) {
    const tile::Use use(doms[i].model.g);
    if (doms[i].started) doms[i].runner->finish();
  }

  return 0;
}

}  // namespace cppwrf::cases
