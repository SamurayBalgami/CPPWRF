# SPDX-License-Identifier: GPL-3.0-or-later
cmake_minimum_required(VERSION 3.24)
project(CPPWRF VERSION 1.0.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release CACHE STRING "" FORCE)
endif()

option(CPPWRF_DOUBLE "Use double precision (real = double)" OFF)
include(CheckLanguage)
check_language(CUDA)
if(CMAKE_CUDA_COMPILER)
  set(_cuda_default ON)
else()
  set(_cuda_default OFF)
endif()
option(CPPWRF_ENABLE_CUDA "Build the CUDA backend" ${_cuda_default})

if(CPPWRF_ENABLE_CUDA)
  if(NOT DEFINED CMAKE_CUDA_ARCHITECTURES)
    set(CMAKE_CUDA_ARCHITECTURES native)  # the GPU of the build machine; pass e.g. 80;90 for servers
  endif()
  enable_language(CUDA)
  set(CMAKE_CUDA_STANDARD 20)
  set(CMAKE_CUDA_STANDARD_REQUIRED ON)
  find_package(CUDAToolkit REQUIRED)
else()
  find_package(OpenMP REQUIRED COMPONENTS CXX)
endif()

# Strict IEEE: no fast-math anywhere (determinism and honest stability tests).
# -ffp-contract=off in every build type, after the user's flags: no FMA contraction on the CPU, as WRF's
# gfortran build on x86-64 (no -march: no FMA instructions); with -march=native or skylake g++ would
# otherwise fuse a*b+c (its default is -ffp-contract=fast). CUDA builds: the same for nvcc's host code.
add_compile_options($<$<COMPILE_LANGUAGE:CXX>:-ffp-contract=off> $<$<COMPILE_LANGUAGE:CUDA>:-Xcompiler=-ffp-contract=off>)
# glibc libmvec's vector log / log10 take an approximate reciprocal (rcpps) whose result differs between Intel and
# AMD; ON: CPPWRF computes them as libmvec does on Intel (src/core/libmvec_x86.hpp), the same on every x86-64 CPU.
# OFF: libmvec's own (the machine's rcpps).
option(CPPWRF_PORTABLE_LIBMVEC "Vector log / log10 as glibc libmvec on Intel, on any x86-64 CPU" ON)
if(NOT CPPWRF_PORTABLE_LIBMVEC)
  add_compile_definitions(CPPWRF_LIBMVEC_HW_LOG)
endif()
option(CPPWRF_NATIVE "Tune for the build machine's CPU (-march=native); OFF for portable binaries" ON)
if(CPPWRF_NATIVE)
  set(CMAKE_CXX_FLAGS_RELEASE "-O3 -march=native")
else()
  set(CMAKE_CXX_FLAGS_RELEASE "-O3")
endif()
set(CMAKE_CUDA_FLAGS_RELEASE "-O3")
# CUDA FP64: the arithmetic of WRF's real*8 build bit for bit. --fmad=false: no fused multiply-add contraction
# (gfortran on x86-64 without -march emits none; nvcc fuses a*b+c by default), every kernel; division and sqrt are
# correctly rounded (-prec-div / -prec-sqrt true, the default; checked below). CPPWRF_CUDA_GLIBC_MATH: glibc's
# libm and libmvec algorithms on the device and the host (src/core/glibc_math.hpp) instead of CUDA's math library.
option(CPPWRF_CUDA_GLIBC_MATH "CUDA FP64 build: glibc's math functions on the device (bit-identical to WRF / CPU)" ON)
if(CPPWRF_ENABLE_CUDA AND CPPWRF_DOUBLE)
  string(APPEND CMAKE_CUDA_FLAGS " --fmad=false")
  if(NOT CPPWRF_CUDA_GLIBC_MATH)
    add_compile_definitions(CPPWRF_CUDA_LIBM)
  endif()
endif()
# flags that change results: reassociation, reciprocals, flush-to-zero, approximate division / sqrt
string(TOUPPER "${CMAKE_BUILD_TYPE}" _cppwrf_bt)
if("${CMAKE_CXX_FLAGS} ${CMAKE_CXX_FLAGS_${_cppwrf_bt}}" MATCHES
   "(-Ofast|-f(fast-math|unsafe-math-optimizations|associative-math|reciprocal-math|finite-math-only)|-ffp-contract=(fast|on))")
  message(FATAL_ERROR "CMAKE_CXX_FLAGS: '${CMAKE_MATCH_1}' changes the floating-point results (CPPWRF needs strict IEEE)")
endif()
if("${CMAKE_CUDA_FLAGS} ${CMAKE_CUDA_FLAGS_${_cppwrf_bt}}" MATCHES
   "(use_fast_math|ftz=true|prec-div=false|prec-sqrt=false|-Xcompiler=?[^ ]*(-Ofast|-ffast-math))")
  message(FATAL_ERROR "CMAKE_CUDA_FLAGS: '${CMAKE_MATCH_1}' changes the floating-point results (CPPWRF needs strict IEEE)")
endif()

enable_testing()
add_subdirectory(src/io)

file(GLOB CPPWRF_SOURCES CONFIGURE_DEPENDS
  ${CMAKE_SOURCE_DIR}/src/core/*.cpp
  ${CMAKE_SOURCE_DIR}/src/dyn/*.cpp
  ${CMAKE_SOURCE_DIR}/src/cases/*.cpp)
# Column physics used by the dycore (P1/P2 suite: sfclayrev + Noah + YSU + KF and its driver glue)
list(APPEND CPPWRF_SOURCES
  ${CMAKE_SOURCE_DIR}/src/phys/driver/suite.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/driver/surface_driver.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/driver/pbl_driver.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/driver/cumulus_driver.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/driver/fdda_driver.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/driver/phy_prep.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/driver/tendency_coupling.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/driver/landuse_tables.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/driver/radiation.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_lw/rrtmg_lw.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_lw/rrtmg_lw_batch.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_lw/rrtmg_lw_tables.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_sw/rrtmg_sw.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_sw/rrtmg_sw_batch.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_sw/rrtmg_sw_tables.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_common/cam_gases.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_common/cam_ozone.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_common/batch_memory.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtm_lw/rrtm_lw.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtm_lw/rrtm_lw_tables.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/sf_sfclayrev/sfclayrev.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/sf_myjsfc/myjsfc.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/bl_ysu/ysu.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/bl_myj/myjpbl.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/lsm_noah/noah.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/lsm_noah/noah_tables.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/lsm_noahmp/noahmp.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/lsm_noahmp/noahmp_tables.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/cu_kf/kf.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/cu_kf/kf_tables.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/mp_thompson/thompson.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/mp_thompson/thompson_tables.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/mp_morrison/morrison.cpp)
set_source_files_properties(
  ${CMAKE_SOURCE_DIR}/src/phys/mp_thompson/thompson.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/mp_morrison/morrison.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/driver/suite.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/driver/surface_driver.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/driver/pbl_driver.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/driver/cumulus_driver.cpp
  ${CMAKE_SOURCE_DIR}/src/phys/driver/fdda_driver.cpp
  PROPERTIES COMPILE_OPTIONS "$<$<COMPILE_LANGUAGE:CUDA>:--fmad=false>")

add_library(cppwrf_core STATIC ${CPPWRF_SOURCES})
# MPI ranks as the workers of a decomposed run (docs/MPI.md): mpirun -n N cppwrf ... Off: no MPI is needed and
# the build is the one without this option.
option(CPPWRF_MPI "Domain decomposition over MPI ranks (mpirun -n N cppwrf)" OFF)
if(CPPWRF_MPI)
  find_package(MPI REQUIRED COMPONENTS CXX)
  target_compile_definitions(cppwrf_core PUBLIC CPPWRF_MPI MPICH_SKIP_MPICXX OMPI_SKIP_MPICXX)  # the C interface only
  # the headers and the libraries only: the compile and link options of the MPI wrapper are the distribution's
  # (Ubuntu's MPICH: -flto=auto, which nvcc's host compile of a CUDA source cannot take)
  target_include_directories(cppwrf_core SYSTEM PUBLIC ${MPI_CXX_INCLUDE_DIRS})
  target_link_libraries(cppwrf_core PUBLIC ${MPI_CXX_LIBRARIES})
endif()
# tables shipped with the sources (data/rrtmg)
target_compile_definitions(cppwrf_core PRIVATE CPPWRF_DATA_DIR="${CMAKE_SOURCE_DIR}/data")
target_include_directories(cppwrf_core PUBLIC ${CMAKE_SOURCE_DIR}/src)
# the configuration keys CPPWRF reads (every "section.key" literal of src/; src/cases/config_keys.cpp): a key of a
# configuration that is not among them is an error. Regenerated when a source changes.
file(GLOB_RECURSE CPPWRF_KEY_SOURCES CONFIGURE_DEPENDS ${CMAKE_SOURCE_DIR}/src/*.cpp ${CMAKE_SOURCE_DIR}/src/*.hpp
     ${CMAKE_SOURCE_DIR}/src/*.cu)
add_custom_command(OUTPUT ${CMAKE_BINARY_DIR}/generated/config_keys.inc
  COMMAND ${CMAKE_COMMAND} -DROOT=${CMAKE_SOURCE_DIR}/src -DOUT=${CMAKE_BINARY_DIR}/generated/config_keys.inc
          -P ${CMAKE_SOURCE_DIR}/src/cases/config_keys.cmake
  DEPENDS ${CPPWRF_KEY_SOURCES} ${CMAKE_SOURCE_DIR}/src/cases/config_keys.cmake VERBATIM)
target_sources(cppwrf_core PRIVATE ${CMAKE_BINARY_DIR}/generated/config_keys.inc)
target_include_directories(cppwrf_core PRIVATE ${CMAKE_BINARY_DIR}/generated)
# the commit of the sources (CPPWRF's own restart files record it): git, or the hash that git archive writes into
# src/cases/commit.txt (export-subst in .gitattributes) for a source tarball
set(CPPWRF_COMMIT "unknown")
find_package(Git QUIET)
if(GIT_FOUND)
  execute_process(COMMAND ${GIT_EXECUTABLE} -C ${CMAKE_SOURCE_DIR} rev-parse --show-toplevel HEAD
                  OUTPUT_VARIABLE _git_out RESULT_VARIABLE _git_rc ERROR_QUIET OUTPUT_STRIP_TRAILING_WHITESPACE)
  if(_git_rc EQUAL 0)
    string(REPLACE "\n" ";" _git_out "${_git_out}")
    list(GET _git_out 0 _git_top)
    get_filename_component(_git_top "${_git_top}" REALPATH)
    get_filename_component(_src_top "${CMAKE_SOURCE_DIR}" REALPATH)
    if(_git_top STREQUAL _src_top)
      list(GET _git_out 1 CPPWRF_COMMIT)
    endif()
  endif()
endif()
if(CPPWRF_COMMIT STREQUAL "unknown")
  file(STRINGS ${CMAKE_SOURCE_DIR}/src/cases/commit.txt _commit LIMIT_COUNT 1)
  if(_commit MATCHES "^[0-9a-f]+$")
    set(CPPWRF_COMMIT ${_commit})
  endif()
endif()
message(STATUS "CPPWRF commit: ${CPPWRF_COMMIT}")
set_property(SOURCE ${CMAKE_SOURCE_DIR}/src/cases/domain_runner.cpp APPEND PROPERTY COMPILE_DEFINITIONS
             CPPWRF_COMMIT="${CPPWRF_COMMIT}")
target_link_libraries(cppwrf_core PUBLIC cppwrf_io)
# glibc libmvec: Grell-Freitas-Li uses the 2-lane vector pow where WRF's gfortran build vectorises (cu_gfl)
if(CMAKE_SYSTEM_PROCESSOR MATCHES "x86_64|AMD64")
  target_link_libraries(cppwrf_core PUBLIC mvec)
endif()
if(EXISTS ${CMAKE_SOURCE_DIR}/src/dyn/small_step.cpp)
  target_compile_definitions(cppwrf_core PUBLIC CPPWRF_HAVE_SMALL_STEP)
endif()
if(CPPWRF_DOUBLE)
  target_compile_definitions(cppwrf_core PUBLIC CPPWRF_DOUBLE)
endif()

# NetCDF-C library
find_package(netCDF CONFIG QUIET)
if(NOT TARGET netCDF::netcdf)
  find_package(PkgConfig QUIET)
  if(PKG_CONFIG_FOUND)
    pkg_check_modules(NETCDF netcdf)
  endif()
endif()
find_path(NETCDF_INCDIR netcdf.h HINTS /usr/include /usr/local/include)
if(TARGET netCDF::netcdf OR NETCDF_FOUND OR NETCDF_INCDIR)
  if(EXISTS ${CMAKE_SOURCE_DIR}/src/io_netcdf)
    add_subdirectory(src/io_netcdf)
    target_link_libraries(cppwrf_core PUBLIC cppwrf_io_netcdf)
    target_compile_definitions(cppwrf_core PUBLIC CPPWRF_HAVE_NETCDF)
  endif()
  if(EXISTS ${CMAKE_SOURCE_DIR}/tests/io_netcdf)
    add_subdirectory(tests/io_netcdf)
  endif()
  # C++ real.exe (host only)
  find_library(NETCDF_LIBRARY NAMES netcdf HINTS /usr/lib /usr/lib/x86_64-linux-gnu /usr/local/lib)
  set(NETCDF_INCLUDE_DIR ${NETCDF_INCDIR})
  add_subdirectory(src/wrf_io)
  target_link_libraries(cppwrf_core PUBLIC cppwrf_wrfio)
  add_subdirectory(src/init_real)
  # cppwrf_real against WRF real.exe output (skipped, exit 77, without ${CPPWRF_WRF_RUNS}/real)
  add_test(NAME real_vs_wrf COMMAND bash ${CMAKE_SOURCE_DIR}/tests/init_real/run_real_test.sh ${CMAKE_BINARY_DIR}
           WORKING_DIRECTORY ${CMAKE_SOURCE_DIR})
  set_tests_properties(real_vs_wrf PROPERTIES SKIP_RETURN_CODE 77)
  # wrfout/wrfrst files identical to WRF v4.8.0's (CPU FP64 builds; skipped, exit 77, without ${CPPWRF_WRF_RUNS})
  if(CPPWRF_DOUBLE AND NOT CPPWRF_ENABLE_CUDA)
    add_test(NAME wrf_files_vs_wrf COMMAND bash ${CMAKE_SOURCE_DIR}/tests/verify/run_wrf_files_test.sh ${CMAKE_BINARY_DIR}
             WORKING_DIRECTORY ${CMAKE_SOURCE_DIR})
    set_tests_properties(wrf_files_vs_wrf PROPERTIES SKIP_RETURN_CODE 77)
  endif()
endif()

# Single-source kernels: every source of the core is compiled by nvcc in CUDA builds.
function(cppwrf_device_sources)
  if(CPPWRF_ENABLE_CUDA)
    set_source_files_properties(${ARGN} PROPERTIES LANGUAGE CUDA)
  endif()
endfunction()

if(CPPWRF_ENABLE_CUDA)
  cppwrf_device_sources(${CPPWRF_SOURCES})
  # RRTMG host code (tables, constants, the column drivers of the checks) and RRTM LW (host columns with OpenMP):
  # C++; the device path is radiation.cpp + rrtmg_lw_batch.cpp + rrtmg_sw_batch.cpp
  set_source_files_properties(
    ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_lw/rrtmg_lw.cpp ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_lw/rrtmg_lw_tables.cpp
    ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_sw/rrtmg_sw.cpp ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_sw/rrtmg_sw_tables.cpp
    ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_common/cam_gases.cpp ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_common/cam_ozone.cpp
    ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtm_lw/rrtm_lw.cpp ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtm_lw/rrtm_lw_tables.cpp
    PROPERTIES LANGUAGE CXX)
  # RRTMG on the device: no FMA contraction (WRF's x86 arithmetic; table indices int(tblint*x + 0.5)
  # are discontinuous, so contracted products move them)
  set_source_files_properties(
    ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_lw/rrtmg_lw_batch.cpp ${CMAKE_SOURCE_DIR}/src/phys/ra_rrtmg_sw/rrtmg_sw_batch.cpp
    PROPERTIES COMPILE_OPTIONS "--fmad=false")
  target_compile_definitions(cppwrf_core PUBLIC CPPWRF_USE_CUDA)
  target_compile_options(cppwrf_core PUBLIC $<$<COMPILE_LANGUAGE:CUDA>:--expt-relaxed-constexpr --extended-lambda>)
  target_link_libraries(cppwrf_core PUBLIC CUDA::cudart)
  # host OpenMP for the radiation columns (C++ sources only)
  find_package(OpenMP REQUIRED COMPONENTS CXX)
  target_link_libraries(cppwrf_core PUBLIC OpenMP::OpenMP_CXX)
else()
  target_link_libraries(cppwrf_core PUBLIC OpenMP::OpenMP_CXX)
endif()

if(EXISTS ${CMAKE_SOURCE_DIR}/src/main.cpp)
  add_executable(cppwrf src/main.cpp)
  cppwrf_device_sources(src/main.cpp)
  target_link_libraries(cppwrf PRIVATE cppwrf_core)
  target_compile_definitions(cppwrf PRIVATE CPPWRF_VERSION="${PROJECT_VERSION}" CPPWRF_COMMIT="${CPPWRF_COMMIT}")
endif()

# Unit tests (tests/unit/*.cpp; tests/unit/io belongs to cppwrf_io)
file(GLOB CPPWRF_UNIT_TESTS CONFIGURE_DEPENDS ${CMAKE_SOURCE_DIR}/tests/unit/*.cpp)
foreach(src ${CPPWRF_UNIT_TESTS})
  get_filename_component(name ${src} NAME_WE)
  add_executable(${name} ${src})
  cppwrf_device_sources(${src})
  target_link_libraries(${name} PRIVATE cppwrf_core)
  add_test(NAME ${name} COMMAND ${name} WORKING_DIRECTORY ${CMAKE_SOURCE_DIR})
  # OpenMP threads that spin while waiting stall the tests for hours on a loaded machine
  set_tests_properties(${name} PROPERTIES ENVIRONMENT "OMP_NUM_THREADS=2;OMP_WAIT_POLICY=passive")
endforeach()

# Namelist translator (tools/wrf2cppwrf.py; python3, no WRF data needed)
add_subdirectory(tests/tools)

# every launch of a kernel that raises a WRF fatal stop is followed by fatal_check() (tools/lint_fatal_check.py)
add_test(NAME lint_fatal_check COMMAND python3 ${CMAKE_SOURCE_DIR}/tools/lint_fatal_check.py ${CMAKE_SOURCE_DIR}/src)
set_tests_properties(lint_fatal_check PROPERTIES LABELS unit)
# deliberate faults the model refuses: unknown configuration keys, nz above a column limit, a restart with other
# options; the non-finite check of every step (tests/robustness/run_test.sh, analytic cases)
if(TARGET cppwrf)
  add_test(NAME robustness COMMAND bash ${CMAKE_SOURCE_DIR}/tests/robustness/run_test.sh $<TARGET_FILE:cppwrf>
           ${CMAKE_BINARY_DIR}/robustness WORKING_DIRECTORY ${CMAKE_SOURCE_DIR})
  set_tests_properties(robustness PROPERTIES LABELS unit ENVIRONMENT "OMP_NUM_THREADS=2;OMP_WAIT_POLICY=passive")
endif()

# Differential tests against WRF v4.8.0's own compiled code (gfortran; slow): physics schemes, the
# physics driver glue, diffusion kernels, nest numerics. ctest -L diff runs them; they need WRF_DIR (a WRF v4.8.0
# -r8 build tree) and WRF_R8D8_DIR (-r8 -fdefault-double-8), some CPPWRF_WRF_RUNS (tests/phys/wrf_fortran.sh), and
# exit 77 (skipped) without them. tools/gcp/gcp_run.sh runs them on every full VM suite.
option(CPPWRF_DIFF_TESTS "Register the WRF-Fortran differential tests with ctest" OFF)
if(CPPWRF_DIFF_TESTS)
  find_package(OpenMP REQUIRED COMPONENTS CXX)  # the CPU reference drivers (also in CUDA builds)
  add_subdirectory(tests/phys)
  set(DIFF_WORK ${CMAKE_BINARY_DIR}/diff_work)
  foreach(t dyn/diffusion phys/suite nest)
    string(REPLACE "/" "_" tname "diff_${t}")
    add_test(NAME ${tname} COMMAND bash ${CMAKE_SOURCE_DIR}/tests/${t}/run_test.sh WORKING_DIRECTORY ${CMAKE_SOURCE_DIR})
    set_tests_properties(${tname} PROPERTIES LABELS diff SKIP_RETURN_CODE 77  # 77: no WRF build / runs
                         ENVIRONMENT "DIFF_TEST_BUILD_DIR=${DIFF_WORK}")
  endforeach()
  # column replays of the model's cumulus calls through WRF's objects (CPU FP64 cppwrf; need
  # CPPWRF_WRF_RUNS and WRF_R8D8_DIR)
  if(CPPWRF_DOUBLE AND NOT CPPWRF_ENABLE_CUDA)
    foreach(t cu_gfl cu_ntiedtke)
      add_test(NAME diff_phys_${t} COMMAND bash ${CMAKE_SOURCE_DIR}/tests/phys/${t}/run_test.sh ${CMAKE_BINARY_DIR}
               WORKING_DIRECTORY ${CMAKE_SOURCE_DIR})
      set_tests_properties(diff_phys_${t} PROPERTIES LABELS diff SKIP_RETURN_CODE 77
                           ENVIRONMENT "CPPWRF_SCRATCH=${DIFF_WORK}")
    endforeach()
  endif()
endif()

# cmake --install and CPack (cmake/Install.cmake)
include(cmake/Install.cmake)
